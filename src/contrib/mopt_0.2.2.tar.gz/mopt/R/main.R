#' @export mopt
mopt <- function(init, fn, method = "rwalk", control = list(), ...) {

  if (! "save_iterations" %in% names(control)) {
    control$save_iterations <- 2000
  }
  if (! "report" %in% names(control)) {
    control$report <- FALSE
  }
  if (! "iterations" %in% names(control)) {
    control$iterations <- 2000
  }
  if (! "min_iterations" %in% names(control)) {
    control$min_iterations <- 5000
  }

  prior_args <- control$prior_args

  # The number of parameters
  par_num   <- length(init)
  # The current set of parameters
  cur_pars  <- init
  # The proposed set of parameters
  prop_pars <- init
  # The log likelihood at the initial values
  cur_ll    <- fn(cur_pars, ...)

  # The matrix that'll keep track of the values
  # run, likelihood, parameters
  out_pars  <- matrix(0, ncol = 3 + par_num, nrow = control$save_iterations)

  # First value is the initial values
  out_pars[nrow(out_pars), 1] <- 1      # iteration number
  out_pars[nrow(out_pars), 2] <- cur_ll # current ll
  out_pars[nrow(out_pars), 3] <- 0      # probability of next step
  out_pars[nrow(out_pars), 4:ncol(out_pars)] <- init # parameters

  # Save the maximum likelihood achieved, and the associated parameter values
  max_like <- -Inf
  max_pars <- init

  # Steps for standard deviations
  sd_i    <- .5
  sd_up   <- 1.05
  sd_down <- 0.95

  run_mean  <- min(50, control$save_iterations)
  ratio_vec <- vector(mode = "numeric", length = run_mean)

  iteration <- 1

  # Number of rows in out_pars
  nrop <- nrow(out_pars)
  l1 <- seq_len(nrop - 1)
  l2 <- 1 + l1

  # Go through the runs
  while (TRUE) {

    # Bump the out_pars matrix
    out_pars[l1, ]   <- out_pars[l2, ]
    out_pars[nrop, ] <- NA

    # First randomly pick our next step from a normal distribution
    nstep     <- rnorm(par_num, sd = sd_i)
    # Get the proposed set of parameters
    prop_pars <- cur_pars + nstep
    # Get the proposed likelihood
    prop_ll   <- fn(prop_pars, ...)

    # The probability of stepping
    ratio <- exp(prop_ll - cur_ll)
    if (method == "mcmc") {
      # Incorporate priors for bayesian
      prior_current   <- control$prior_fn(cur_pars,  prior_args)
      prior_proposed  <- control$prior_fn(prop_pars, prior_args)

      ratio <- log(ratio) + sum(log(prior_proposed)) - sum(log(prior_current))
      ratio <- exp(ratio)

      if (! is.finite(ratio)) {
        cat("Something caused a non-finite ratio, skipping iteration\n")
        next
      }
    }

    # Probability of taking the next step
    p_nstep <- min(ratio, 1)

    # Resolve this probability
    r_nstep <- runif(1)
    if (p_nstep > r_nstep) {
      # The proposed has beat out the current, so we step
      cur_ll   <- prop_ll
      cur_pars <- prop_pars

      out_pars[nrop, 1] <- iteration
      out_pars[nrop, 2] <- prop_ll
      out_pars[nrop, 3] <- p_nstep
      out_pars[nrop, 4:ncol(out_pars)] <- prop_pars
    } else {
      # The proposed hasn't beat out the curret, so we stay
      out_pars[nrop, 1] <- iteration
      out_pars[nrop, 2] <- cur_ll
      out_pars[nrop, 3] <- p_nstep
      out_pars[nrop, 4:ncol(out_pars)] <- cur_pars
    }

    ## See if we can get some smart sd picking
    p_nstep_avg <- 0

    if (iteration == run_mean) {
      sest      <- out_pars[, 4:ncol(out_pars)]
      sd_i      <- sqrt(diag(var(sest)))
      sd_i      <- ifelse(sd_i == 0, 0.01, sd_i)
    }

    if (iteration > run_mean) {
      p_nstep_avg <- mean(out_pars[(nrop - run_mean):nrop, 3])

      if (p_nstep_avg < 0.4) {
        sd_i <- sd_i * sd_down
      } else if (p_nstep_avg > 0.6) {
        sd_i <- sd_i * sd_up
      }
    }

    # Check if we're at a maximum
    if (cur_ll > max_like) {
      max_like <- cur_ll
      max_pars <- cur_pars
      if (control$report) {
        cat("NM| Iteration:", iteration, "| Likelihood:", cur_ll, "| Max:", max_like, "\n")
      }
    }

    if (iteration %% 100 == 0) {
      cat("II| Iteration:", iteration,
          "| E(p(Prop)):", p_nstep_avg,
          "| Likelihood:", cur_ll,
          "\n")
    }

    # Check if we break the loop
    if (method == "mcmc") {
      check <- mcmc_checker(iteration, control, out_pars, max_like)
    } else {
      check <- ml_checker(iteration, control, out_pars, max_like)
    }
    if (iteration > control$iterations) check <- TRUE
    if (check) break

    iteration <- iteration + 1
  }

  # Sort the parameter matrix by the iteration
  out_pars <- out_pars[order(out_pars[, 1]), ]

  if (method == "mcmc") {
    res <- list(estimates  = out_pars[, 4:ncol(out_pars)],
                likelihood = out_pars[, 2],
                sample_id  = out_pars[, 1],
                convcode   = 0)
  } else {
    res <- list(estimates = max_pars, likelihood = max_like,  convcode = 0)
  }
  res
}

ml_checker <- function(iteration, control, out_pars, max_like) {
  # If the number of runs is greater than the iteration limit
  # break now
  # If we don't have a new max in the last number of save iterations
  # break now
  if ((iteration %% 100 == 0) & (iteration >= control$save_iterations)) {
    if (max_like %in% out_pars[, 2]) {
      ret_val <- FALSE
    } else {
      ret_val <- TRUE
    }
  } else {
    ret_val <- FALSE
  }
  return(ret_val)
}

mcmc_checker <- function(iteration, control, out_pars, max_like) {
  # If the number of runs is greater than the iteration limit
  # break now

  if ((iteration > control$min_iterations) & (iteration > control$save_iterations)) {
    ret_val <- TRUE
  } else {
    ret_val <- FALSE
  }
  return(ret_val)
}
