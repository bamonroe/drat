nloptr_opt <- function(pars, lfun, wrap_opts, method, optopt) {
  method <- ifelse(method == "sbplx",      "NLOPT_LN_SBPLX",       method)
  method <- ifelse(method == "bobyqa",     "NLOPT_LN_BOBYQA",      method)
  method <- ifelse(method == "cobyla",     "NLOPT_LN_COBYLA",      method)
  method <- ifelse(method == "neldermead", "NLOPT_LN_NELDERMEAD",  method)
  method <- ifelse(method == "praxis",     "NLOPT_LN_PRAXIS",      method)
  method <- ifelse(method == "newuoa",     "NLOPT_LN_NEWUOA",      method)

  if (! "iterations" %in% names(optopt)) {
    optopt$iterations <- 1000
  }
  if (! "report" %in% names(optopt)) {
    optopt$report <- TRUE
  }

  if (optopt$report) {
    trace <- 2
  } else {
    trace <- 0
  }

  out <- nloptr::nloptr(x0 = pars,
                 eval_f = rcest::lfun_wrap,
                 opts = list(algorithm = method, print_level = trace, maxeval = optopt$iterations),
                 lfun = function(...) {-lfun(...)},
                 wrap_opts = wrap_opts,
                 sum_res = TRUE)

  list(estimates = out$solution, likelihood = -abs(out$objective))
}

maxlik_opt <- function(pars, lfun, wrap_opts, method, optopt = list()) {
  method <- ifelse(method == "bhhh", "BHHH", method)
  method <- ifelse(method == "nr",   "NR",   method)

  if (! "iterations" %in% names(optopt)) {
    optopt$iterations <- 1000
  }
  if (! "report" %in% names(optopt)) {
    optopt$report <- TRUE
  }

  if (optopt$report) {
    if (! "trace" %in% names(optopt)) {
      optopt$trace <- 2
    }
  } else {
    optopt$trace <- 0
  }

  out <- maxLik::maxLik(logLik = rcest::lfun_wrap,
                        start = pars, method = method,
                        control = list(iterlim = optopt$iterations, printLevel = optopt$trace),
                        lfun = lfun,
                        wrap_opts = wrap_opts,
                        sum_res = ifelse(method == "BHHH", FALSE, TRUE))

  list(estimates = out$estimate, likelihood = -abs(out$maximum))
}

mcmc_opt <- function(pars, lfun, wrap_opts, method, optopt) {

  if (! "iterations" %in% names(optopt)) {
    optopt$iterations <- 1000
  }
  if (! "report" %in% names(optopt)) {
    optopt$report <- TRUE
  }

  if (optopt$report) {
    trace <- 2
  } else {
    trace <- 0
  }

  optopt$prior_args <- wrap_opts
  out <- mopt(pars,
              fn = rcest::lfun_wrap,
              method = method,
              control = optopt,
              lfun = lfun,
              wrap_opts = wrap_opts,
              sum_res = TRUE)

  list(estimates = out$estimates, likelihood = out$likelihood, sample_id = out$sample_id)
}

mbmark_opt <- function(pars, lfun, wrap_opts, method, optopt) {

  if (! "iterations" %in% names(optopt)) {
    optopt$iterations <- 100
  }
  if (! "report" %in% names(optopt)) {
    optopt$report <- TRUE
  }
  if (! "control" %in% names(optopt)) {
    optopt$control <- list()
  }

  out <- microbenchmark::microbenchmark(val <- rcest::lfun_wrap(pars,
                                                         lfun = lfun,
                                                         wrap_opts = wrap_opts,
                                                         sum_res = TRUE),
                                        times = optopt$iterations,
                                        control = optopt$control)

  list(estimates = pars, likelihood = val, microbenchmark = out)
}
