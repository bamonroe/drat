#' @export gibbs_opt
gibbs_opt <- function(init, jump, n, post_fn, chains = 1, mccores = 1) {

  npar <- length(init)

  if (mccores > 1) {
    lfun <- function(..., mc.cores = mccores) parallel::mclapply(..., mc.cores = mc.cores)
  } else {
    lfun <- lapply
  }

  samples <- lfun(seq_len(chains), function(chain) {

    samples <- matrix(NA, nrow = n, ncol = 3 + npar)
    samples[, 1] <- chain

    pars  <- init
    ppars <- init

    for (iter in seq_len(n)) {

      samples[iter, 2] <- iter

      for (i in seq_len(npar)) {

        # Get the current posterior
        post <- post_fn(pars, i)

        # Propose some parameters
        ppars[i] <- rnorm(pars[i], 0, jump[i])

        # Get the proposed posterior
        ppost <- post_fn(ppars, i)

        # Resolve the mcmc jump
        ratio <- min(c(ppost - post, 0))
        resolve <- log(runif(1))

        if (ratio > resolve) {
          post <- ppost
          pars <- ppars
        }


      }

      samples[iter, 3] <- post
      samples[iter, 4:(npar + 3)] <- pars

    }

      samplpes

  })

  samples <- do.call(rbind, samples)
  samples <- as.data.frame(samples)
  colnames(samples) <- c("chain", "iter", "post", names(init))
  samples

}
