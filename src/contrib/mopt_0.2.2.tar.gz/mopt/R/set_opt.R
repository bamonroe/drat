.onLoad <- function(libname, pkgname) {
  if ("rcest" %in% loadedNamespaces()) {
    # Set some extra optimizers
    rcest::set_optimizer(method = c("sbplx"),      type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("bobyqa"),     type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("cobyla"),     type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("neldermead"), type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("praxis"),     type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("newuoa"),     type = "ml",    fn = nloptr_opt)
    rcest::set_optimizer(method = c("bhhh"),       type = "ml",    fn = maxlik_opt)
    rcest::set_optimizer(method = c("nr"),         type = "ml",    fn = maxlik_opt)
    rcest::set_optimizer(method = c("rwalk"),      type = "ml",    fn = mcmc_opt)
    rcest::set_optimizer(method = c("mcmc"),       type = "bayes", fn = mcmc_opt)

    # Some not-real optimizers
    rcest::set_optimizer(method = c("microbenchmark", "mbmark"), type = "ml", fn = mbmark_opt)
  }
}
