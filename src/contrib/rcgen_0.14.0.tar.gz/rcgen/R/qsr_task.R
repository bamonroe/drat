qsr <- function(r, a, b) {
  s <- c(r, 1 - r)
  o <- a + b * (2 * r - sum(s^2))
  o
}

#' @title Create a QSR instument
#'
#' @description qsr_task generates a risk inst using the quadratic scoring rule
#' to generate outcomes. This is the kind of inst implied by a 2-bin token
#' allocation task. This function sets the generated inst using set_inst, and
#' can then be generated using the name "qsr_<tokens>" where <tokens> is the
#' number passed as the "tokens" argument.
#'
#' @param tokens the number of tokens allowed to allocate
#' @param apar the vector of "a" parameters
#' @param bpar the vector of "b" parameters
#' @param prob1 the vector of probabilities for opt*_out1
#' @export qsr_task
qsr_task <- function(tokens, apar, bpar, prob1) {

  prob2 <- 1 - prob1

  q <- seq(from = 0, to = 1, length.out = tokens + 1)

  dat <- lapply(seq_along(q), function(opt) {

    r <- q[opt]
    out1 <- qsr(r, apar, bpar)
    out2 <- qsr(1 - r, apar, bpar)

    d <- cbind(out1, out2, prob1, prob2)
    d <- as.data.frame(d)
    colnames(d) <- c(
      paste0("opt", opt, "_out1"),
      paste0("opt", opt, "_out2"),
      paste0("opt", opt, "_prob1"),
      paste0("opt", opt, "_prob2")
    )

    d
  })
  dat <- do.call(cbind, dat)

  dat$Max  <- apar + bpar
  dat$Min  <- apar - bpar
  dat$task <- "risk"
  dat$inst <- paste0("qsr_", tokens)

  dat <-rcest::rank_inst(dat, "standard", use_times = F)

  set_inst(name = paste0("qsr_", tokens), inst = dat)
}
