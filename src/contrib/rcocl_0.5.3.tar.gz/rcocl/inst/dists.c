#define PI 3.14159265358979
#define SQ2PI 2.506628274631
#define SQ2 1.4142135623731
#define ERF_A 0.147
#define PI_A 4.330746751
#define PI2 6.283185

#define BETA_STOP 1.0e-7
#define BETA_TINY 1.0e-30

// Constants for buffer sizes
#ifndef BATCHMAX
#define BATCHMAX 10
#endif
#ifndef BATCH_TRIANGLE
#define BATCH_TRIANGLE (BATCHMAX * (BATCHMAX + 1) / 2)
#endif

#ifndef BATCHMAX
#define BATCHMAX 10
#endif

typedef struct BatchInfo {
  int pari;  // The index of the first parameter in the batch
  int batch; // Which batch are we estimating
  int bpars; // How many pars are in this batch (this is just a helpful thing)
  __constant uint *batches; // The pointer to the vector of batches
  uint  *rng; // Pointer to the RNG state
  uint  stype; // What type of sampler? (0) MCMC or (1) Direct?
  float *pars; // the array of parameters
  float *target; // pointer to the posterior probability
  float *pptr;  // Pointer to pars[pari];
} BatchInfo;


// From Xorshift RNGs
// George Marsaglia
// https://doi.org/10.18637/jss.v008.i14
float runif(uint* s) {
	// uint in OpenCL is 32 bit
	uint y = *s;
	// Note these are all prime
	y ^= y << 13;
	y ^= y >> 17;
	y ^= y << 15;
	// The runif function self-updates the state
	*s = y;
	// x is a uint, we want a float, so divide by the maximum uint
	float o = (y >> 8) * 0x1.0p-24;
	return(o);
};

float dunif(float x, float lower, float upper) {
	float d = 1.0 / (upper - lower);
	if (x >= lower && x <= upper) return(d);
	return(0.0);
}

float ldunif(float x, float lower, float upper) {
	float d = -log(upper - lower);
	if (x >= lower && x <= upper) return(d);
	return(-INFINITY);
}

float dnorm(float x, float m, float s)
{
	return exp(-.5 * pow((float)(x - m)/s, (float)2.0)) / (s * SQ2PI);
};

float ldnorm(float x, float m, float s)
{
  return -log(s) - .5 * log(PI2) - pow((float)(x - m), (float)2.0) / (2.0 * pow((float)s, (float)2.0));
};

float pnorm(float x, float m, float s)
{
	return .5 * (1 + erf((x - m) / (s * SQ2)));
};

// This is just an approximation of the inverse erf
// https://en.wikipedia.org/wiki/Error_function#Inverse_functions
float ierf(float z)
{
	float t1 = log(1 - pow((float)z, (float)2.0));
	float t2 = PI_A + (t1 / 2.0);
	return sign(z) * sqrt(
		sqrt(pow((float)t2, (float)2.0) - (t1 / ERF_A)) - t2
	);
};

float qnorm(float x, float m, float s)
{
	return m + s * SQ2 * ierf(2.0 * x - 1.0);
};

float rnorm(uint* s, float mean, float sd)
{
  float ru, out;
  for (int try = 0; try < 5; try++) {
    ru  = runif(s);
    out = qnorm(ru, mean, sd);
    if (isfinite(out)) {
      try = 6;
    }
  }
  return out;
};

// get the index in the array representing the lower-triangle of a symmetric matrix
int sym_index(int row, int col) {
  if (row >= col)
    return (row + 1) * (row + 2) / 2 - 1 - row + col;
  else
    return (col + 1) * (col + 2) / 2 - 1 - col + row;
}

//' @param input the (lower triangle) input matrix
//' @param lower_chol the lower triangle Cholesky decomposition of the matrix
//' @param dim the dimension size of the matrix
void cholesky(
  float* input,
  float* lower_chol,
  int dim
){
  // Algorithm borrowed for wikipedia creative commons
  // https://en.wikipedia.org/wiki/Cholesky_decomposition#The_Cholesky%E2%80%93Banachiewicz_and_Cholesky%E2%80%93Crout_algorithms

  int i, j, k;
  float sum;

  for (i = 0; i < dim; i++) {
    for (j = 0; j <= i; j++) {
      sum = 0.0;

      for (k = 0; k < j; k++) {
        sum += lower_chol[sym_index(i, k)] * lower_chol[sym_index(j, k)];
      }

      if (i == j) {
        lower_chol[sym_index(i, j)] = sqrt(input[sym_index(i, i)] - sum);
      } else {
        lower_chol[sym_index(i, j)] = (1.0 / lower_chol[sym_index(j, j)] * (input[sym_index(i, j)] - sum));
      }
    }
  }
}

//' @param lower_chol the lower triangle Cholesky decomposition of the matrix
//' @param dim the dimension size of the matrix
float ldeterminant_chol(
  float *lower_chol,
  int dim
){
  // Note
  // det(sigma) = det(LL^T) = det(L)det(L^T)
  // where sigma is a positive definite symmetric matrix (it'll typically be a
  // covariance matrix for our purposes), L is a lower triangle matrix and L^T
  // is it's transpose. L is found by a Cholesky decomposition of the matrix
  // sigma.
  // Note also:
  // det(L) = det(L^T)
  float out = 0;
  for (int i = 0; i < dim; i++) {
    out += log(lower_chol[sym_index(i, i)]);
  }
  out *= 2;

  return out;
};

//' @param lower_chol the lower triangle Cholesky decomposition of the matrix
//' @param out the output matrix - a lower triangle as it's assumed symmetric positive definite
//' @param dim the dimension size of the matrix
void inverse_chol(
  float *lower_chol,
  float* output,
  int dim
){
  // Note
  // M = LL^T
  // M^(-1) = L^(-T)L^(-1)
  float x;
  // This solves for the inverse of the lower triangular matrix using forward
  // substitution
  // https://en.wikipedia.org/wiki/Triangular_matrix#Forward_substitution
  for (int col = 0; col < dim; col++) {
    for (int row = col; row < dim; row++) {
      x = row == col ? 1.0 : 0;
      for (int back = col; back < row; back++) {
        x -= lower_chol[sym_index(row, back)] * output[sym_index(back, col)];
      }
      output[sym_index(row, col)] = x / lower_chol[sym_index(row, row)];
    }
  }
  // This is the (L^(-1))^T %*% L^(-1)
  // In place! (other than the x float)
  for (int row = 0; row < dim; row++) {
    for (int col = 0; col <= row; col++) {
      x = 0;
      for (int scan_row = row; scan_row < dim ; scan_row++) {
        x += output[sym_index(scan_row, row)] * output[sym_index(scan_row, col)];
      }
      output[sym_index(row, col)] = x;
    }
  }
};

//' @param rng        pointer to rng state
//' @param mean       the vector of means
//' @param lower_chol the lower triangle Cholesky decomposition of the matrix
//' @param output     the array where the values will be saved
//' @param dim        the dimension of the covariance matrix
void mvrnorm(
  uint*  rng,
  float* mean,
  global float* lower_chol,
  float* output,
  int    dim
){

  float norm_value;
  int nvec_i, avec_i;

  for (avec_i = 0; avec_i < dim; avec_i++) {
    output[avec_i] = 0;
  }

  for (nvec_i = 0; nvec_i < dim; nvec_i++) {
    // Get a random standard normal number
    norm_value = rnorm(rng, 0.0, 1.0);
    for (avec_i = nvec_i; avec_i < dim; avec_i++) {
      output[avec_i] += norm_value * lower_chol[sym_index(avec_i, nvec_i)];
    }
    // Add the mean to the random numbers
    output[nvec_i] += mean[nvec_i];
  }
}

//' @param xmat       the vector representing one draw from the mvnorm distribution
//' @param mean       the vector of means
//' @param lower_chol the lower triangle Cholesky decomposition of the matrix
//' @param dim        the dimension of the covariance matrix
float lmvdnorm(
  float* xmat,
  float* mean,
  float* lower_chol,
  int dim
){

  float inverse_sigma[BATCH_TRIANGLE];
  inverse_chol(lower_chol, inverse_sigma, dim);

  float output = 0, buf = 0;

  // This is:
  // (x - mean)^T %*% inverse_sigma %*% (x - mean)
  // this collapses to a scalar value. The below is worked out such that we
  // don't need to store the intermediate result of (x - mean)^T %*% inverse_sigma

  for (int col = 0; col < dim; col++) {
    buf = 0;
    for (int row = 0; row < dim; row++) {
      buf += (xmat[row] - mean[row]) * inverse_sigma[sym_index(row, col)];
    }
    output += buf * (xmat[col] - mean[col]);
  }

  output *= -.5;

  // Now add the left term
  // square root of 2 * pi raised to the power of the dimensions
  output += - log(SQ2PI) * dim;

  // add the inverse of the square root of the determinant
  output += -.5 * ldeterminant_chol(lower_chol, dim);

  return  output;
};

// Log multivariate normal density, but where inverse of the covariance matrix and the determinant of the covariance matrix are supplied
//' @param xmat          the vector representing one draw from the mvnorm distribution
//' @param mean          the vector of means
//' @param inverse_sigma the inverse of the covariance matrix
//' @param det           the determinant of the covariance matrix
//' @param dim           the dimension of the covariance matrix
float lmvdnorm_inv_det(
  float* xmat,
  global float* mean,
  global float* inverse_sigma,
  float det,
  int dim
){

  float output = 0, buf = 0;

  // This is:
  // (x - mean)^T %*% inverse_sigma %*% (x - mean)
  // this collapses to a scalar value. The below is worked out such that we
  // don't need to store the intermediate result of (x - mean)^T %*% inverse_sigma

  for (int col = 0; col < dim; col++) {
    buf = 0;
    for (int row = 0; row < dim; row++) {
      buf += (xmat[row] - mean[row]) * inverse_sigma[sym_index(row, col)];
    }
    output += buf * (xmat[col] - mean[col]);
  }

  output *= -.5;

  // Now add the left term
  // square root of 2 * pi raised to the power of the dimensions
  output += - log(SQ2PI) * dim;

  // add the inverse of the square root of the determinant
  output += -.5 * det;

  return  output;
};


// This is the regularized beta function, in log form
float lbeta(float a, float b)
{
	// lgamma is a built-in for opencl
	return lgamma(a) + lgamma(b) - lgamma(a + b);
};

// The log of the beta density function
float ldbeta(float x, float a, float b)
{
	float den = log(powr((float)x, (float) (a - 1.0))) + log(powr((float)(1.0 - x), (float)(b - 1.0))) - lbeta(a, b);
	return(den);
};

// The log of the beta density function
float ldbeta_alt(float x, float m, float p)
{
	return(ldbeta(x, m * p, (1 - m) * p));
};

float pbeta(float x, float a, float b) {
    if (x < 0.0 || x > 1.0) return 1.0/0.0;

    /*The continued fraction converges nicely for x < (a+1)/(a+b+2)*/
    if (x > (a + 1.0)/(a + b + 2.0)) {
        return (1.0 - pbeta(b, a, 1.0 - x)); /*Use the fact that beta is symmetrical.*/
    }

    /*Find the first part before the continued fraction.*/
    const float lbeta_ab = lgamma(a) + lgamma(b) - lgamma(a + b);
    const float front = exp(log(x) * a + log(1.0 - x) * b - lbeta_ab) / a;

    /*Use Lentz's algorithm to evaluate the continued fraction.*/
    float f = 1.0, c = 1.0, d = 0.0;

    int i, m;
    for (i = 0; i <= 200; ++i) {
        m = i / 2;

        float numerator;
        if (i == 0) {
            numerator = 1.0; /*First numerator is 1.0.*/
        } else if (i % 2 == 0) {
            numerator = (m * (b - m) * x) / ((a + 2.0 * m - 1.0) * (a + 2.0 * m));  /* Even term. */
        } else {
            numerator = -((a + m) * (a + b + m) * x) / ((a + 2.0 * m) * (a + 2.0 * m + 1));  /* Odd term. */
        }

        /*Do an iteration of Lentz's algorithm.*/
        d = 1.0 + numerator * d;
        if (fabs(d) < BETA_TINY) d = BETA_TINY;
        d = 1.0 / d;

        c = 1.0 + numerator / c;
        if (fabs(c) < BETA_TINY) c = BETA_TINY;

        const float cd = c*d;
        f *= cd;

        /*Check for stop.*/
        if (fabs(1.0 - cd) < BETA_STOP) {
            return front * (f - 1.0);
        }
    }

    return 1.0/0.0; /*Needed more loops, did not converge.*/
}

void norm_to_lnnorm(float *m, float *s)
{
	// Squarring terms
	float m2 = *m * *m;
	float s2 = *s * *s;

	*m = log(m2 / sqrt(m2 + s2));
	*s = sqrt(log(1 + (s2 / m2)));
}

// This is defined in terms of the mean and standard deviation of the log-normal distribution
float dlnorm_adj(float x, float m, float s)
{
	norm_to_lnnorm(&m, &s);

	float o = (1 / (x * s * SQ2PI));
	float n = log(x) - m;
	n = -n * n;
	n = exp(n / (2 * s * s));

	o = o * n;

	return o;
};

// This is defined the normal way where m and s are the underlying normal distribution moments
float ldlnorm(float x, float m, float s)
{
  return -log(x) -log(s) - .5 * log(PI2) - pow((float)(log(x) - m), (float)2.0) / (2.0 * pow((float)s, (float)2.0));
}

// Inverse-Gamma density function
float ldigamma(float x, float a, float b) {
	int sign;
	float v = lgamma_r(a, &sign);
	float out = a * log(b) - (sign * v) - (a + 1) * log(x) - (b / x);
	return(exp(out));
}

float rgamma(uint *s, int a, float b) {

  float sum_unif = 0;
  for (int try = 0; try < 5; try++) {
    sum_unif = 0;
    for (int i = 0; i < a; i++) {
      sum_unif += log(runif(s)) / b;
    }
    if (isfinite(sum_unif)) {
      try = 6;
    }
  }

  return(-sum_unif);
}

float rigamma(uint *s, int a, float b) {
	return(1.0 / rgamma(s, a, b));
}

// Inverse-Chi2 densisty function
float dinvchi2(float x, float v, float tau2) {
	v = v / 2;
	return(
		pow((tau2 * v), v) / tgamma(v) * exp(-v * tau2 / x) / pow(x, (float)1.0 + v)
	);
}

float ldinvchi2(float x, float v, float tau2) {
	v = v / 2;
	return(
		v * (log(tau2) + log(v)) - lgamma(v) - v * tau2 / x - (1 + v) * log(x)
	);
}
