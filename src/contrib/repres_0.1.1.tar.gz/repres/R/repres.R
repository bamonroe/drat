#' @title Kickstart a reproducible research project
#' @description This function copies the primary file of the repres package into the current working directory.
#' The point here is that you should not depend on other people having this package
#' installed to make the code work, that would be the antithesis of the goal of this project.
#' After this file is copied locally, source it directly in your project so that it overwrites
#' the various base functions.
#' @param top_level the location where the R_library folder will be made
#' @export kickstart
kickstart <- function() {
  fname <- system.file("repres.R", package = "repres", mustWork = TRUE)
  file.copy(from = fname, to = getwd(), overwrite = TRUE)
}
