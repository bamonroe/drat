set_default <- function(cfg, name, value) {
  cn <- names(cfg)
  if (! name %in% cn) {
    cfg[[name]] <- value
  }
  cfg
}

get_nchains <- function(config) {
  chains <- sum(unlist(lapply(config$dlist, "[[", "work_items")))
}

check_config_terms <- function(config) {

  # Some terms are required in the config
  required_cfg <- c("draws", "fn", "dlist", "algo")
  check <- ! required_cfg %in% names(config)

  if (any(check)) {
    msg <- paste0("Some required config items are missing:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[! names(config) %in% required_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some terms are forbidden in the config
  forbidden_cfg <- c("nrows", "npar")
  if (any(names(config) %in% forbidden_cfg)) {
    msg <- paste0("Some config items are forbidden:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[names(config) %in% forbidden_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some names for the function are impermissible
  forbidden_fname <- c(
    "mhmc", "gibbs",
    "state",
    "dnorm", "ldnorm", "pnorm", "ierf", "qnorm", "rnorm",
    "lbeta", "ldbeta", "ldbeta_alt", "pbeta", "norm_to_lnorm",
    "dlnorm", "ldigamma")
  if (config$fn %in% forbidden_fname)
    stop("You can't name your function mhmc or gibbs")

}

check_init <- function(init, config) {

  # How many chains are being run
  chains <- get_nchains(config)
  chains_per_super      <- chains / config$super_chains
  chain_super_remainder <- chains %% config$super_chains

  if (chain_super_remainder != 0) {
    stop(paste(
      "The number of `work_items` needs to be a multiple of the number of `super_chains`.",
      "In `config$dlist` you have ", chains, " chains, but in `config$super_chains` you have",
      config$super_chains, ", thus a remainder of ", chain_super_remainder, "."
    ))
  }

  # The initial paramters need to be a list or numeric vector
  if (is.list(init)) {
    numeric_check <- all(unlist(lapply(init, is.vector, mode = "numeric")))
    finite_check  <- all(unlist(lapply(init, is.finite)))
    length_check  <- unlist(lapply(init, length))
    length_check  <- all(length_check[1] == length_check)
    schain_check  <- length(init) == config$super_chains

    if (!numeric_check) {
      stop("If `init` is a list, all elements must be numeric. Some were not.")
    }
    if (!length_check) {
      stop("If `init` is a list, all elements must be the same length. They are not.")
    }
    if (!finite_check) {
      stop("If `init` is a list, all elements must be finite numeric vectors. Some vectors have non-finite elements.")
    }
    if (!schain_check) {
      msg <- paste0(
        "If `init` is a list, it needs to be of the same length as the",
        " number of `config$super_chains`. `init` length is ", length(init),
        " and `config$super_chains` is ", config$super_chains, ".")
      stop(msg)
    }
    # Expand chains out
    init <- lapply(init, function(ii) rep(ii, chains_per_super))
    init <- unlist(init)

  } else if (is.vector(init, mode = "numeric")) {
    finite_check  <- all(is.finite(init))
    if (!finite_check) {
      stop("If `init` is a vector, all elements must be finite. Some elements were non-finite.")
    }
    # Expand the init vector for all chains
    init <- rep(init, chains)
  } else {
    stop("`init` needs to be a list of equal sized numeric vectors, or a numeric vector")
  }
  init

}

clean_config <- function(config, init, jump) {
  # Check that certain elements are in the config, some are not
  check_config_terms(config)
  # How many chains are being run
  chains <- get_nchains(config)
  # Some things are optional
  # Some optional things have requirements still
  # Which parameter to monitor in the output
  config <- set_default(config, "show_sd",    0)
  # The multiplier of the parameter standard deviation to get the jump vector
  config <- set_default(config, "sd_mult",    1)
  # How many times should the gibbs sampler loop on the device. Jump vector is not updated between runs, and only the values of the last run is saved.
  config <- set_default(config, "mcmc_runs",  1)
  # Keep every iteration that is a multiple of this number passed the skip iterations
  config <- set_default(config, "keep_every", 1)
  # This is the "warmup" iterations that aren't considered for collection
  config <- set_default(config, "skip",       100)
  # How many iterations to not apply the adaptive jump distribution
  config <- set_default(config, "burn_sd",    1)
  # Should the adaptive jump rule be applied to ALL iterations?
  config <- set_default(config, "adapt_all",  FALSE)
  # Should the adaptive jump rule be applied to NO iterations?
  config <- set_default(config, "adapt_none", FALSE)
  # Use the auto-burn rule to determine how long to warmup
  config <- set_default(config, "auto_burn",  FALSE)
  config <- set_default(config, "auto_lag",   100)
  config <- set_default(config, "auto_sig",   .05)
  # A list of constants to pass to the kernels
  config <- set_default(config, "constants",  list())
  config <- set_default(config, "super_chains", chains)

  config$chains <- chains

  # Check that the init argument is Fine
  init <- check_init(init, config)

  # We need to know the number of parameters often
  npar  <- length(init) / chains
  njump <- length(jump)

  # The jump and init vectors need to be the same size
  if (npar != njump) {
    stop("Initial parameters and Jump vector are not the same length")
  }

  config <- set_default(config, "batches", rep(1, npar))
  config <- set_default(config, "sampler", rep("mcmc", length(config$batches)))

  sbatch   <- sum(config$batches)
  nbatches <- length(config$batches)
  lsampler <- length(config$sampler)
  if (sbatch < npar) {
    stop("The specified batches vector sums to less than the total number of parameters")
  } else if (sbatch > npar) {
    stop("The specified batches vector sums to more than the number of parameters, you need to fix this.")
  }

  if (lsampler < nbatches) {
    stop("The specified sampler vector is smaller than the batches vector")
  } else if (lsampler > nbatches) {
    stop("The specified sampler vector is longer than the number of batches, you need to fix this.")
  }

  # we actually want a uint vector to pass around in C++
  config$sampler <- ifelse(config$sampler == "mcmc", 0, 1)
  # This needs to be 0-1
  config$adapt_all <- ifelse(config$adapt_all, 1, 0)

  # Some things need to be overwritten
  config$npar  <- npar
  config$constants[["NBATCHES"]] <- length(config[["batches"]])

  return(list(config = config, init = init))
}

code_creator <- function(config, kernel_code, dat, algo) {
  # Some names are going to be overwritten, just stop the user here. I could
  # warn them, but they shouldn't be doing this and probably don't mean to be.
  constants <- config$constants
  nc <- names(constants)
  reserved_constants <- c("NPAR", "MCMC_RUNS")
  if (any(nc %in% reserved_constants)) {
    msg <- paste0("The following names cannot be used as constants:\n")
    msg <- paste0(msg, paste(nc[nc %in% reserved_constants], collapse = ",\n"))
    stop(msg)
  }
  # Anyway, let's add a few more
  constants["NPAR"]      <- config$npar
  constants["MCMC_RUNS"] <- config$mcmc_runs

  # The kernel_code can be a file name
  if (file.exists(kernel_code)) {
    kernel_code <- get_file(kernel_code)
  }

  # Get the mhmc or gibbs file
  fname <- system.file(package = "rcocl", paste0("dists.c"))
  dists  <- readLines(fname)
  dists  <- paste(dists, collapse = "\n")

  # Generate the kernel code
  code <- c(
    # Make define statements
    make_defines(constants),
    # Add code for distributions
    dists,
    # Add in the user code,
    kernel_code,
    # Make the kernel code
    make_mcmc_kern(
      dat,
      config$fn,
      algo
    )
  )
  code <- paste(code, collapse = "\n\n")

  # Write out the file for debugging purposes
  fname <- "./full.c"
  fconn <- file(fname, open = "w")
  writeLines(text = code, con = fconn, sep = "")
  close(fconn)

  code
}

#' @title Run MCMC sampler on gpu
#' @param kernel_code The code, or file, for the kernel
#' @param config      A list of configuration items
#' @param init        The initial parameters
#' @param jump        The jump standard deviations
#' @param dat        Double precision data
#' @export gpu_mcmc
gpu_mcmc <- function(
  kernel_code,
  config,
  init,
  jump,
  dat
) {

  # Get a config with everythin we need
  clean_conf <- clean_config(config, init, jump)
  config <- clean_conf$config
  init   <- clean_conf$init

  # Get the code
  code <- code_creator(config, kernel_code, dat, algo = config["algo"])

  # Collect the samples
  out <- full_mcmc(
    kernel_code = code,
    config = config,
    init = init,
    jump = jump,
    dat = dat
  )

  # Name the output columns
  pnames <- names(init)[1:config$npar]
  stat_names <- c()
  for (pn in pnames) {
    stat_names <- c(stat_names, paste0(pn, c("_m", "_s", "_a")))
  }

  out[["stats"]] <- as.data.frame(out[["stats"]])
  colnames(out[["stats"]]) <- c("iter", "posterior_m", "posterior_s", stat_names)

  out[["samples"]] <- as.data.frame(out[["samples"]])
  colnames(out[["samples"]]) <- c("iter", "chain", "posterior", pnames)

  out
}
