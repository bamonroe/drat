#ifndef USEMEAN
#define USEMEAN 0
#endif

#ifndef BATCHMAX
#define BATCHMAX 10
#endif
#ifndef BATCH_TRIANGLE
#define BATCH_TRIANGLE (BATCHMAX * (BATCHMAX + 1) / 2)
#endif

void plot_lt(float* mat, int dim) {
  for (int row = 0; row < dim; row++) {
    for (int col = 0; col <= row; col++) {
      printf("%f ", mat[sym_index(row, col)]);
    }
      printf("\n");
  }
  printf("\n");
}
void plot_vec(float* mat, int dim) {
  for (int row = 0; row < dim; row++) {
    printf("%f ", mat[row]);
  }
  printf("\n");
}

void kernel gibbs (
  // first two args are mandatory
  global   float* post_out,
  global   float* par,
  global   uint*  rng_state,
  global   float* aux_mean,
  global   float* aux_invcov,
  global   float* aux_chol,
  global   float* aux_logdet,
  global   float* accept,
  constant uint*  batches,
  constant uint*  sample_type,
  // user args
  @@def_user_args@@
)
{
  // The id for this worker
  int gid  = get_global_id(0);
  // Initialize the rng state
  uint s = rng_state[gid];

  // The parameter vector for this model
  float pars[NPAR], ppars[NPAR], means[NPAR];
  for (int i = 0; i < NPAR; i++) {
    pars[i]  = par[gid * NPAR + i];
    ppars[i] = pars[i];
    means[i] = aux_mean[i];
  }

  // The acceptance rate for each parameter
  float avec[NPAR];
  for (int i = 0; i < NPAR; i++) {
    avec[i] = 0.0;
  }

  // Some algebra needs to happen to the proposed, so it happens here
  float final_proposed, final_current, resolve, ratio;

  // Keep track of the proposed and current prior and posterior
  float proposed, current;

  // Ensure we're dealing with real numbers here
  current = isnan(current) ? -FLT_MAX : current;

  float aavg = 0;
  float out_post;

  int accept_this = 0;
  int pari = 0;
  uint bpars = 0;
  uint stype = 0;

  int check = 0;

  float current_den = 0;
  float proposed_den = 0;
  float jump_adjust = 0;

  int cov_index = 0;


  BatchInfo binfo;
  // Some things are common to everything
  binfo.batches = batches;
  binfo.rng     = &s;

  for (int iter = 0; iter < MCMC_RUNS; iter++) {
    // This is Gibbs sampling with an embedded Metropolis Hastings algorithm
    // We do the embedded algorithm because we do not know if we can directly
    // sample from the conditional posterior, and so instead, we use the MH
    // algorithm to sample for us.

    out_post  = 0;
    cov_index = 0;

    // Iterate through every parameter, in order, and calculate successive
    // conditional distributions
    for (int batch = 0; batch < NBATCHES; batch++) {

      // The number of parameters in this batch
      bpars = batches[batch];
      // The type of sampling to be done
      stype = sample_type[batch];

      current  = 0.0;
      proposed = 0.0;

      binfo.pari    = pari;
      binfo.batch   = batch;
      binfo.bpars   = bpars;
      binfo.stype   = stype;

      // Use the metropolis algorithm
      if (stype == 0) {

        // Propose new values for the parameters in this batch
        jump_adjust = 0;

        #if USEMEAN > 0
        // Get the random values
        mvrnorm(&s, &means[pari], &aux_chol[cov_index], &ppars[pari], bpars);
        // Get the density of the current and proposed parameters
        current_den  = lmvdnorm_inv_det(&pars[pari],  &aux_mean[pari], &aux_invcov[cov_index], aux_logdet[batch], bpars);
        proposed_den = lmvdnorm_inv_det(&ppars[pari], &aux_mean[pari], &aux_invcov[cov_index], aux_logdet[batch], bpars);
        jump_adjust  = (current_den - proposed_den);
        #else
        // Get the random values
        mvrnorm(&s, &pars[pari], &aux_chol[cov_index], &ppars[pari], bpars);
        #endif

        binfo.pars    = pars;
        binfo.post    = &current;
        binfo.pptr    = &pars[pari];

        // Get the current value of the conditional posterior
        @@function_name@@ (
          &binfo,
          @@fn_user_args@@
        );

        binfo.pars    = ppars;
        binfo.post    = &proposed;
        binfo.pptr    = &ppars[pari];

        // Get the value of the proposed conditional posterior
        @@function_name@@ (
          &binfo,
          @@fn_user_args@@
        );
        // Take the difference
        ratio   = proposed - current;
        // Adjust for the denisty of the proposal distribution
        ratio += jump_adjust;
        // Get the min BEFORE exponentiation to avoid overflow
        ratio   = min((float) 0.0, ratio);
        // Get a random uniform variable to resolve the jump
        resolve = runif(&s);
        // And log it so we don't have to exponentiate the log-posterior ratio
        resolve = log(resolve);

        if (isfinite(proposed) && ratio > resolve) {
          // If we accept the proposed parameters, then reset pars to reflect it
          for (int i = 0; i < bpars; i++) {
            pars[pari + i] = ppars[pari + i];
            // The acceptance ratio for this batch
            avec[pari + i] += exp(ratio) / MCMC_RUNS;
          }
          // The rest of this is fluff
          out_post += proposed;
        } else {
          // If we don't accept the proposed parameters,
          // then reset the ppars to the original parameters
          for (int i = 0; i < bpars; i++) {
            ppars[pari + i] = pars[pari + i];
          }
          out_post += current;
        }
      } else {
        // If we're sampling directly
        binfo.pars = ppars;
        binfo.post = &proposed;
        binfo.pptr = &ppars[pari];
        @@function_name@@ (
          &binfo,
          @@fn_user_args@@
        );
        for (int i = 0; i < bpars; i++) {
          pars[pari + i] = ppars[pari + i];
          avec[pari + i] += 1.0;
        }
        out_post += current;
      }

      // Increment pari for the number of parameters in this batch
      pari += bpars;
      // Increment the index in the covariance vectors for the number of parameters in this batch
      cov_index += bpars * (bpars + 1) / 2;
    }
  }

  // reset the state
  rng_state[gid] = s;

  // Record the latest parameters and acceptance ratio
  for (int i = 0; i < NPAR; i++) {
    par[gid * NPAR + i] = pars[i];
    accept[gid * NPAR + i] = avec[i];
  }

  // Record the prior and likelihood separately
  post_out[gid] = out_post;
}

// The user can specify a batchsize
#ifndef ADDBATCHSIZE
#define ADDBATCHSIZE 1024
#endif

void kernel calc_mean (
  // first two args are mandatory
  global   float* par,
  global   float* aux_mean,
  global   float* accept,
  constant uint*  parinfo,
  uint dev_chains
)
{
  // The id for this worker
  int pari  = get_global_id(0);
  float par_mean = 0;
  float accept_mean = 0;

  // Batch add the pars together to try and decrease the loss of precision
  int parnum = parinfo[0];
  int chains = parinfo[1];

  float tmp0 = 0, tmp1 = 0;
  int chains_done = 0;
  int runsize = 0;
  int index;

  while (chains_done < dev_chains) {

    // If there are more than ADDBATCHSIZE chains left, run ADDBATCHSIZE chains, else do the balance
    runsize = (dev_chains - chains_done) >= ADDBATCHSIZE ? ADDBATCHSIZE : (dev_chains - chains_done);

    tmp0 = 0;
    tmp1 = 0;
    for (int i = 0; i < runsize; i++) {
      index = pari + (chains_done + i) * parnum;
      tmp0  += par[index] / (float)chains;
      tmp1  += accept[index] / (float)chains;
    }

    par_mean += tmp0;
    accept_mean += tmp1;
    chains_done += ADDBATCHSIZE;
  }

  //printf("pari %d, parnum: %d, chains: %d, mean: %f, index %d\n", pari, parnum, chains, par_mean, index);
  aux_mean[pari] = par_mean;
  accept[pari] = accept_mean;
}

void get_row_col(int index, int *row, int *col) {
  index = index + 1;
  *row = ceil(sqrt(2 * index + .25) - .5) - 1;
  *col = index - (*row) * (*row + 1) / 2 - 1;
}

void kernel calc_cov (
  // first two args are mandatory
  global   float* par,
  global   float* aux_invcov,
  constant uint*  batches,
  constant uint*  parinfo,
  uint dev_chains
)
{
  // The id for this worker
  int gid = get_global_id(0);
  // Since we have batches, we need to find the index of this worker in the full
  // aux_cov vector, which includes all batches
  int batch = 0;
  // This is the index in the correct triangle for this worker
  int index = gid;
  int thisbatch = batches[batch] * (batches[batch] + 1) / 2;
  int startpar = 0;
  while (index >= thisbatch) {
    // The right hand side is the size of the lower triangle for batch i
    index -= thisbatch;
    startpar += batches[batch];
    batch++;
    thisbatch = batches[batch] * (batches[batch] + 1) / 2;
  }

  // how many pars are there and how many TOTAL chains (dev_chains is the number of chains on this device)
  int parnum = parinfo[0];
  int chains = parinfo[1];

  // Get the row and column in the covariance matrix implied by this worker ID
  int row, col;
  get_row_col(index, &row, &col);

  float cov = 0;

  float tmp = 0;
  int chains_done = 0;
  int runsize = 0;
  int index0, index1;

  while (chains_done < dev_chains) {

    // If there are more than ADDBATCHSIZE chains left, run ADDBATCHSIZE chains, else do the balance
    runsize = (dev_chains - chains_done) >= ADDBATCHSIZE ? ADDBATCHSIZE : (dev_chains - chains_done);

    tmp = 0;
    for (int i = 0; i < runsize; i++) {

      index0 = startpar + row + (chains_done + i) * parnum;
      index1 = startpar + col + (chains_done + i) * parnum;

      tmp += (par[index0] * par[index1]);
    }

    tmp = tmp / (float)(chains);

    cov += tmp;
    chains_done += ADDBATCHSIZE;
  }

  //printf("gid %d, batch %d, parnum %d, chains %d, dev_chains %d, index %d, startpar %d, row %d, col %d, cov: %f, index0: %d, index1: %d\n", gid, batch, parnum, chains, dev_chains, index, startpar, row, col, cov, index0, index1);

  aux_invcov[gid] = cov;
}
