#ifndef maindef
#include "main.hpp"
#endif

OclHandler::OclHandler(List &dev, String &code)
{
  // The current platform
  List plist;
  // The vector of device numbers for this platform
  std::vector<int> dnum;
  // A struct to hold the info per-platform
  ocl_pairs pair;


  pairs = std::vector<ocl_pairs>(dev.length());

  for (int i = 0; i < (int)dev.length(); i++)
  {
    plist = dev[i];
    // Get the platform number
    pair.pnum = plist["plat_num"];
    // Get the vector of devices
    pair.dnum.push_back(plist["dev_num"]);
    // Get the number of wokers for each device
    pair.work_items.push_back(plist["work_items"]);
    // Add to vector
    pairs[i] = pair;

    pair.dnum.clear();
    pair.work_items.clear();
  }

  // Add the kernel code to the sources
  std::string kcode = code.get_cstring();
  sources.push_back({kcode.c_str(), kcode.length()});
  // Get all platforms (drivers)
  cl::Platform::get(&platforms);
  if (platforms.size() == 0)
  {
    Rcout <<" No platforms found. Check OpenCL installation!" << std::endl;
    exit(1);
  }

  // Initialize the all devs vector size
  // This is the vector of devices we're compiling for, not all that exist
  all_devs = std::vector<std::vector<cl::Device>>(pairs.size());
  // Initialize the total work items to 0
  totalwi = 0;

  // Loop through all the Device pairs
  for (int i = 0; i < (int)pairs.size(); i++)
  {
    // Pointer to the i'th platform we care about
    cl::Platform *plat = &platforms[pairs[i].pnum];
    plat->getDevices(CL_DEVICE_TYPE_ALL, &all_devs[i]);

    // Every device passed as this list should exist, it's an error if it doesn't
    if (all_devs[i].size() == 0)
    {
      Rcout << "No devices found for platform "
        << pairs[i].pnum
        << ". Check OpenCL installation!"
        << std::endl;
      exit(1);
    }

    // Get the pointers to the devices we'll actually use
    // And create individual contexts with them
    int n, k, w;
    for (int j = 0; j < (int)pairs[i].dnum.size(); j++)
    {
      // Get the device number for this platform
      k = pairs[i].dnum[j];
      // Get the number of work items for this device
      w = pairs[i].work_items[j];
      // Add this to the device specific vector
      work_items.push_back(w);
      // And add to the total work item count
      totalwi += w;
      // Hanging on to the pointers
      devices.push_back(&all_devs[i][k]);
      // How big is this list now?
      n = devices.size() - 1;
      // The individual contexts
      contexts.push_back(
        cl::Context({*devices[n]})
      );

      // Compile the program
      programs.push_back(
        cl::Program(
          contexts[n],
          sources)
      );

      int build_code = programs[n].build();
      if (build_code != CL_SUCCESS)
      {
        Rcout << "Error building for platform " << i << " device " << k << std::endl;
        Rcout << "Error Code: " << build_code << std::endl;

        std::string buildlog = programs[n].getBuildInfo<CL_PROGRAM_BUILD_LOG>(*devices[n]);
        Rcout << buildlog << std::endl;
        exit(1);
      } else {
        Rcout << "Kernel built successfully." << std::endl;
        Rcout << "Build Log" << std::endl;
        std::string buildlog = programs[n].getBuildInfo<CL_PROGRAM_BUILD_LOG>(*devices[n]);
        Rcout << buildlog << std::endl;
      }
      // Make the queue for this device
      queues.push_back(
        cl::CommandQueue(contexts[n], *devices[n])
      );
    }
  }

  // Wrapping up
  // How many devices do we have?
  ndev = devices.size();
  // Make the vector of kernsl
  kernels = std::vector<cl::Kernel>(ndev);
}

void OclHandler::finish()
{
  for (int i = 0; i < this->ndev; i++)
  {
    this->queues[i].finish();
  }
}

void OclHandler::run_kernel(std::string kernel_name)
{
  // Loop through all the devices
  for (int i = 0; i < this->ndev; i++)
  {
    // Run the kernel
    this->kernels[i] = cl::Kernel(this->programs[i], kernel_name.c_str());
    for (int j = 0; j < (int)buffers[i].size() ; j++)
    {
      this->kernels[i].setArg(j, buffers[i][j]);
    }
    this->queues[i].enqueueNDRangeKernel(this->kernels[i],
                                         cl::NullRange,
                                         cl::NDRange(this->work_items[i]),
                                         cl::NullRange);
  }
}

int OclHandler::bnum()
{
  return(this->buffers[0].size());
}

int OclHandler::bi()
{
  return(bnum() - 1);
}
