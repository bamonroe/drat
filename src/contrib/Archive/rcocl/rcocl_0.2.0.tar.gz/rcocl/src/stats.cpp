// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

Stats::Stats(List config, int ncols)
{
  // If this is 1, start collecting samples
  this->collect_signal = 0;

  // Minimum number of iterations
  int skip = config["skip"];

  // Are we burning using the regression approach or with a set number of
  // iterations
  this->auto_burn = config["auto_burn"];
  // How big is the regression lag
  this->auto_lag  = config["auto_lag"];
  // What significance level to use in the testing
  this->auto_sig  = config["auto_sig"];

  // How many columns are being used?
  this->ncols  = ncols;
  this->buffer = std::vector<rtype>(ncols);

  // Keep track of lots of things for the regression approach
  this->index  = 0;

  // Sign of the beta coefficient
  this->bhat_sign[0] = 0;
  this->bhat_sign[1] = 0;

  // Minimum number of iterations
  this->iter_min = this->auto_burn ? std::max(this->auto_lag, skip) : skip;

  // Linear model vectors
  this->lm_x  = arma::vec(this->auto_lag);
  this->lm_y0 = arma::vec(this->auto_lag);
  this->lm_y1 = arma::vec(this->auto_lag);
  // Linear model predictions
  this->par_pred[0] = 0;
  this->par_pred[1] = 0;
  this->par_pred[2] = 0;

  // Actual data being stored and saved
  std::vector<std::vector<rtype>> j;
  this->data = j;
}

void Stats::check_collect()
{
  if (this->auto_burn) {
    this->reg();
  } else {
    // If we're not auto-burning, then after the minimum iterations are met,
    // start collecting
    this->collect_signal = this->data.size() < this->iter_min ? 0 : 1;
  }
}

void Stats::add(rtype val)
{
  // Assign the value to the relevent position in the index
  this->buffer.at(this->index) = val;
  // Increment the buffer index
  this->index++;

  // If we've reached the last column, reset the index, and push the row
  if (this->index >= this->ncols) {
    // Index reset
    this->index = 0;
    // Push the buffer
    this->data.push_back(this->buffer);
  }
}

rtype Stats::get(int col)
{
  return this->data.back().at(col);
}

NumericMatrix Stats::to_mat()
{
  NumericMatrix out(this->data.size(), this->ncols);
  for (int row = 0; row < this->data.size(); row++) {
    for (int col = 0; col < this->ncols; col++) {
      out.at(row, col) = this->data.at(row).at(col);
    }
  }
  return out;
}

void Stats::reg()
{
  // Some early returns to avoid computation
  if (this->collect_signal == 1) {
    return;
  }
  int iter = this->data.size();
  // We don't do regression unless we have more than auto_lag elements
  if (iter < this->auto_lag) return;

  // We're regressing 2 terms against iterations
  int term0 = 1;
  int term1 = 2;

  if (iter == this->auto_lag) {
    for (int i = 0; i < this->auto_lag; i++) {
      this->lm_y0.at(i) = this->data.at(i).at(term0);
      this->lm_y1.at(i) = this->data.at(i).at(term1);
      this->lm_x.at(i) = i;
    }
  }

  // Fill in the new data, after much pain, I'm confident this is correct
  int i = (iter - 1) % this->auto_lag;
  this->lm_y0.at(i) = this->data.at(iter - 1).at(term0);
  this->lm_y1.at(i) = this->data.at(iter - 1).at(term1);
  this->lm_x.at(i) = iter - 1;

  // Averages of some variables
  rtype xbar  = arma::mean(this->lm_x);
  rtype y0bar  = arma::mean(this->lm_y0);
  rtype y1bar  = arma::mean(this->lm_y1);

  arma::vec x2 = arma::pow(this->lm_x, 2.0);
  arma::vec y02 = arma::pow(this->lm_y0, 2.0);
  arma::vec y12 = arma::pow(this->lm_y1, 2.0);

  // The estimate of the coefficient on x
  arma::mat bhat00 = arma::cor(this->lm_x, this->lm_y0) * arma::stddev(this->lm_y0) / arma::stddev(this->lm_x);
  arma::mat bhat10 = arma::cor(this->lm_x, this->lm_y1) * arma::stddev(this->lm_y1) / arma::stddev(this->lm_x);
  rtype bhat0 = bhat00.at(0, 0);
  rtype bhat1 = bhat10.at(0, 0);

  // The estimate of the intercept
  rtype ahat0 = y0bar - bhat0 * xbar;
  rtype ahat1 = y1bar - bhat1 * xbar;

  // Error term
  arma::vec ehat0    = this->lm_y0 - ahat0 - bhat0 * this->lm_x;
  arma::vec ehat1    = this->lm_y1 - ahat1 - bhat1 * this->lm_x;

  arma::vec ehat20 = arma::pow(ehat0, 2.0);
  rtype ehat02     = arma::accu(ehat20) / ((rtype)this->auto_lag - 2.0);

  ehat20           = arma::pow(ehat1, 2.0);
  rtype ehat12     = arma::accu(ehat20) / ((rtype)this->auto_lag - 2.0);

  arma::vec xmbar0 = this->lm_x - xbar;
  xmbar0           = arma::pow(xmbar0, 2.0);
  rtype xmbar      = arma::accu(xmbar0);

  // The standard deviation of the error term
  rtype sb0 = (ehat02 ) / xmbar;
  rtype sb1 = (ehat12 ) / xmbar;

  sb0 = std::sqrt(sb0);
  sb1 = std::sqrt(sb1);

  // The student's t value
  rtype tval0 = std::abs(bhat0) / sb0;
  rtype tval1 = std::abs(bhat1) / sb1;

  // The 2-sided probability of that value
  rtype p0 = 0.5 * Rf_pt(tval0, this->auto_lag - 2, 0, 0);
  rtype p1 = 0.5 * Rf_pt(tval1, this->auto_lag - 2, 0, 0);

  // What's the sign of this estimate
  int bh_positive[2] = {bhat0 > 0 ? 1 : 0, bhat1 > 0 ? 1 : 0};

  // Is this a sign change from the previous bhat?
  bool sign_change[2] = {
    bh_positive[0] != this->bhat_sign[0],
    bh_positive[1] != this->bhat_sign[1]
  };

  this->bhat_sign[0] = bh_positive[0];
  this->bhat_sign[1] = bh_positive[1];

  rtype pred0 = ahat0 + bhat0 * this->auto_lag / 2;
  rtype pred1 = ahat1 + bhat1 * this->auto_lag / 2;

  this->par_pred[0] = pred0 - 1.959964 * pred1;
  this->par_pred[1] = pred0;
  this->par_pred[2] = pred0 + 1.959964 * pred1;

  Rcout << "\tbhat0: " << bhat0 << "\tp0: " << p0 << std::endl;
  Rcout << "\tbhat1: " << bhat1 << "\tp1: " << p1 << std::endl;

  // If the sign changed from the previous 
  bool pbig  = (p0 > this->auto_sig) & (p1 > this->auto_sig);
  bool signc = sign_change[0] & sign_change[1];
  signc = true;
  bool iterl = iter > this->iter_min;

  if (pbig & signc & iterl) {
    this->collect_signal = 1;
  } 

}
