// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <CL/opencl.hpp>
using namespace Rcpp;

#define maindef
//#define rtype cl_float
typedef cl_float rtype;

typedef NumericVector nvec;
typedef NumericMatrix nmat;

template <typename T> class Ovec;
class OclHandler;

uint64_t timeSinceEpochMillisec();

struct bconf
{
  int NPARS;
  int CHAINS;
  int BURNSD;
  int ADAPT_ALL;
  int ADAPT_NONE;
};

struct ravg
{
  rtype ratio;
  int n;
  int N;
};

struct ocl_pairs
{
  int pnum;
  std::vector<int> dnum;
  std::vector<int> work_items;
};

struct buffer_parameters {
  int size;
  int  nelem;
  bool per_chain;
};

class OclHandler {
private:
  std::vector<ocl_pairs>               pairs;
  std::vector<cl::Platform>            platforms;
  std::vector<std::vector<cl::Device>> all_devs;
  std::vector<cl::Device*>             devices;
  cl::Program::Sources                 sources;
  std::vector<buffer_parameters>       buf_params;
  int buf_num;

  // Functions to get pointers dynamically
  template <typename T> T* get_ptr(Ovec<T>& in, int d) {return (in.getv(d));}
  template <typename T> T* get_ptr(T* in, int d)       {return (in);}

  // Functions to get sizes for read/writing to buffers dynamically
  template <typename T> T get_size(Ovec<T>& in) {return (sizeof(T));}
  template <typename T> T get_size(T* in)       {return (sizeof(T));}
 
  // Functions to buffer numbers for read/writing to buffers dynamically
  template <typename T> int get_buffno(Ovec<T>& in, int buffno = -1) {return (in.buffno);}
  template <typename T> int get_buffno(T* in, int buffno = -1)       {return (buffno);}


public:
  std::vector<std::vector<cl::Buffer>> buffers;
  std::vector<std::vector<uint>>       buffers_nelem;
  std::vector<cl::Context>             contexts;
  std::vector<cl::CommandQueue>        queues;
  std::vector<cl::Program>             programs;
  std::vector<cl::Kernel>              kernels;
  std::vector<int>                     work_items;
  int                                  ndev;
  int                                  totalwi;
  OclHandler(List &dev, String &code);
  void finish();
  void run_kernel(std::string kernel_name);
  int bnum();
  int bi();

  template <typename T>
  void make_buffer(int cl_mem, int nelem, bool per_chain)
  {
    // Some are ints, some are doubles
    int size = sizeof(T);

    // Instantiate the buffers vector if it doesn't already exist
    if ((int)this->buffers.size() != this->ndev) {
      for (int d = 0; d < this->ndev; d++)
      {
        this->buffers.push_back(std::vector<cl::Buffer>());
        this->buffers_nelem.push_back(std::vector<uint>());
      }
    }

    int twi;
    for (int d = 0; d < this->ndev; d++)
    {
      // Some buffers need dev-specific sizes
      twi = (per_chain ? this->work_items[d] : 1) * nelem;
      // Make the buffer
      this->buffers[d].push_back(
        cl::Buffer(this->contexts[d], cl_mem, size * twi)
      );
      // Record how many elements are in this buffer
      this->buffers_nelem[d].push_back(
        twi
      );
    }

    // Saving the buffer parameters for reading/writing
    buffer_parameters bp = {
      size,
      nelem,
      per_chain
    };
    this->buf_params.push_back(bp);
  }

  template <typename T>
  void read_buffer(T out, int bnum = -1)
  {
    // If we're passing in an Ovec, it already has a buffer number carried around
    bnum = get_buffno(out, bnum);

    int twi;
    int size = this->buf_params[bnum].size;

    for (int d = 0; d < this->ndev; d++)
    {
      // Some buffers need dev-specific sizes
      twi = this->buffers_nelem[d].at(bnum);
      this->queues[d].enqueueReadBuffer(
        this->buffers[d][bnum],
        CL_FALSE,
        0,
        twi * size,
        get_ptr(out, d)
      );
    }
  }

  template <typename T>
  void write_buffer(T in, int bnum = -1)
  {
    // If we're passing in an Ovec, it already has a buffer number carried around
    bnum = get_buffno(in, bnum);

    int twi;
    int size = this->buf_params[bnum].size;

    for (int d = 0; d < this->ndev; d++)
    {
      // Some buffers need dev-specific sizes
      twi = this->buffers_nelem[d].at(bnum);
      // Actually do the writing
      this->queues[d].enqueueWriteBuffer(
        this->buffers[d][bnum],
        CL_FALSE,
        0,
        twi * size,
        get_ptr(in, d)
      );
    }
  }
};

template <typename T>
class Ovec {
private:
  // The vector of vectors that will hold the actual values
  // The outer vector is per-device, the inner vector needs to be written to the
  // device in one go. Individual chains are all reading from one big buffer
  std::vector<std::vector<T>> val;
  // Keep track of the pointer to the handler
  const OclHandler *ocl;
  // Do we multiply per chain
  bool per_chain;
  // The number of elements
  int elem_per_chain;

public:
  // This is to keep track of which buffer this belongs to
  int buffno;

  Ovec(const OclHandler *ocl_in, int pos)
  {
    // keep track of the pointer and multiplier
    ocl = ocl_in;
    buffno = pos;

    // The position is relative to the buffer that was already made,
    // which is stored in buffers vector of the ocl handler object. The number
    // of elements in each buffer is also stored there, so we grab it here
    uint nelem; 

    // Initialize 'val'
    for (int d = 0; d < ocl->ndev; d++)
    {
      nelem = ocl->buffers_nelem.at(0).at(pos);
      val.push_back(std::vector<T>(nelem));
    }
  }

  // Get the pointer the position in the correct vector that corresponds
  // to work item 'wi'
  T* geti(int wi)
  {
    int w = 0, i;
    // Loop over the different devices
    for (i = 0; i < ocl->ndev; i++)
    {
      // Accumulate the number of work items for each device
      w += ocl->work_items[i];
      // If the work item 'wi' is less than the accumulated work
      // items, then it exists in device 'i'. Also, if we subtract
      // the latest device's work items from 'w', then we have the index of the first
      // work item for device 'i'. 'wi' minus this number times the multiplier is the
      // position in the i'th val vector of work item 'wi'.
      if (wi < w)
      {
        w -= ocl->work_items[i];
        break;
      }
    }
    // Return a pointer in the correct vector for the beginning of work item 'wi'
    return &val[i][(wi - w) * elem_per_chain];
  }

  // Get the pointer the position in the correct vector that corresponds
  // to work item 'wi'
  T at(int wi)
  {
    return(*geti(wi));
  }

  // Get the pointer the position in the correct vector that corresponds
  // to work item 'wi'
  T at(int di, int wi, int i)
  {
    return(val[di][wi * elem_per_chain + i]);
  }

  // Get the pointer to the beginning of the vector associated with device 'di'
  T* getv(int di)
  {
    return &val[di][0];
  }
  // Get the pointer to the beginning of the vector associated with device 'di'
  T* begin(int di)
  {
    return &val[di].front();
  }
  // Get the pointer to the beginning of the vector associated with device 'di'
  T* end(int di)
  {
    return &val[di].back();
  }
};

class Stats {
private:
  int bhat_sign[2];
  int iter_min;

  bool auto_burn;
  int  auto_lag;
  rtype auto_sig;

  int n;
  int index;
  arma::vec lm_x;
  arma::vec lm_y0;
  arma::vec lm_y1;

  std::vector<rtype> buffer;
  std::vector<std::vector<rtype>> data;
  void reg();
public:
  int collect_signal;
  int ncols;

  rtype par_pred[3];

  Stats(List config, int ncol);
  void add(rtype val);
  rtype get(int col);
  NumericMatrix to_mat();
  void check_collect();
};
