// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <CL/opencl.hpp>
#include <unistd.h>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

#define __CL_ENABLE_EXCEPTIONS

using namespace Rcpp;

// There are key vectors of values that need to be carried around, we
// store them in a struct
struct Odata {
  Ovec<rtype> post;
  // The array for the parameters
  Ovec<rtype> par;
  // The arrays for the RNG states
  Ovec<cl_uint> rng;
  // The arrays for the mean pars
  Ovec<rtype> aux_mean;
  // The arrays for the standard deviation pars
  Ovec<rtype> aux_sd;
  // The arrays for the rejection statistics
  Ovec<rtype> accepts;
  // The arrays for the batch info
  Ovec<cl_uint> batches;
  // The arrays for the sampling type
  Ovec<cl_uint> stype;
};

void showme(
  Odata &odat,
  OclHandler &ocl,
  bconf &cfg,
  int p
){
  rtype v;
  for (int d = 0; d < ocl.ndev ; d++) {
    for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
      v = odat.par.at(d, wi, p);
      // Increment the work item counter
      if (!std::isfinite(v)) {
        Rcout << "d: " <<d << " wi: " << wi << " par: " << v  << std::endl;
      }
    }
  }
}

void fmcmc_display(
  Stats &stats,
  bconf &cfg,
  int iter,
  int citer,
  List config
) {

  int show_sd = config["show_sd"];
  int ikeep = config["keep_every"];

  // The posterior
  rtype post   = stats.get(1);
  rtype par    = stats.get(3 + 3 * show_sd);
  rtype sd     = stats.get(3 + 3 * show_sd + 1);
  rtype accept = stats.get(3 + 3 * show_sd + 2);

  if ((citer >= 0) & (citer % ikeep == 0)) {
    Rcout  << "**";
  } else {
    Rcout  << "@@";
  }

  Rcout  
    << "iter: "    << std::left << std::setw(6) << iter
    << " post: "   << std::left << std::setw(10) << post
    << " par["     << show_sd << "]: " << std::left << std::setw(10) << par
    << " sd["      << show_sd << "]: " << std::left << std::setw(10) << sd
    << " accept: " << std::left << std::setw(10) << accept
    << std::endl;

  if ((stats.collect_signal > 0) & (citer < 0)) {
    Rcout << "\n** Start Collecting" << std::endl;
    //Rcout <<   "** 95% Posterior Prediction (assuming normality):" << std::endl;
    //Rcout <<   "**          92.5%           Est.              97.5%" << std::endl;
    //Rcout <<   "** " << std::setw(14) << stats.par_pred[0] << " "
    //  << std::setw(14) << stats.par_pred[1] << " "
    //  << std::setw(14) << stats.par_pred[2] << "\n" << std::endl;
  }

}

void collect_samples(
  Odata &odat,
  List  &config,
  NumericMatrix &samples,
  OclHandler &ocl,
  int iter,
  int citer,
  int &draws_collected
)
{

  // Keep every ikeep iterations
  int ikeep = config["keep_every"];
  // The number of chains
  int chains = config["chains"];
  // The number of parameters
  int npar = config["npar"];

  // If we're not in an ikeep iteration, just skip ahead
  if (citer % ikeep != 0) {
    return;
  }

  // Incrememnt the number of draws collected;
  draws_collected++;

  rtype *post_p, *par_i;

  // The row of the datset
  int rnum = (citer / ikeep) * chains;

  int irow = 0;
  int chain = 0;
  // Assign the chosen pars to the full sample
  for (int d = 0; d < ocl.ndev ; d++) {
    post_p = odat.post.getv(d);
    par_i  = odat.par.getv(d);
    for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
      // First the iteration
      samples.at(rnum + irow, 0) = iter;
      // Second the chain
      samples.at(rnum + irow, 1) = chain;
      // Third the posterior
      samples.at(rnum + irow, 2) = *post_p;
      for (int p = 0; p < npar; p++) {
        // Save the parameters
        samples.at(rnum + irow, 3 + p) = *par_i;
        par_i++;
      }
      irow++;
      post_p++;
      chain++;
    }
  }

}

float cond_norm(float data_mean, float cond_sd, int n) {
  // This isn't the whole formula. This assumes a prior mean of 0, and a prior
  // standard deviation approaching Inf. This is an improper prior, but Gelman
  // shows this still results in a proper posterior.
  return Rf_rnorm(data_mean, cond_sd / (float)n);
}

float cond_igamma(float data_mean, float cond_sd, int n) {
  // this also improperly sets alpha and beta prior parameters to 0
  float out = Rf_rgamma((float)n / 2, 1 / ((float)n * cond_sd / 2));
  out = std::sqrt(out);
  return out;
}

void fmcmc_calc(
  Odata &odat,
  bconf &cfg,
  NumericMatrix &samples,
  int iter,
  OclHandler &ocl,
  Stats &stats,
  std::vector<rtype> &m1,
  std::vector<rtype> &m2,
  std::vector<rtype> &a1,
  List config
){

  rtype *par_i, *rej_i, *post_i;

  // For variance I'm using the formula
  // E(X^2) - E(X)^2
  // E(X)   is m1
  // E(X^2) is m2
  // I could multiply this by CHAINS / (CHAINS - 1) for the degrees of
  // freedom correction, but since I typically have CHAINS > 1000, this is
  // a really small correction

  // Set m1, m2, and accept to 0
  std::fill(m1.begin(), m1.end(), 0);
  std::fill(m2.begin(), m2.end(), 0);
  std::fill(a1.begin(), a1.end(), 0);

  // Average posterior
  rtype post0 = 0;
  rtype post1 = 0;
  rtype post2 = 0;

  // Work item counter
  for (int d = 0; d < ocl.ndev ; d++) {
    par_i  = odat.par.getv(d);
    rej_i  = odat.accepts.getv(d);
    post_i = odat.post.getv(d);
    for (int wi = 0; wi < ocl.work_items[d] ; wi++) {

      post0  = *post_i;
      post1 += post0 / cfg.CHAINS;
      // This is equivalent to post0 * post0 / cfg.CHAINS but more numerically stable
      post2 += exp(2 * log(post0) - log(cfg.CHAINS));

      post_i++;

      for (int p = 0; p < cfg.NPARS; p++) {
        // Between chain mean and variance parameters
        // over all chains, this is the mean
        m1.at(p) += *par_i / cfg.CHAINS;
        // over all chains, this is the mean of par^2, which can be used to calculate variance
        m2.at(p) += (*par_i * *par_i) / cfg.CHAINS;
        // acceptance rate over all chains
        a1.at(p) += *rej_i / cfg.CHAINS;

        // Increment the iterators
        par_i++;
        rej_i++;
      }
    }
  }

  // Update jump after the burn_sd
  rtype sd_mult = config["sd_mult"];
  rtype bvar;

  // Save the iteration
  stats.add(iter);
  // Save the average posterior
  stats.add(post1);
  // Save the standard dev of the posteriors
  post2 = sqrt(post2 - (post1 * post1));
  stats.add(post2);

  for (int p = 0; p < cfg.NPARS; p++) {
    // Between_chain variance
    m2.at(p) -= (m1.at(p) * m1.at(p));
    m2.at(p) = sqrt(m2.at(p));
    bvar = m2.at(p);

    // Save the mean of this parameter
    stats.add(m1.at(p));
    // Save the standard dev of this parameter
    stats.add(m2.at(p));
    // Save the acceptance rate of this parameter
    stats.add(a1.at(p));

    if (!std::isfinite(bvar)) {
      Rcout << "Non-finite between variance:" << std::endl;
      Rcout << " p: " << p  << std::endl;
      Rcout << "bvar: " << m2.at(p) - (m1.at(p) * m1.at(p)) << std::endl;
      Rcout << "m1 " << m1.at(p) << std::endl;
      Rcout << "m2 " << m2.at(p) << std::endl;
      showme(odat, ocl, cfg, p);
      std::exit(1);
    }
  }

  // There are several configurations that control whether we adaptively update the jump vector.
  // It can always be ON with 'ADAPT_ALL'
  // It can always be OFF with 'ADAPT_NONE'
  // It can be on, but only after BURNSD has passed, and you are not collecting samples
  if (
      ((iter >= cfg.BURNSD && stats.collect_signal == 0) || (cfg.ADAPT_ALL == 1)) &&
      (! cfg.ADAPT_NONE)
    ) {
    /*
    // Is the posterior more than SS standard deviations away from the mean? Wipe the chain.
    float SS = 10.0;
    for (int d = 0; d < ocl.ndev ; d++) {
      par_i  = odat.par.getv(d);
      post_i = odat.post.getv(d);
      for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
        post0  = *post_i;
        if (abs(post0 - post1) > (SS * post2) || std::isnan(post0)) {
          Rcout << "\npost0 " << post0 << " post1 " << post1 << " post2 " << post2 << std::endl;
          Rcout << "Work item " << wi << " of dev " << d << " is being wiped" << std::endl;
          *post_i = -FLT_MAX;
          for (int p = 0; p < cfg.NPARS; p++) {
            *par_i = m1.at(p);
            par_i++;
          }
        } else {
          par_i += cfg.NPARS;
        }
        post_i++;
      }
    }
    // Write the par buffer
    ocl.write_buffer<Ovec<rtype>&>(odat.post);
    ocl.write_buffer<Ovec<rtype>&>(odat.par);
    ocl.finish();
    */

    rtype *aux_sd, *aux_mean;
    for (int d = 0; d < ocl.ndev ; d++) {
      aux_mean = odat.aux_mean.getv(d);
      aux_sd   = odat.aux_sd.getv(d);
      for (int p = 0; p < cfg.NPARS; p++) {
        // Adjust this by a scaling factor to keep acceptance rates in a good range
        *aux_mean = m1.at(p);
        *aux_sd   = m2.at(p) * sd_mult;

        aux_mean++;
        aux_sd++;
      }
    }
    // Write the jump buffer
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_mean);
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_sd);
    ocl.finish();
  }
}

Odata ocl_setup(
  OclHandler    &ocl,
  bconf         &cfg,
  List          &dat,
  NumericVector &init,
  NumericVector &init_mean,
  NumericVector &init_sd,
  IntegerVector &batches,
  IntegerVector &sampling_type
) {

  // Add the posterior column
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, 1, true);
  // Add column for parameters
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, cfg.NPARS, true);
  // Add column to hold the state for RNG
  ocl.make_buffer<cl_uint>(CL_MEM_READ_WRITE, 1, true);
  // Add column for the mean of the proposal distributions
  ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, cfg.NPARS, false);
  // Add column for the standard deviation of the proposal distributions
  ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, cfg.NPARS, false);
  // Add column to hold the average rejection states
  ocl.make_buffer<rtype>(CL_MEM_WRITE_ONLY, cfg.NPARS, true);
  // Add column to hold the batch infamtion 
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, batches.length(), false);
  // Add column to hold the sampling type infamtion
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, sampling_type.length(), false);

  // Write in the data
  List ddat, idat;

  NumericVector dvec;
  IntegerVector ivec;

  ddat = dat["double"];
  idat = dat["int"];

  for (int i = 0; i < ddat.length(); i++) {
    // Get the List item into vectors
    dvec = ddat[i];
    std::vector<rtype> double_vec (dvec.begin(), dvec.end());

    ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, double_vec.size(), false);
    ocl.write_buffer<rtype*>(double_vec.data(), ocl.bi());
    ocl.finish();
  }

  for (int i = 0; i < idat.length(); i++) {
    // Get the List item into vectors
    ivec = idat.at(i);
    ocl.make_buffer<cl_int>(CL_MEM_READ_ONLY, ivec.length(), false);
    ocl.write_buffer<cl_int*>(ivec.begin(), ocl.bi());
    ocl.finish();
  }

  // This struct will carry around these ovecs and be returned from this
  // setup function
  Odata odat = {
    // Set the array that will hold the posterior
    Ovec<rtype>(&ocl, 0),
    // The arrary for the parameters
    Ovec<rtype>(&ocl, 1),
    // The arrays for the RNG states
    Ovec<cl_uint>(&ocl, 2),
    // The arrays for the mean parameters
    Ovec<rtype>(&ocl, 3),
    // The arrays for the sd parameters
    Ovec<rtype>(&ocl, 4),
    // The arrays for the rejection statistics
    Ovec<rtype>(&ocl, 5),
    // The arrays for the batch info
    Ovec<cl_uint>(&ocl, 6),
    // The arrays for the sampling type
    Ovec<cl_uint>(&ocl, 7)
  };

  // Initialize the parameter vector
  rtype   *post_init, *par_init, *mean_init, *jump_init, *rej_init;
  cl_uint *rng_init, *batch_init, *stype_init;

  int counter = 0;
  // loop through all devices to initialize per-device
  for (int d = 0; d < ocl.ndev; d++)
  {
    post_init  = odat.post.getv(d);
    par_init   = odat.par.getv(d);
    rng_init   = odat.rng.getv(d);
    mean_init  = odat.aux_mean.getv(d);
    jump_init  = odat.aux_sd.getv(d);
    rej_init   = odat.accepts.getv(d);
    batch_init = odat.batches.getv(d);
    stype_init = odat.stype.getv(d);

    // Vectors which are not dependent on work-items/chains
    for (int i = 0; i < batches.size(); i++) {
      *batch_init = batches.at(i);
    }
    for (int i = 0; i < sampling_type.size(); i++) {
      *stype_init = sampling_type.at(i);
    }

    // Loop through parameter-specific inits
    for (int j = 0; j < cfg.NPARS; j++)
    {
      *jump_init = init_sd[j];
      *mean_init = init_mean[j];
      jump_init++;
      mean_init++;
    }

    // Loop through the work-items per device
    for (int i = 0; i < ocl.work_items[d]; i++){
      // Initialize the parameters
      for (int j = 0; j < cfg.NPARS; j++)
      {
        *par_init  = init[j + cfg.NPARS * counter];
        *rej_init  = 0.0;
        par_init++;
        rej_init++;
      }
      // Set prior and posterior to lowest possible values
      *post_init  = 100 - FLT_MAX;
      // Set the initial RNG state to be equal to the work item index
      *rng_init = (counter + 1) * 10 + (cl_uint)round(R::runif(0, 10)) ;
      // Increment pointers
      post_init++;
      rng_init++;
      counter++;
    }
  }

  // Write the buffers for the initialized vectors
  ocl.write_buffer<Ovec<rtype>&>(odat.post);
  ocl.write_buffer<Ovec<rtype>&>(odat.par);
  ocl.write_buffer<Ovec<cl_uint>&>(odat.rng);
  ocl.write_buffer<Ovec<rtype>&>(odat.aux_mean);
  ocl.write_buffer<Ovec<rtype>&>(odat.aux_sd);
  ocl.write_buffer<Ovec<rtype>&>(odat.accepts);
  ocl.write_buffer<Ovec<cl_uint>&>(odat.batches);
  ocl.write_buffer<Ovec<cl_uint>&>(odat.stype);

  // Make sure everything is synced at this point
  ocl.finish();

  return odat;
}

//' @title Gather samples from _every_ chain
//' @param kernel_code The code for the kernel
//' @param config      A list of configuration items
//' @param init        The initial parameters
//' @param init_mean   The initial value for the parameter mean
//' @param init_sd     The initial value for the parameter sd
//' @param dat         rtype precision data
// [[Rcpp::export]]
List full_mcmc
(
  String kernel_code,
  List config,
  NumericVector init,
  NumericVector init_mean,
  NumericVector init_sd,
  List          dat
)
{
  Rcout << "in CPP" << std::endl;
  // Some variables for timekeeping
  double avg_time = 0, diff = 0, n;
  uint64_t iter_time0, iter_time1, setup_time0, setup_time1;

  // We're going to time how long it takes to get to the iterations
  setup_time0 = timeSinceEpochMillisec();

  // Number of iterations
  int draws = config["draws"];
  // Keep every ikeep iterations
  int ikeep = config["keep_every"];
  // Skip the first iskip iterations
  int iskip = config["skip"];
  // Total number of iterations to run
  int niter = iskip + ikeep * draws;
  // Which algorithm are we running
  std::string algo = config["algo"];

  // The batches of parameters to run with gibbs
  IntegerVector batches       = config["batches"];
  IntegerVector sampling_type = config["sampler"];

  // The device number
  List dlist = config["dlist"];
  // Some pieces need to be carried around, and List types don't always
  // play well with others, so let's save them in a struct
  bconf cfg = {
    config["npar"],
    config["chains"],
    config["burn_sd"],
    config["adapt_all"],
    config["adapt_none"],
  };


  // Now actually begin initializing the OpenCL stuff
  // Get all platforms (devices)
  OclHandler ocl(dlist, kernel_code);
  // Initialize the buffers on the devices
  Odata odat = ocl_setup(ocl, cfg, dat, init, init_mean, init_sd, batches, sampling_type);

  // Set the numeric vector that will hold all the samples
  // Extra cols:
  //   posterior
  //   chain
  //   iteration
  int extra_cols = 3;
  NumericMatrix samples(draws * cfg.CHAINS, cfg.NPARS + extra_cols);

  // Sum statistics
  // Extra cols:
  //  iteration
  //  posterior
  //  posterior standard deviation
  // Cols:
  //  mean parameter
  //  mean standard deviation
  //  mean acceptance
  Stats stats(config, 3 * cfg.NPARS + 3);

  // Between chain variance
  std::vector<rtype> m1(cfg.NPARS);
  std::vector<rtype> m2(cfg.NPARS);
  std::vector<rtype> a1(cfg.NPARS);

  // This is the number of iterations from when the collect signal was given
  int citer = -1;
  // The number of draws we've collected thus far
  int draws_collected = 0;
  int iter = 1;

  setup_time1 = timeSinceEpochMillisec();

  Rcout << "@@full_mcmc: Staring iterations" << std::endl;

  iter_time0 = timeSinceEpochMillisec();

  while (true) 
  {

    // Run the kernel on all devices
    ocl.run_kernel(algo);
    // Read result from GPU to here
    ocl.read_buffer<Ovec<rtype>&>(odat.post);
    ocl.read_buffer<Ovec<rtype>&>(odat.par);
    ocl.read_buffer<Ovec<rtype>&>(odat.accepts);
    // Kernel needs to have finished
    ocl.finish();

    // Calculate the jump distribution
    fmcmc_calc(odat, cfg, samples, iter, ocl, stats, m1, m2, a1, config);

    ocl.finish();

    // Collect iteration times
    iter_time1 = timeSinceEpochMillisec();
    diff = iter_time1 - iter_time0;
    n    = iter;
    avg_time =  avg_time * (n / (n + 1)) + (diff / (n + 1));
    iter_time0 = iter_time1;

    if (stats.collect_signal == 0) {
      stats.check_collect();
    } else {
      citer++;
      collect_samples(odat, config, samples, ocl, iter, citer, draws_collected);
    }

    // Display some information
    fmcmc_display(stats, cfg, iter, citer, config);

    if (draws_collected == draws) {
      break;
    }
    iter++;

  }

  Rcout << "\nDone with iterations" << std::endl;
  Rcout << "Total setup time:           " << (setup_time1 - setup_time0) / 1000.0 << "s" <<std::endl;
  Rcout << "Total iteration time:       " << avg_time * niter / 1000 << "s" <<std::endl;
  Rcout << "Average time per iteration: " << avg_time << "ms" <<std::endl;

  return List::create(
    Named("samples") = samples,
    Named("stats")   = stats.to_mat()
  );
};
