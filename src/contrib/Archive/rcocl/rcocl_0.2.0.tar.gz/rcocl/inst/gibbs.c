#ifndef USEMEAN
#define USEMEAN 0
#endif

void kernel gibbs (
  // first two args are mandatory
  global   float* post_out,
  global   float* par,
  global   uint*  rng_state,
  constant float* aux_mean,
  constant float* aux_sd,
  global   float* accept,
  constant uint* batches,
  constant uint* sample_type,
  // user args
  @@def_user_args@@
)
{
  // The id for this worker
  int gid  = get_global_id(0);
  // Initialize the rng state
  uint s = rng_state[gid];

  // The parameter vector for this model
  float pars[NPAR], ppars[NPAR];
  for (int i = 0; i < NPAR; i++) {
    pars[i]  = par[gid * NPAR + i];
    ppars[i] = pars[i];
  }

  // The jump vector for this model
  float jvec[NPAR];
  for (int i = 0; i < NPAR; i++) {
    jvec[i] = aux_sd[i];
  }

  // The acceptance rate for each parameter
  float avec[NPAR];
  for (int i = 0; i < NPAR; i++) {
    avec[i] = 0.0;
  }

  // Some algebra needs to happen to the proposed, so it happens here
  float final_proposed, final_current, resolve, ratio;

  // Keep track of the proposed and current prior and posterior
  float proposed;
  float current;

  // Ensure we're dealing with real numbers here
  current = isnan(current) ? -FLT_MAX : current;

  float aavg = 0;
  float out_post;

  int accept_this = 0;
  int pari = 0;
  uint bpars = 0;
  uint stype = 0;

  int check = 0;

  float ja0 = 0;
  float ja1 = 0;
  float jump_adjust = 0;

  for (int iter = 0; iter < MCMC_RUNS; iter++) {
    // This is Gibbs sampling with an embedded Metropolis Hastings algorithm
    // We do the embedded algorithm because we do not know if we can directly
    // sample from the conditional posterior, and so instead, we use the MH
    // algorithm to sample for us.

    out_post = 0;

    // Iterate through every parameter, in order, and calculate successive
    // conditional distributions
    for (int batch = 0; batch < NBATCHES; batch++) {

      // The number of parameters in this batch
      bpars = batches[batch];
      // The type of sampling to be done
      stype = sample_type[batch];

      current  = 0.0;
      proposed = 0.0;

      // Use the metropolis algorithm
      if (stype == 0) {
        // Get the current value of the conditional posterior
        @@function_name@@ (
          &current,
          pars,
          pari,
          bpars,
          stype,
          &s,
          @@fn_user_args@@
        );
        // Propose new values for the parameters in this batch
        jump_adjust = 0;
        for (int i = 0; i < bpars; i++) {
          #if USEMEAN > 0
          ppars[pari + i] = rnorm(&s, aux_mean[pari + i], jvec[pari + i]);
          ja0 = ldnorm(pars[pari + i],  aux_mean[pari + i], jvec[pari + i]);
          ja1 = ldnorm(ppars[pari + i], aux_mean[pari + i], jvec[pari + i]);
          jump_adjust += ja0 - ja1;
          #else
          ppars[pari + i] = rnorm(&s, pars[pari + i], jvec[pari + i]);
          #endif
        }

        // Get the value of the proposed conditional posterior
        @@function_name@@ (
          &proposed,
          ppars,
          pari,
          bpars,
          stype,
          &s,
          @@fn_user_args@@
        );
        // Take the difference
        ratio   = proposed - current;
        /*
        if (gid == 0 & batch == 0) {
          printf("bpars: %d\n",  bpars);
          printf("par: %f %f\n",  pars[pari], pars[pari + 1]);
          printf("ppar: %f %f\n", ppars[pari], ppars[pari + 1]);
          printf("m1: %f %f\n", aux_mean[pari], aux_mean[pari + 1]);
          printf("j1: %f %f\n", jvec[pari], jvec[pari + 1]);
          printf("ja0: %f\n", ja0);
          printf("ja1: %f\n", ja1);
          printf("ratio: %f\n", ratio);
          printf("jump_adj: %f\n", jump_adjust);
          printf("\n\n");
        }
        */
        ratio += jump_adjust;
        // Get the min BEFORE exponentiation to avoid overflow
        ratio   = min((float) 0.0, ratio);
        // Get a random uniform variable to resolve the jump
        resolve = runif(&s);
        // And log it so we don't have to exponentiate the log-posterior ratio
        resolve = log(resolve);

        if (isfinite(proposed) && ratio > resolve) {
          // If we accept the proposed parameters, then reset pars to reflect it
          for (int i = 0; i < bpars; i++) {
            pars[pari + i] = ppars[pari + i];
            // The acceptance ratio for this batch
            avec[pari + i] += exp(ratio) / MCMC_RUNS;
          }
          // The rest of this is fluff
          out_post += proposed;
        } else {
          // If we don't accept the proposed parameters,
          // then reset the ppars to the original parameters
          for (int i = 0; i < bpars; i++) {
            ppars[pari + i] = pars[pari + i];
          }
          out_post += current;
        }
      } else {
        // If we're sampling directly
        @@function_name@@ (
          &proposed,
          ppars,
          pari,
          bpars,
          stype,
          &s,
          @@fn_user_args@@
        );
        for (int i = 0; i < bpars; i++) {
          pars[pari + i] = ppars[pari + i];
          avec[pari + i] += 1.0;
        }
        out_post += current;
      }

      //if (gid == 0 && (!isfinite(out_post))) {
      if ((!isfinite(out_post))) {
        //printf("gid: %d\n", gid);
        //printf("batch %d\t stype %d\tgid %d\n", batch, stype, gid);
        //printf("currrnt %.8f \n", current);
        //printf("proposed %.8f\n", proposed);

        //for (int bp = 0; bp < bpars; bp++) {
        //	printf("par[%d] %f\t", bp, pars[bp]);
        //}
        ////for (int bp = POP * MODPAR; bp < POP * MODPAR + 12; bp++) {
        ////	printf("par[%d] %f\t", bp, exp(pars[bp]));
        ////}
        //printf("\n");
        //check = 1;
      }

      // increment pari for the number of parameters in this batch
      pari += bpars;
    }
  }

  // reset the state
  rng_state[gid] = s;

  // Record the latest parameters and acceptance ratio
  for (int i = 0; i < NPAR; i++) {
    par[gid * NPAR + i] = pars[i];
    accept[gid * NPAR + i] = avec[i];
  }

  // Record the prior and likelihood separately
  post_out[gid] = out_post;
}
