#define PI 3.14159265358979
#define SQ2PI 2.506628274631
#define SQ2 1.4142135623731
#define ERF_A 0.147
#define PI_A 4.330746751
#define PI2 6.283185

#define BETA_STOP 1.0e-7
#define BETA_TINY 1.0e-30

// From Xorshift RNGs
// George Marsaglia
float runif(uint* s) {
	// uint in OpenCL is 32 bit
	uint y = *s;
	// Note these are all prime
	y ^= y << 13;
	y ^= y >> 17;
	y ^= y << 15;
	// The runif function self-updates the state
	*s = y;
	// x is a uint, we want a float, so divide by the maximum uint
	float o = (y >> 8) * 0x1.0p-24;
	return(o);
};

float dunif(float x, float lower, float upper) {
	float d = 1.0 / (upper - lower);
	if (x >= lower && x <= upper) return(d);
	return(0.0);
}

float ldunif(float x, float lower, float upper) {
	float d = -log(upper - lower);
	if (x >= lower && x <= upper) return(d);
	return(-INFINITY);
}

float dnorm(float x, float m, float s)
{
	return exp(-.5 * pow((float)(x - m)/s, (float)2.0)) / (s * SQ2PI);
};

float ldnorm(float x, float m, float s)
{
	return -log(s) - .5 * log(PI2) - pow((float)(x - m), (float)2.0) / (2.0 * pow((float)s, (float)2.0));
};

float pnorm(float x, float m, float s)
{
	return .5 * (1 + erf((x - m) / (s * SQ2)));
};

// This is just an approximation of the inverse erf
// https://en.wikipedia.org/wiki/Error_function#Inverse_functions
float ierf(float z)
{
	float t1 = log(1 - pow((float)z, (float)2.0));
	float t2 = PI_A + (t1 / 2.0);
	return sign(z) * sqrt(
		sqrt(pow((float)t2, (float)2.0) - (t1 / ERF_A)) - t2
	);
};

float qnorm(float x, float m, float s)
{
	return m + s * SQ2 * ierf(2.0 * x - 1.0);
};

float rnorm(uint* s, float mean, float sd)
{
	float ru = runif(s);
	return qnorm(ru, mean, sd);
};

// This is the regularized beta function, in log form
float lbeta(float a, float b)
{
	// lgamma is a built-in for opencl
	return lgamma(a) + lgamma(b) - lgamma(a + b);
};

// The log of the beta density function
float ldbeta(float x, float a, float b)
{
	float den = log(powr((float)x, (float) (a - 1.0))) + log(powr((float)(1.0 - x), (float)(b - 1.0))) - lbeta(a, b);
	return(den);
};

// The log of the beta density function
float ldbeta_alt(float x, float m, float p)
{
	return(ldbeta(x, m * p, (1 - m) * p));
};

float pbeta(float x, float a, float b) {
    if (x < 0.0 || x > 1.0) return 1.0/0.0;

    /*The continued fraction converges nicely for x < (a+1)/(a+b+2)*/
    if (x > (a + 1.0)/(a + b + 2.0)) {
        return (1.0 - pbeta(b, a, 1.0 - x)); /*Use the fact that beta is symmetrical.*/
    }

    /*Find the first part before the continued fraction.*/
    const float lbeta_ab = lgamma(a) + lgamma(b) - lgamma(a + b);
    const float front = exp(log(x) * a + log(1.0 - x) * b - lbeta_ab) / a;

    /*Use Lentz's algorithm to evaluate the continued fraction.*/
    float f = 1.0, c = 1.0, d = 0.0;

    int i, m;
    for (i = 0; i <= 200; ++i) {
        m = i / 2;

        float numerator;
        if (i == 0) {
            numerator = 1.0; /*First numerator is 1.0.*/
        } else if (i % 2 == 0) {
            numerator = (m * (b - m) * x) / ((a + 2.0 * m - 1.0) * (a + 2.0 * m));  /* Even term. */
        } else {
            numerator = -((a + m) * (a + b + m) * x) / ((a + 2.0 * m) * (a + 2.0 * m + 1));  /* Odd term. */
        }

        /*Do an iteration of Lentz's algorithm.*/
        d = 1.0 + numerator * d;
        if (fabs(d) < BETA_TINY) d = BETA_TINY;
        d = 1.0 / d;

        c = 1.0 + numerator / c;
        if (fabs(c) < BETA_TINY) c = BETA_TINY;

        const float cd = c*d;
        f *= cd;

        /*Check for stop.*/
        if (fabs(1.0 - cd) < BETA_STOP) {
            return front * (f - 1.0);
        }
    }

    return 1.0/0.0; /*Needed more loops, did not converge.*/
}

void norm_to_lnnorm(float *m, float *s)
{
	// Squarring terms
	float m2 = *m * *m;
	float s2 = *s * *s;

	*m = log(m2 / sqrt(m2 + s2));
	*s = sqrt(log(1 + (s2 / m2)));
}

// This is defined in terms of the mean and standard deviation of the log-normal distribution
float dlnorm(float x, float m, float s)
{
	norm_to_lnnorm(&m, &s);

	float o = (1 / (x * s * SQ2PI));
	float n = log(x) - m;
	n = -n * n;
	n = exp(n / (2 * s * s));

	o = o * n;

	return o;
};

// Inverse-Gamma density function
float ldigamma(float x, float a, float b) {
	int sign;
	float v = lgamma_r(a, &sign);
	float out = a * log(b) - (sign * v) - (a + 1) * log(x) - (b / x);
	return(exp(out));
}

float rgamma(uint *s, int a, float b) {
float su = 0;
for (int i = 0; i < a; i++) {
	su += log(runif(s));
}
return(-su / b);
}

float rigamma(uint *s, int a, float b) {
	return(1 / rgamma(s, a, b));
}

// Inverse-Chi2 densisty function
float dinvchi2(float x, float v, float tau2) {
	v = v / 2;
	return(
		pow((tau2 * v), v) / tgamma(v) * exp(-v * tau2 / x) / pow(x, (float)1.0 + v)
	);
}

float ldinvchi2(float x, float v, float tau2) {
	v = v / 2;
	return(
		v * (log(tau2) + log(v)) - lgamma(v) - v * tau2 / x - (1 + v) * log(x)
	);
}
