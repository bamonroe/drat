tenv <- new.env()

timecheck <- function() {
  if (! exists("lasttime", env = tenv)) {
    tenv$lasttime <- Sys.time()
  } else {
    now <- Sys.time()
    cat(now - tenv$lasttime, "\n")
    tenv$lasttime <- now
  }
}
