#' @useDynLib rcocl
#' @importFrom Rcpp sourceCpp
NULL
