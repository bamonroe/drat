data {
  // The number of subjects
  int<lower=1> N;
  // The number of data points by subject
  int<lower=1> T[N];
  // The number of rows of data total
  int<lower=1> ndat;
  // The number of options in the dataset
  int<lower=2> nopts;
  // The number of outcomes in the dataset
  int<lower=2> nouts;
  // The number of covariate effects to estimate
  int<lower=0> ncovar_est;
  // The number of unique covariates passed across all hyper parameters
  int<lower=0> ncvars;
  // Number of hyper-parameter
  int<lower=0> nhyper;
  // The list of bools for each possible covar, for each hyper-parameter
  int<lower=0> cvarmap[ncvars, nhyper];
  // This is the matrix of all unique covars, with 1 row per subjects, 1 column
  // for each possible covar across all hyper-parameters
  real<lower=0> covars[N, ncvars];

  // The choices
  int<lower=0, upper = 1> choice[ndat];

  // The probabilities
  matrix[ndat, nouts] probs1;
  matrix[ndat, nouts] probs2;

  // The outcomes
  matrix[ndat, nouts] outs1;
  matrix[ndat, nouts] outs2;

  // Max and Min outcomes with non-zero probability across the pair
  // this is for Contextual Utility
  real Max[ndat];
  real Min[ndat];
}

transformed data {

  // Cumulative probabilities from highest to lowest here.
  // Doing this operation here allows it to only be calculated once instead of
  // every time the model is called

  // Initialize the decision weights at the value of the first probability, the
  // highest outcome
  matrix[ndat, nouts] cprob1 = rep_matrix(probs1[, 1], nouts);
  matrix[ndat, nouts] cprob2 = rep_matrix(probs2[, 1], nouts);

  for (kk in 2:nouts) {
    cprob1[, kk] = cprob1[, kk - 1] + probs1[, kk];
    cprob2[, kk] = cprob2[, kk - 1] + probs2[, kk];
  }
  // Normalize back so they add up to one
  cprob1 = cprob1 ./ rep_matrix(cprob1[, nouts], nouts);
  cprob2 = cprob2 ./ rep_matrix(cprob2[, nouts], nouts);

  // Indicator variables for whether a cumulative probability is zero
  // We need these because the Prelec weighting function is not defined at zero
  matrix[ndat, nouts] cprob1_c;
  matrix[ndat, nouts] cprob2_c;
  for (nn in 1:ndat) {
    for (kk in 1:nouts) {
      cprob1_c[nn, kk] = cprob1[nn, kk] == 0 ? 1 : 0;
      cprob2_c[nn, kk] = cprob2[nn, kk] == 0 ? 1 : 0;
    }
  }
  // Replace the zeros with small numbers.
  cprob1 = (1.0 - cprob1_c) .* cprob1 + cprob1_c * 0.05;
  cprob2 = (1.0 - cprob2_c) .* cprob2 + cprob2_c * 0.05;

}

parameters {
  // Hyper parameters first
  // parameters for the mean of each of r, phi, eta, and mu
  //
 
  // Hyper parameters first
  // parameters for the CRRA parameter
  real <lower = .5, upper = 8> hyper_r_a;
  real <lower = .5, upper = 8> hyper_r_b;
  // parameters for the CARA parameter
  real <lower = .5, upper = 8> hyper_alpha_a;
  real <lower = .5, upper = 8> hyper_alpha_b;

  // parameters for the Fechner term
  real hyper_u_mean;
  real hyper_u_lnsd;

  // Arrays of parameters for each subject. Each arrary keeps N parameters, N
  // being the number of subjects
  real <lower = 0, upper = 1> r[N];
  real <lower = 0, upper = 1> alpha[N];
  real ln_mu[N];

  // Vector for the parameters that defined the covariate effects
  real dem[ncovar_est];
}

model {
  // Variables for subject specific parameters - this should reduce memory lookups
  real ri;
  real alphai;
  real mu;
  // Variables for covariate-corrected hyper-parameters. You need to change
  // the index manually per-model
  int total_hyper = 6;
  real hyper[total_hyper];
  // Variable for the utility difference
  real udiff;
  // Variable keeping track of covariate effects
  int ci = 0;
  // Variable keeping track of the observation
  int i = 0;

  real u1;
  real u2;
  real u_max;
  real u_min;

  // Hyper Prior Distributions
  // r a and b parameters for beta distribution
  target += uniform_lpdf(hyper_r_a | .5, 8);
  target += uniform_lpdf(hyper_r_b | .5, 8);

  // alpha a and b parameters for beta distribution
  target += uniform_lpdf(hyper_alpha_a | .5, 8);
  target += uniform_lpdf(hyper_alpha_b | .5, 8);

  // log(mu) mean and standard deviation
  target += normal_lpdf(hyper_u_mean | 0, 100);
  target += normal_lpdf(hyper_u_lnsd | 0, 100);

  // Looping through the subjects
  for (n in 1:N) {

    // CRRA prior
    target += beta_lpdf(r[n] | hyper_r_a, hyper_r_b);
    // CARA prior
    target += beta_lpdf(alpha[n] | hyper_alpha_a, hyper_alpha_b);
    // Fechner prior
    target += normal_lpdf(ln_mu[n] | hyper_u_mean,  exp(hyper_u_lnsd));

    // The parameters for subject "n"
    // We're bounding r to be [0, 1] so no need to adjust the beta
    ri     = r[n];
    // To bound a beta between U and L you do var * (U - L) + L
    alphai = (alpha[n]) * (.15 - (-.15)) + (-.15);
    mu     = exp(ln_mu[n]);

    // Looping through each of the observations per-subject
    for (t in 1:T[n]) {
      i += 1;

      // Calculate the EUT and RDU of the options
      u1 = 0;
      u2 = 0;
      for (out in 1:nouts) {
        // EUT uses probs
        u1 += (probs1[i, out] * ((1 - exp(-alphai * outs1[i, out]^(1 - ri))) / alphai));
        u2 += (probs2[i, out] * ((1 - exp(-alphai * outs2[i, out]^(1 - ri))) / alphai));
      }

      // EUT utility difference using contextual utility
      u_max = ((1 - exp(-alphai * Max[i]^(1 - ri))) / alphai);
      u_min = ((1 - exp(-alphai * Min[i]^(1 - ri))) / alphai);
      udiff = (u1 - u2) / (u_max - u_min);
      udiff = udiff / mu;

      // Logistic linking function
      udiff = 1 / (1 + exp(udiff));
      udiff = choice[i] * udiff + (1 - choice[i]) * (1 - udiff);

      // Log the likelihood and add to the posterior target
      udiff = log(udiff);

      target += udiff;
    }
  }

}



