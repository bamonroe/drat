qsr <- function(r, a, b) {
  s <- c(r, 1 - r)
  o <- a + b * (2 * r - sum(s^2))
  o
}

#' @title Create a QSR instument
#'
#' @description qsr_task generates a risk inst using the quadratic scoring rule
#' to generate outcomes. This is the kind of inst implied by a 2-bin token
#' allocation task. This function sets the generated inst using set_inst, and
#' can then be generated using the name "qsr_<tokens>" where <tokens> is the
#' number passed as the "tokens" argument.
#'
#' @returns the name of the task
#'
#' @param tokens the number of tokens allowed to allocate
#' @param apar the vector of "a" parameters
#' @param bpar the vector of "b" parameters
#' @param prob1 the vector of probabilities for opt*_out1
#' @export qsr_task
qsr_task <- function(tokens, apar, bpar, prob1) {

  tname <- paste0("qsr_", tokens)
  prob2 <- 1 - prob1

  q <- seq(from = 0, to = 1, length.out = tokens + 1)

  dat <- lapply(seq_along(q), function(opt) {

    r <- q[opt]
    out1 <- qsr(r, apar, bpar)
    out2 <- qsr(1 - r, apar, bpar)

    d <- cbind(out1, out2, prob1, prob2)
    d <- as.data.frame(d)
    colnames(d) <- c(
      paste0("opt", opt, "_out1"),
      paste0("opt", opt, "_out2"),
      paste0("opt", opt, "_prob1"),
      paste0("opt", opt, "_prob2")
    )

    d
  })
  dat <- do.call(cbind, dat)

  dat$Max  <- apar + bpar
  dat$Min  <- apar - bpar
  dat$task <- "risk"
  dat$inst <- tname

  set_inst(name = tname, inst = dat)

  tname
}

set_max_min <- function(inst, layout) {
  profile <- profile_inst(inst, layout)
  # Re-calculate Max-Min
  for (i in seq_len(nrow(inst))) {
    row <- inst[i, ]
    maxval <- -Inf
    minval <- Inf
    for (j in seq_along(profile$probabilities)) {
      probs <- row[profile$probabilities[[j]]]
      outs  <- row[profile$outcomes[[j]]]
      outs  <- outs[probs > 0]

      maxval <- ifelse(max(outs) > maxval, max(outs), maxval)
      minval <- ifelse(min(outs) < minval, min(outs), minval)
    }
    inst[i, "Max"] <- maxval
    inst[i, "Min"] <- minval
  }
  inst
}

#' @title Create a Skewed QSR instument
#'
#' @description qsr_task generates a risk inst using the quadratic scoring rule
#' to generate outcomes. This is the kind of inst implied by a 2-bin token
#' allocation task. This function sets the generated inst using set_inst, and
#' can then be generated using the name "qsr_<tokens>" where <tokens> is the
#' number passed as the "tokens" argument.
#'
#' @returns the name of the task
#'
#' @param tokens the number of tokens allowed to allocate
#' @param apar the vector of "a" parameters
#' @param bpar the vector of "b" parameters
#' @param prob1 the vector of probabilities for opt*_out1
#' @export sqsr_task
sqsr_task <- function(tokens, apar, bpar, prob1) {

  tname <- paste0("sqsr_", tokens)
  prob2 <- (1 - prob1) / 2
  prob3 <- prob2

  q <- seq(from = 0, to = 1, length.out = tokens + 1)

  dat <- lapply(seq_along(q), function(opt) {

    r <- q[opt]
    out1 <- qsr(r, apar, bpar)
    o2   <- qsr(1 - r, apar, bpar)

    out2 <- o2 - o2 / 2
    out3 <- o2 + o2 / 2

    d <- cbind(out1, out2, out3, prob1, prob2, prob3)
    d <- as.data.frame(d)
    colnames(d) <- c(
      paste0("opt", opt, "_out1"),
      paste0("opt", opt, "_out2"),
      paste0("opt", opt, "_out3"),
      paste0("opt", opt, "_prob1"),
      paste0("opt", opt, "_prob2"),
      paste0("opt", opt, "_prob3")
    )

    d
  })
  dat <- do.call(cbind, dat)

  dat$task <- "risk"
  dat$inst <- tname

  dat <- set_max_min(dat, "standard")

  set_inst(name = tname, inst = dat)

  tname
}
