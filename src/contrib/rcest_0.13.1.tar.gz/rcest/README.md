## RC Estimation
[![Build Status](https://drone.bamonroe.com/api/badges/rdev/rcest/status.svg?ref=refs/heads/master)](https://drone.bamonroe.com/rdev/rcest)

This package provides functions to the direct estimation of "ftypes", a format I've developed to aid the estimation of structural models. Generic functions to do any maximum likelihood estimate, and delta method functions to do non-linear wald tests are also provided.

The delta methods were derived because the nlWaldtest package didn't allow for arbitrary functional transformations of parameters. The delta methods are provided here because they are most useful when combined with the results from the top_llfun, but can be used for any set of estimates and covariance matrix.

#### Goals

- [x] Allow for parameters to be made linear functions of observable covariates.
- [x] Create generic function to use in other packages so work isn't duplicated elsewhere.
- [x] Create API to allow users to add any optimizer
	- Base-R optimizers are pre-built into the package, so work can begin out of the box.
- [x] Create API to allow users to provide arbitrary parameter transformations.
	- "none", "exp", and "logit" transforms are pre-built for non-constrained, positive-constrained, and 0-1 constrained parameters.
- [x] Provide Delta Method functions for arbitrary parameter transformations.
- [x] Clean way of correcting covariance matrix for clusters in the data.
- [x] Minimize Dependencies
	- Currently zero dependencies.
