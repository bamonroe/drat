cvb_identity <- function(inst, ...) {
  dargs  <- list(...)

  arenum    <- sapply(dargs, is.numeric)
  fnames    <- names(dargs)
  num_named <- all(fnames[arenum] != "")
  if (!num_named)
    stop("Some arguments to the 'identity' cvb are numeric, but not named")

  arechar     <- sapply(dargs, is.character)
  are_numchar <- all(arechar | arenum)
  if (!are_numchar)
    stop("Some arguments to the 'identity' cvb are not numeric or character")

  ivec <- cvar_vec_to_numeric(unlist(dargs))
  ivec <- ivec[match(unique(names(ivec)), names(ivec))]

  vnames      <- names(ivec)
  check_names <- vnames[!vnames %in% colnames(inst)]
  if (length(check_names) > 0) {
    check_names <- paste0("'", check_names, "'")
    check_names <- paste(check_names, collapse = ", ")
    msg <- paste0("Covariate names ",
                  check_names,
                  " were passed to the identity cvb, but these don't exist in the inst")
    stop(msg)
  }

  cnames <- names(ivec)
  out    <- list(vars = inst[, cnames, drop = F], init = ivec)
  out
}

cvb_dummy <- function(inst, var, init = NA, include = NA, omit = NA) {

  if (! is.na(include[1])) {
    dvar <- include
  } else {
    dvar <- sort(unique(inst[, var]))
    if (! is.na(omit[1]) & any(omit %in% dvar)) {
      dvar <- dvar[which(! dvar %in% omit)]
    } else {
      dvar <- dvar[-1]
    }
  }

  ldvar <- length(dvar)

  vars <- matrix(0, nrow = nrow(inst), ncol = ldvar)
  vars <- as.data.frame(vars)

  nvec <- c()
  for (j in seq_len(ldvar)) {
    dv        <- dvar[j]
    nname     <- paste0(var, "@", dv)
    nvec      <- c(nvec, nname)
    vars[, j] <- ifelse(inst[, var] == dv, 1, 0)
  }
  colnames(vars) <- nvec

  ivec <- cvar_vec_to_numeric(nvec)
  for (n in names(ivec)) {
    if (n %in% names(init)) {
      ivec[n] <- init[n]
    }
  }

  ncvb <- cvb(name = "dummy", var = var, include = dvar)

  out <- list(vars = vars, init = ivec, cvb = ncvb)
  out
}

cvb_polynomial <- function(inst, dem, poly) {
  vals <- as.data.frame(matrix(0, nrow = nrow(inst), ncol = length(poly)))
  for (i in seq_along(poly)) vals[, i] <- inst[[dem]]^poly[i]
  poly <- sapply(poly, format, digits = 2)
  colnames(vals) <- paste0(dem, "^", poly)
  list(vars = vals, init = rep(0, length(poly)))
}

cvb_interaction <- function(inst, dem) {
  # make a default values data.frame
  vals <- as.data.frame(matrix(1, nrow = nrow(inst), ncol = 1))
  # Loop over the values in dems interacting as we go
  for (i in dem) {
    vals[, 1] <- vals[, 1] * inst[[i]]
  }
  # Make the new variable separated by a "*"
  colnames(vals) <- paste(dem, collapse = "*")
  out <- list(vars = vals, init = 0)
  out
}
