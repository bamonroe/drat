res_check <- function(res = NULL) {
  if (is.null(res)) {
    stop("You need to pass in the result of the rcest function")
  }

  if (! "ftypes" %in% names(res)) {
    stop("You need to pass a 'res' argument that contains an 'ftypes' list")
  }

  if (! "covars" %in% names(res)) {
    stop("You need to pass a 'res' argument that contains an 'covars' list")
  }

  if (! "transforms" %in% names(res)) {
    stop("You need to pass a 'res' argument that contains an 'transforms' list")
  }
}

inst_check <- function(inst = NULL) {
  if (! is.data.frame(inst)) {
    stop("'inst' needs to be a data.frame, not a '", class(inst), "'")
  }
}

#' @title Check the arguments of a function
#'
#' @param fn the function
#' @param req_args the required arguments for the function
#' @param fn_name option name to identify the function in an error message
#' @export fn_check
fn_check <- function(fn, req_args, fn_name = "fn") {
  nformals <- names(formals(fn))
  if (! all(req_args %in% nformals)) {
    missing_vals <- paste("'",
                          req_args[! req_args %in% nformals],
                          "'",
                          sep = "",
                          collapse = ", ")
    stop(paste0("'", fn_name, "' is missing arguments: ", missing_vals))
  }
}
