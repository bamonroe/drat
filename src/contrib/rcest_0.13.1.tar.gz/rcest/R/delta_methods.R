#' @title Get Standard Errors of Statistic Using Delta Method
#'
#' @param g1 function to transform parameters
#' @param g2 function to transform parameters
#' @param mu vector of parameters used to derive statistic
#' @param sigma covariance matrix of parameters used to derive statistic
#' @param gp1 optional gradient function of g, otherwise it is calculated numerically
#' @param gp2 optional gradient function of g, otherwise it is calculated numerically
#' @param ... aditional arguments to g functions
#' @export delta_cov
delta_cov <- function(g1, g2, mu, sigma, gp1 = NULL, gp2 = NULL, ...) {

  if (is.null(gp1)) {
    gf  <- deriv_selector("grad")
    gp1 <- gf(g1, mu, ...)
    gp2 <- gf(g2, mu, ...)
  } else {
    gp1 <- gp1(mu)
    gp2 <- gp2(mu)
  }

  var1  <- 0
  var2  <- 0
  cov12 <- 0

  sigma <- as.matrix(sigma)
  for (j in seq_len(nrow(sigma))) {
    for (k in seq_len(ncol(sigma))) {
      var1  <- var1  + (gp1[j] * gp1[k] * sigma[j, k])
      var2  <- var2  + (gp2[j] * gp2[k] * sigma[j, k])
      cov12 <- cov12 + (gp1[j] * gp2[k] * sigma[j, k])
    }
  }
  out_mat <- matrix(c(var1, cov12, cov12, var2), nrow = 2, ncol = 2)
  out_mat
}


#' @title Get Standard Errors of Statistic Using Delta Method
#'
#' @param g function to transform parameters
#' @param mu vector of parameters used to derive statistic
#' @param sigma covariance matrix of parameters used to derive statistic
#' @param gp optional gradient function of g, otherwise it is calculated numerically
#' @param ... aditional arguments to g function
#' @export delta_var
delta_var <- function(g, mu, sigma, gp = NULL, ...) {
  if (is.null(gp)) {
    gf <- deriv_selector("grad")
    gp <- gf(g, mu, ...)
  } else {
    gp <- gp(mu)
  }
  val <- 0
  sigma <- as.matrix(sigma)
  for (j in seq_len(nrow(sigma))) {
    for (k in seq_len(ncol(sigma))) {
      val <- val + (gp[j] * gp[k] * sigma[j, k])
    }
  }
  val
}
#' @title Get Two-Tailed p-Value of Statistic Using Delta Method
#'
#' @param g function to transform parameters
#' @param mu vector of parameters used to derive statistic
#' @param sigma covariance matrix of parameters used to derive statistic
#' @param h0 Null hypothesis value
#' @param ... aditional arguments to g function
#' @export delta_pval
delta_pval <- function(g, mu, sigma, gp = NULL, h0 = 0, ...) {
  gx <- g(mu, ...)
  se <- sqrt(delta_var(g = g, mu = mu, sigma = sigma, gp = gp, ...))
  d_pval(gx = gx, se = se, h0 = h0)
}

d_pval <- function(gx, se, h0) {
  z <- abs((gx - h0) / se)
  pnorm(z, lower.tail = FALSE) * 2
}


#' @title Get Two-Tailed Confidence Interval of Statistic Using Delta Method
#'
#' @param g function to transform parameters
#' @param mu vector of parameters used to derive statistic
#' @param sigma covariance matrix of parameters used to derive statistic
#' @param ... aditional arguments to g function
#' @export delta_conf
delta_conf <- function(g, mu, sigma, gp = NULL, ...) {
  gx <- g(mu, ...)
  se <- sqrt(delta_var(g = g, mu = mu, sigma = sigma, gp = gp, ...))
  confidence(gx = gx, se = se)
}

d_confidence <- function(gx, se) {
  ul <- abs(qnorm((1 - .95) / 2))
  lv <- gx - se * ul
  uv <- gx + se * ul
  out <- c(lv, uv)
  names(out) <- c("L95", "U95")
  out
}

#' @title Generate Parsed Matrix of Statistic Using Delta Method
#'
#' @description Generates a data.frame row for a single statistic containing the estimate,
#'              the standard error, lower and upper bounds of the confidence interval,
#'              a null hypothesis and a pval of the null. Uses the delta method to transform
#'              parameters.
#' @param g function to transform parameters
#' @param mu vector of parameters used to derive statistic
#' @param sigma covariance matrix of parameters used to derive statistic
#' @param ... aditional arguments to g function
#' @export delta_parsed
delta_parsed <- function(g, mu, sigma, h0 = 0, gp = NULL, ...) {
  gx   <- g(mu, ...)
  se   <- sqrt(delta_var(g = g, mu = mu, sigma = sigma, gp = gp, ...))

  conf <- d_confidence(gx = gx, se = se)
  pval <- d_pval(gx = gx, se = se, h0 = h0)
  val  <- data.frame(gx, se, conf[1], conf[2], h0, pval)
  rownames(val) <- NULL
  names(val)    <- c("Est", "SE", "L95", "U95", "h0", "pval")
  val
}
