#' Predict Base Parameters
#'
#' @description Use estimates from rcest to make predictions about the base
#' parameters.
#'
#' @param res output of the rcest command
#' @param inst the inst passed to the rcest command
#' @export est_predict
est_predict <- function(res, inst) {
  # Check the res obj
  res_check(res)
  # Check the inst obj
  inst_check(inst)

  ninit <- est_ftypes(res)

  ncovars <- ninit$covars
  ninit   <- ninit$init

  ft_n <- unlist(lapply(ninit, names))

  pred_mat <- data.frame(matrix(NA, nrow = nrow(inst), ncol = length(ft_n)))
  colnames(pred_mat) <- ft_n

  for (ft in names(ninit)) {
    for (bp in names(ninit[[ft]])) {
      pred_mat[, bp] <- ninit[[ft]][bp]
      # Check if list for ftypes with single parameters
      if (is.list(ncovars[[ft]])) {
        cobj <- ncovars[[ft]][[bp]]
      } else {
        cobj <- ncovars[[ft]]
      }
      for (cn in names(cobj)) {
        pred_mat[, bp] <- pred_mat[, bp] + cobj[cn] * inst[, cn]
      }
    }
  }
  return(pred_mat)
}
