#' @title Register the instrument
#'
#' @param inst the dataframe containing the choice data
#' @param layout list of regex/varnames of important instrument properties
#' @param covars optional covar ftype list to make a covars entry
#' @export profile_inst
profile_inst <- function(inst, layout, ...) {
  # Either passing through a layout list or a profile name
  profile <- get_profile(layout)
  cnames  <- colnames(inst)
  out <- lapply(names(profile), function(pn) {
    profile[[pn]](inst = inst, fname = pn, layout = layout, ...)
  })
  names(out) <- names(profile)
  return(out)
}

#' @title Rank the instrument
#'
#' @param inst from profile_inst
#' @export rank_inst
rank_inst <- function(inst, layout, use_times = T, ...) {

  if (nrow(inst) == 0) {
    stop("The passed instrument to rank has 0 rows.")
  }

  profile <- profile_inst(inst, layout, ...)

  outcomes      <- profile[["outcomes"]]
  probabilities <- profile[["probabilities"]]
  times         <- profile[["times"]]

  non_zero_mat <- matrix(NA,
                         nrow = nrow(inst[, profile$outcomes[[1]]]),
                         ncol = 1)

  # Go through every option
  for (opt in seq_along(outcomes)) {
    # For every row, order outcomes from greatest to least,
    # Put probabilities and times in the same order
    vnc      <- ncol(inst[, outcomes[[opt]]])
    inst_out <- inst[, outcomes[[opt]]]
    if (!is.null(vnc)) {
      opt_rank <- t(apply(inst_out, 1, order, decreasing = TRUE))
    } else {
      opt_rank <- NULL
    }

    outcomes[[opt]]      <- mat_order_by_row(inst[, outcomes[[opt]]],
                                             opt_rank, fname = "outcomes")
    probabilities[[opt]] <- mat_order_by_row(inst[, probabilities[[opt]]],
                                             opt_rank, fname = "probabilities")
    if (use_times) {
      times[[opt]]       <- mat_order_by_row(inst[, times[[opt]]],
                                             opt_rank, fname = "times")
    }

    nzero <- ifelse(probabilities[[opt]] != 0, outcomes[[opt]], NA)
    non_zero_mat <- cbind(non_zero_mat, nzero)
  }

  max_val <- apply(non_zero_mat, 1, max, na.rm = TRUE)
  min_val <- apply(non_zero_mat, 1, min, na.rm = TRUE)

  for (opt in seq_along(outcomes)) {
    inst[, profile$outcomes[[opt]]]      <- outcomes[[opt]]
    inst[, profile$probabilities[[opt]]] <- probabilities[[opt]]
    if (use_times) {
      inst[, profile$times[[opt]]]       <- times[[opt]]
    }
    inst[, "Max"] <- max_val
    inst[, "Min"] <- min_val
  }

  return(inst)
}

mat_order_by_row <- function(mat1, mat2, fname) {

  ncm1 <- ncol(mat1)
  ncm2 <- ncol(mat2)

  ncm1 <- ifelse(is.null(ncm1), 0, ncm1)
  ncm2 <- ifelse(is.null(ncm2), 0, ncm2)

  # The fields need to have the same number of columns in each option
  if (ncm1 != ncm2) {
    stop(paste0("'", fname, "' has ", ncm1, " columns and the ranking field has ", ncm2))
  } else if (ncm1 == 0) {
    return(as.matrix(mat1))
  }

  nmat2 <- as.numeric(mat2)
  val   <- cbind(seq_len(nrow(mat2)), nmat2)
  out   <- mat1[val]
  out   <- matrix(out, ncol = ncol(mat2))
  out
}


#' @title Convert inst to standard layout
#'
#' @param inst an inst to convert to standard
#' @param layout layout profile
#' @export layout_convert
layout_convert <- function(inst, layout) {

  # Get the instrument profile
  in_prof <- profile_inst(inst, layout)

  # Name all the options according to this thing
  nopts <- length(in_prof$outcomes)

  # The column names of the instrument
  cnames <- colnames(inst)

  for (opt in seq_len(nopts)) {
    cnum   <- seq_len(length(in_prof$outcomes[[opt]]))
    cnames <- rename_checker(cnames, in_prof, "outcomes", opt, cnum)
    cnames <- rename_checker(cnames, in_prof, "probabilities", opt, cnum)
    cnames <- rename_checker(cnames, in_prof, "times", opt, cnum)
  }

  cnames[in_prof[["choice"]]] <- "choice"
  cnames[in_prof[["task"]]]   <- "task"
  cnames[in_prof[["ID"]]]     <- "ID"
  cnames[in_prof[["Max"]]]    <- "Max"
  cnames[in_prof[["Min"]]]    <- "Min"

  colnames(inst) <- cnames
  inst
}

rename_checker <- function(cnames, profile, field, opt, cnum) {
  if (field == "outcomes")      fval <- "out"
  if (field == "probabilities") fval <- "prob"
  if (field == "times")         fval <- "time"
  if (length(profile[[field]]) > 0) {
    if (! is.null(profile[[field]][[opt]])) {
        cnames[profile[[field]][[opt]]] <- paste0("opt", opt, "_", fval, cnum)
    }
  }
  cnames
}


## Make environment containing regex profiles

#' @title Set up Regex Profile
#'
#' @param name the name of this profile
#' @param ... named functions that are performed on the instrument
#' @export set_profile
set_profile <- function(name, ...) {
  dotargs <- list(...)
  if (name %in% ls(envir = top_env$profile_env)) {
    rprof <- get_profile(name)
    for (oname in names(dotargs)) {
      rprof[[oname]] <- dotargs[[oname]]
    }
  } else {
    rprof <- dotargs
  }
  top_env$profile_env[[name]] <- rprof
}

#' @title Get Regex Profile
#'
#' @param name the name of the profile
#' @export get_profile
get_profile <- function(name) {
  if (! name %in% ls(envir = top_env$profile_env)) {
    stop(paste0("Profile name '", name, "' is not a set profile name"))
  }
  return(top_env$profile_env[[name]])
}

#' @title Delete a Regex Profile
#'
#' @param name the name of this profile
#' @export del_profile
del_profile <- function(name) {
  if (name %in% ls(envir = top_env$profile_env)) {
    top_env$profile_env[[name]] <- NULL
    TRUE
  } else {
    FALSE
  }
}
