#' @title Parse results to give familiar looking output
#'
#' @param res the results of a rcest optimization
#' @param covmat the covariance matrix given by calc_covmat
#' @export make_parsed
make_parsed <- function(res, covmat) {

  # Check the res obj
  res_check(res)

  # If covmat survived the calc_covmat function and is a matrix, it should be
  # fine for everything below
  if (! is.matrix(covmat)) stop("'covmat' needs to be a matrix")

  wopts <- get_wrap_opts(res$inst,
                         res$ftypes,
                         res$covars_in,
                         res$transforms,
                         res$init)

  # Sanatize the ftypes
  ftypes          <- wopts$ftypes
  # Sanatize the transforms
  transforms      <- wopts$transforms
  # Fetch the transform objects
  made_transforms <- wopts$made_transforms
  # Sanatize the covariates
  covars          <- wopts$covars
  # The index of the base pars
  ft_index        <- wopts$ft_index
  # The index of the covars
  cv_index        <- wopts$cv_index
  # Shortcut for the estimates
  est             <- res$estimates

  # Get the parsed matrix for the base parameters
  # Loop through the ftypes
  out_base <- lapply(names(ftypes), function(ft) {
    # Get the ft_index for this ftype
    fp <- ft_index[[ft]]
    # If this ftype has no parameters, return an empty
    if (fp[1] == 0) return()
    # If there aren't estimates for this ftype, just quit
    if (length(fp) == 0) return()
    # Loop through each of these parameters and get the parsed matrix for it
    val <- lapply(seq_along(fp), function(fi) {
      # The tranform for this parameter
      tr  <- made_transforms[[ft]][[fi]]
      # Get the index value of this parameter in the fullpar vector
      i   <- fp[fi]
      delta_parsed(tr$g, est[i], sigma = covmat[i, i], gp = tr$gp)
    })
    # Combine the parsed matrix for the base pars for this ftype
    val <- as.data.frame(do.call(rbind, val))
    # These are the base pars, to record their names
    val$par   <- ftype_names(ft, ftypes)
    # Their "covarite" reference is just the constant
    val$covar <- "_constant"
    val
  })
  out_base <- do.call(rbind, out_base)

  # Do the same for the covariates
  out_cv <- lapply(names(covars), function(ft) {
    # If there aren't covar estimates for this ftype, just quit
    if (length(covars[[ft]]) == 0) return()
    # The index of the base_par
    fi <- ft_index[[ft]]
    # The base_par estimates
    bp_ests <- res$estimates[fi]
    # The index of the covars for this ftype in the full par vector
    cvi <- cv_index[[ft]]
    # Loop over every base par for this ftype
    cv_out <- lapply(seq_along(bp_ests), function(bi) {
      # Transforms for this parameter
      tr <- made_transforms[[ft]][[bi]]
      # Get the raw index for base parameter 'bi'
      fibi <- fi[bi]
      # Index of covars for this parameter
      ce <- cvi[[bi]]
      # The names of the covars for this parameter
      cn <- names(covars[[ft]][[bi]])
      # Loop through each cvar
      omat <- lapply(ce, function(ci) {
        # The estimate for base par 'bi' for ftype 'ft'
        ee <- res$estimates[fibi]
        # The estimate for cvar 'ci' for parameter 'bi' for ftype 'ft'
        cv <- res$estimates[ci]
        # The covar decumulation function
        ng <- function(par) {
          tr$g(par[1] + par[2]) - tr$g(par[1])
        }
        # Covariance Matrix:
        # base-base  base-cvar
        # cvar-base  cvar-cvar
        cmat <- matrix(c(covmat[fibi, fibi], covmat[fibi, ci],
                         covmat[ci,   fibi], covmat[ci,   ci]),
                         byrow = T, nrow = 2, ncol = 2)
        # Get the parsed for the cvar
        delta_parsed(g = ng, mu = c(ee, cv), sigma = cmat)
      })
      # Combine each covar
      omat <- as.data.frame(do.call(rbind, omat))
      # If it's empty return an empty
      if (nrow(omat) == 0) return(NULL)
      # The name of the base par
      omat$par   <- names(covars[[ft]])[bi]
      # The vector of covars
      omat$covar <- cn
      omat
    })
    cv_out <- do.call(rbind, cv_out)
    cv_out
  })

  out_cv <- do.call(rbind, out_cv)
  out <- rbind(out_base, out_cv)
  rownames(out) <- NULL
  cnames <- colnames(out)
  fvars <- c("par", "covar")
  out <- out[, c(fvars, cnames[which(!cnames %in% fvars)])]

  return(out)
}
