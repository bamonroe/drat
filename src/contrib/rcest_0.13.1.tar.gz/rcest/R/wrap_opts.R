#' @title Generate the list that is used with a handful of rcest functions
#'
#' @description This will be used almost exclusively in internal functions
#' @export get_wrap_opts
get_wrap_opts <- function(inst,
                          ftypes = list(),
                          covars = list(),
                          transforms = list(),
                          init = list(),
                          ...) {

  # Sanatize the ftypes
  ftypes <- ftype_sanitize(ftypes = ftypes)
  # Sanatize the transforms
  transforms <- trans_sanitize(ftypes, transforms = transforms)
  # Fetch the transform objects
  made_transforms <- trans_make(ftypes = ftypes, transforms = transforms)
  # Sanatize the initial values
  init <- init_sanitize(ftypes = ftypes, init = init)
  # Apply transforms to initial values
  made_init <- mkinit(ftypes, init = init, transforms = transforms)
  # Sanatize the covariates
  covars_in <- covar_sanitize(covars = covars, ftypes = ftypes)
  # Adjust inst and covars for for cvb
  cvb_adjusted <- inst_adjust(covars_in, inst)
  covars       <- covar_sanitize(covars = cvb_adjusted$covars_o, ftypes = ftypes)
  covars_in    <- cvb_adjusted$covars_i
  inst         <- cvb_adjusted$inst
  # Apply the transforms to initial covariate values
  made_covars <- mkcovars(ftypes, init = init, covars = covars, transforms = transforms)
  # The index of the base pars
  ft_index <- ftype_index(ftypes = ftypes)
  # The index of the covars
  cv_index <- covar_index(covars = covars, ftypes = ftypes)

  wrap_opts <- list(inst            = inst,
                    init            = init,
                    made_init       = made_init,
                    ftypes          = ftypes,
                    ft_index        = ft_index,
                    covars          = covars,
                    covars_in       = covars_in,
                    made_covars     = made_covars,
                    cv_index        = cv_index,
                    transforms      = transforms,
                    made_transforms = made_transforms,
                    dot_args        = list(...))
  wrap_opts
}
