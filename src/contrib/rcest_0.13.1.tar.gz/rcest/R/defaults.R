# An optimizer based on the optim function shipped with base R
optim_fn <- function(pars, lfun, wrap_opts, method, optopt) {

  if (!"iterations" %in% names(optopt)) optopt$iterations <- 1000
  if (! "report"    %in% names(optopt)) optopt$report     <- TRUE
  if (! "lower"     %in% names(optopt)) optopt$lower      <- -Inf
  if (! "upper"     %in% names(optopt)) optopt$upper      <- Inf

  if (optopt$report) trace <- 1
  else               trace <- 0

  if (! method %in% c("Brent")) {
    method <- toupper(method)
  }

  controls <- list(fnscale = -1, trace = trace, maxit = optopt$iterations)
  opt_res <- optim(par = pars,
                   fn = lfun_wrap,
                   method = method,
                   lower = optopt$lower,
                   upper = optopt$upper,
                   hessian = FALSE,
                   lfun = lfun,
                   wrap_opts = wrap_opts,
                   sum_res = TRUE,
                   control = controls)

  list(estimates = opt_res$par, likelihood = opt_res$value)
}

runonce_fn <- function(pars, lfun, wrap_opts, method, optopt) {
  out <- lfun_wrap(par = pars, lfun = lfun, wrap_opts = wrap_opts, sum_res = TRUE)
  list(estimates = pars, likelihood = out)
}

#' @title Set default environment options for rcest
#'
#' @description Since set_rcenv can clear the default environments, this
#' function provides a way to quickly recover them
#'
#' @export set_rcdefault
set_rcdefault <- function() {

  # Set some optimizers that use the build-in optim function
  set_optimizer(method = c("Nelder-Mead", "nelder-mead"), type = "ml", fn = optim_fn)
  set_optimizer(method = c("BFGS", "bfgs"),               type = "ml", fn = optim_fn)
  set_optimizer(method = c("CG", "cg"),                   type = "ml", fn = optim_fn)
  set_optimizer(method = c("SANN", "sann"),               type = "ml", fn = optim_fn)
  set_optimizer(method = c("Brent", "brent"),             type = "ml", fn = optim_fn)
  set_optimizer(method = c("L-BFGS-B", "l-bfgs-b"),       type = "ml", fn = optim_fn)
  # Optimizers hand-implemented in this package
  set_optimizer(method = c("runonce", "RUN_ONCE"),        type = "ml", fn = runonce_fn)
  set_optimizer(method = c("Newton-Rhapson", "NR", "nr"), type = "ml", fn = nr_opt)
  set_optimizer(method = c("Newton's Root Finder", "Newton's Method", "NRF", "nrf"),
                type = "ml", fn = nr_opt)

  set_transform(name = "none",
                g    = function(x) x,
                gi   = function(x) x,
                gp   = function(x) 1)

  set_transform(name = "exp",
                g    = function(x) exp(x),
                gi   = function(x) log(x),
                gp   = function(x) exp(x))

  set_transform(name = "logit",
                g    = function(x) 1 / (1 + exp(-x)),
                gi   = function(x) -log((1 / x) - 1),
                gp   = function(x) exp(-x) / (exp(-x) + 1)^2)

  # Set some regex
  set_profile(
    name = "standard",
    outcomes = profile_setup_fn,
    probabilities = profile_setup_fn,
    times  = profile_setup_fn,
    choice = function(inst, fname, layout, ...) which(colnames(inst) == "choice"),
    task   = function(inst, fname, layout, ...) which(colnames(inst) == "task"),
    ID     = function(inst, fname, layout, ...) which(colnames(inst) == "ID"),
    Max    = function(inst, fname, layout, ...) which(colnames(inst) == "Max"),
    Min    = function(inst, fname, layout, ...) which(colnames(inst) == "Min")
  )

  set_profile(
    name = "AB",
    outcomes = AB_profile_setup_fn,
    probabilities = AB_profile_setup_fn,
    times  = AB_profile_setup_fn,
    choice  = function(inst, fname, layout, ...) which(colnames(inst) == "choice"),
    task    = function(inst, fname, layout, ...) which(colnames(inst) == "task"),
    ID      = function(inst, fname, layout, ...) which(colnames(inst) == "ID"),
    Max     = function(inst, fname, layout, ...) which(colnames(inst) == "Max"),
    Min     = function(inst, fname, layout, ...) which(colnames(inst) == "Min")
  )

  # Set default cvb
  set_cvb(c("identity",    "id"),         cvb_identity)
  set_cvb(c("dummy",       "d"),          cvb_dummy)
  set_cvb(c("polynomial",  "poly", "p"),  cvb_polynomial)
  set_cvb(c("interaction", "inter", "x"), cvb_interaction)

}
