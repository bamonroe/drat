## Set up environments for set/fetch functions
## For optimizers
top_env <- new.env()

.onLoad <- function(libname, pkgname) {
  # Set the initial (empty) environments
  set_rcenv()
  # Set the default environ functions
  set_rcdefault()
}
