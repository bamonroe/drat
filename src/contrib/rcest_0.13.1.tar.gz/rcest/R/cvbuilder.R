#' @title Set covar builder function
#'
#' @param names the names applied to this builder
#' @param fn the function called when this builder is invoked
#' @export set_cvb
set_cvb <- function(names, fn) {
  # Check the arguments
  if (! is.character(names)) {
    stop("'names' must be a character vector")
  }
  if (! is.function(fn)) {
    stop("'fn' must be a function")
  }
  # Check that the function has all the necessary parameters defined
  req_args <- c("inst")
  fn_check(fn, req_args, "fn")

  # The default name for this cvb
  def_name <- names[1]
  # Create the environment elements if they're not there
  for (v in c("maps", "fn")) {
    if (! v %in% ls(envir = top_env$covar_env)) {
      top_env$covar_env[[v]] <- list()
    }
  }
  # All names map to the def_name
  for (n in names) {
    top_env$covar_env[["maps"]][[n]] <- def_name
  }
  # The function is mapped to the def_name only
  top_env$covar_env[["fn"]][[def_name]] <- fn
}

avail_cvb <- function() {
  names(unlist(top_env$covar_env$maps))
}

#' @title Covar Builder class
#'
#' @description
#' This class is recognized as a special element of a covars list which
#' indicates the inst needs to be adjusted depeding on the contents
#'
#' @import methods
#' @exportClass  cvb
setClass("cvb", slots = c("name" = "character", "dargs" = "list"))

#' @title Covar Builder List
#'
#' @description
#' This is a list of cvb elements which is recognized by covar_sanitize as a
#' cvar vector, and is applied to parameters accordingly.
#'
#' @import methods
#' @exportClass  cbvec
setClass("cbvec", slots = c("values" = "list"))

#' @title Union type for combine methods
#'
#' @import methods
#' @exportClass  cbunion
setClassUnion("cbunion", c("cvb", "cbvec", "numeric", "character", "NULL"))

#' @title Combine, 'c', method when a "cvb" object is in dots
#' @import methods
#' @export
setMethod(f = "c",
          signature = "cbunion",
          definition = function(x, ...) {
            da <- list(x, ...)
            nda <- names(da)
            olist <- list()
            count <- 0
            for (i in seq_along(da)) {
              v  <- da[[i]]
              nv <- nda[i]
              if (is.numeric(v)) {
                if (nv == "") {
                  stop(paste0("Argument '", i, "' is numeric but needs to be named"))
                }
                o <- list("identity", v)
                names(o) <- c("name", nv)
                count <- count + 1
                olist[[count]] <- do.call(cvb, o)
              } else if (is.character(v)) {
                o <- list("identity", 0)
                names(o) <- c("name", v)
                count <- count + 1
                olist[[count]] <- do.call(cvb, o)
              } else if (is(v, "cvb")) {
                count <- count + 1
                olist[[count]] <- v
              } else if (is(v, "cbvec")) {
                values <- slot(v, "values")
                for (j in seq_along(values)) {
                  count <- count + 1
                  olist[[count]] <- values[[j]]
                }
              } else if (! is.null(v)) {
                stop(paste0("Cannot combine argument '", i, "' with remaining vector."))
              }
            }
            new("cbvec", values = olist)
})

#' @title Covar builder placeholder
#'
#' @description This function can be called in a covars list to generate
#' placeholders for covars which will be filled in by a covar builder
#'
#' @param name the name of the builder function
#' @param ... named variables passed to the function
#' @export cvb
cvb <- function(name, ...) {
  if (! name %in% avail_cvb()) {
    stop(paste0("cvb '", name, "' not in covar environment. Did you forget to set it?"))
  }
  new("cvb", name = name, dargs = list(...))
}

get_cvb <- function(name) {
  # Check the arguments
  if (! is.character(name)) {
    stop("cvbuilder 'name' must be a character vector")
  }
  if (length(name) != 1) {
    stop("Only one name can be specified for 'get_cvb'")
  }
  name <- top_env$covar_env$maps[[name]]
  fn   <- top_env$covar_env$fn[[name]]
  fn
}

#' @title Adjust instrument for cvb covars
#'
#' @description
#' This function adjusts the inst to make new vars based on the cvb functions.
#' It also removes the cbvec objects from the covars and replaces it with
#' proper cvecs.
#'
#' @param covars a sanitized covars list
#' @param inst the inst to be used for estimation
#'
#' @export inst_adjust
inst_adjust <- function(covars, inst) {
  nftypes <- names(covars)

  covars_i <- covars
  covars_o <- covars

  for (ci in seq_along(covars)) {
    ft <- nftypes[ci]
    cv <- covars[[ci]]
    pnames <- names(cv)

    for (i in seq_along(cv)) {
      cvec    <- cv[[i]]
      parname <- pnames[i]

      if (is(cvec, "cbvec")) {
        cvals <- cvec@values

        # The new cvec that'll be inserted in place here.
        ncvec <- c()
        # The new cvbvec that'll replace the input vec
        ncbvec <- c()

        for (bi in seq_along(cvals)) {
          cb <- cvals[[bi]]

          # Get the function name and args from the s4 class slots
          bname      <- slot(cb, "name")
          bargs      <- slot(cb, "dargs")

          # Get the covar builder function and call it
          bfn        <- get_cvb(bname)
          bargs$inst <- inst
          bres       <- do.call(bfn, bargs)

          # Check that the cvb returns an OK output
          bres_check(bres, ft, bname, parname)

          # We only get three results, init and cvb are optional
          gen_vars <- bres$vars
          new_init <- bres$init
          new_cvb  <- bres$cvb

          # Add the new cvb if it exists, the above check ensures it's a cvb
          if (! is.null(new_cvb)) {
            ncbvec <- c(ncbvec, new_cvb)
          } else {
            ncbvec <- c(ncbvec, cb)
          }

          nnames <- colnames(gen_vars)
          inames <- colnames(inst)

          new_vars <- nnames[! nnames %in% inames]
          if (length(new_vars) > 0) {
            inst[, new_vars] <- gen_vars[, new_vars]
          }

          names(new_init) <- nnames
          ncvec <- c(ncvec, new_init)
        }
        # Get rid of duplicates for the new vec
        ncvec <- ncvec[match(unique(names(ncvec)), names(ncvec))]
        covars_i[[ci]][[i]] <- ncbvec
        covars_o[[ci]][[i]] <- ncvec
      }
    }
  }
  return(list(inst = inst, covars_o = covars_o, covars_i = covars_i))
}

bres_check <- function(bres, ft, bname, parname) {
  gen_vars <- bres$vars
  new_init <- bres$init
  new_cvb  <- bres$cvb

  if (! is.numeric(new_init)) {
    msg <- paste0("The 'init' returned by cvb '", bname,
                  "' for ftype '", ft, "', parameter '", parname, "'",
                  " isn't a numeric vector")
    stop(msg)
  }
  if (! is.data.frame(gen_vars)) {
    msg <- paste0("The 'vars' returned by cvb '", bname,
                  "' for ftype '", ft, "', parameter '", parname, "'",
                  " isn't a data.frame")
    stop(msg)
  }
  if (! is.null(new_cvb) & ! is(new_cvb, "cvb")) {
    msg <- paste0("The 'cvb' returned by cvb '", bname,
                  "' for ftype '", ft, "', parameter '", parname, "'",
                  " isn't a cvb object")
    stop(msg)
  }
  if (ncol(gen_vars) != length(new_init)) {
    msg <- paste0("The length of 'init' and ncol of `vars' returned by cvb '", bname,
                  "' for ftype '", ft, "', parameter '", parname, "'",
                  " are not the same")
    stop(msg)
  }
}
