# Get the parameter names of a fname
ftype_names <- function(ft, ftypes) {
  if (!ft %in% names(ftypes)) stop("ftype '" %+% ft %+% "' is not in the ftypes list")
  fn        <- ftypes[[ft]]
  fte       <- top_env$parser_env[[ft]]
  def_pars  <- fte$foptions[[fn]]$def_pars
  par_names <- fte$foptions[[fn]]$par_names
  par_names
}

#' Sanitize the ftypes
#'
#' @description Generate a new ftype list, that replaces ftypes with default
#' when empty, and with the first name when not.
#'
#' @param ftypes list of function types
#' @export ftype_sanitize
ftype_sanitize <- function(ftypes = list()) {
  function_types <- ls(envir = top_env$parser_env)
  nftypes        <- names(ftypes)

  if (! all(nftypes %in% function_types)) {
    nft <- nftypes[! nftypes %in% function_types]
    nft <- paste(nft, collapse = ", ")
    msg <- "ftypes '" %+% nft %+%
      "' are in the ftype list, but not in the environment, did you forget to set them?"
    stop(msg)
  }

  for (ft in nftypes) {
    fn <- ftypes[[ft]]
    fetched      <- get_parser(ft, fn)
    ftypes[[ft]] <- fetched$fname
  }

  return(ftypes)
}

#' Main parameter index for different fun types
#'
#' @param ftypes list of ufun, pfun, sfun, tfun, dfun
#' @export ftype_index
ftype_index <- function(ftypes) {
  ftypes     <- ftype_sanitize(ftypes)
  fpars      <- init_sanitize(ftypes)
  fpars_len  <- lapply(fpars, length)

  index <- fpars_len

  for (i in seq_len(length(fpars_len))) {
    if (i == 1) {
      if (fpars_len[[1]] > 0) {
        index[[1]] <- 1:fpars_len[[1]]
      } else {
        index[[1]] <- 0
      }
    } else {
      j <- index[[i - 1]]
      index[[i]] <- max(j)
      if (fpars_len[[i]] > 0) {
        index[[i]] <- max(j) + 1:fpars_len[[i]]
      } else {
        index[[i]] <- max(j)
      }
    }
  }

  for (i in seq_len(length(fpars_len))) {
    if (fpars_len[[i]] == 0) {
      index[[i]] <- 0
    }
  }

  return(index)
}

#' @title Set ftype parser
#'
#' @description Return the functions available to use
#'
#' @param ftype the name of the new ftype
#' @param fname a character vector of names to define this function
#' @param transforms a vector of transforms for each parameter in the function
#' @param def_pars a vector of default parameters for the function
#' @param par_names a vector or names for the parameters in the function
#' @param description an optional description applied to all fnames
#' @export set_parser
set_parser <- function(ftype, fname,
                       transforms  = NA,
                       def_pars    = NA,
                       par_names   = NA,
                       description = NA,
                       set_default = FALSE) {

  if (! is.character(ftype))       stop("'ftype' needs to be a character string")
  if (! is.character(fname))       stop("'fname' needs to be a character string")
  if (! is.character(transforms))  stop("'transforms' needs to be a character string")
  if (! is.numeric(def_pars))      stop("'def_pars' need to be numeric")
  if (! is.character(par_names))   stop("'par_names' need to be a character string")
  if (! is.character(description)) stop("'description' need to be a character string")

  lt <- length(transforms)
  ld <- length(def_pars)
  lp <- length(par_names)
  if (length(unique(c(lt, ld, lp))) != 1) {
    msg <- paste0("The vector arguments are lengths: ",
                  "'transforms'=", lt, ", ",
                  "'def_pars'=", ld, ", ",
                  "'par_names'=", lp, ", ",
                  "and they need to be the same.")
    stop(msg)
  }

  # foptions is actually the meat of the thing. A named list of fnames fmaps
  # tells you which foption to actually look for because there are several
  # names allowed. fdefault tells you what is the default fname for thie ftype

  if (! ftype %in% ls(envir = top_env$parser_env)) {
    top_env$parser_env[[ftype]] <- list(fmaps    = list(),
                                foptions = list(),
                                fdefault = NA)
  }
  # Fill out foptions as if it's good to go
  foptions <- list(ftype       = ftype,
                   fname       = fname[1],
                   transforms  = transforms,
                   def_pars    = def_pars,
                   par_names   = par_names,
                   description = description)

  # Check if a default function is set
  if (is.na(top_env$parser_env[[ftype]][["fdefault"]])) {
    # if not, set everything
    def_name <- fname[1]
    top_env$parser_env[[ftype]][["fmaps"]][[fname[1]]]    <- def_name
    top_env$parser_env[[ftype]][["foptions"]][[fname[1]]] <- foptions
    top_env$parser_env[[ftype]][["fdefault"]]             <- def_name
  } else {
    def_name <- fname[1]
    top_env$parser_env[[ftype]][["fmaps"]][[fname[1]]]    <- def_name
    top_env$parser_env[[ftype]][["foptions"]][[fname[1]]] <- foptions
    if (set_default) {
      top_env$parser_env[[ftype]][["fdefault"]]           <- def_name
    }
  }

  # The remaining fnames map to the first one
  for (fn in fname[-1]) {
    top_env$parser_env[[ftype]][["fmaps"]][[fn]] <- def_name
  }
}

#' @title Fetch ftype parser
#'
#' @description Return the functions available to use
#'
#' @param ftype the name of the new ftype
#' @param fname the function name of ftype to be fetched
#' @export get_parser
get_parser <- function(ftype, fname) {
  if (! is.character(ftype)) stop("'ftype' arg needs to be a character string")
  if (! is.character(fname)) stop("'fname' arg needs to be a character string")
  if (exists(ftype, envir = top_env$parser_env)) {
    # Check if this ftype is a clone
    if (fname %in% names(top_env$parser_env[[ftype]][["fmaps"]])) {
      fmap <- top_env$parser_env[[ftype]][["fmaps"]][[fname]]
      out  <- top_env$parser_env[[ftype]][["foptions"]][[fmap]]
      return(out)
    } else {
      stop(paste0("fname '", fname, "' is not listed as an available fname for ", ftype,
                 ". Did you forget to set it first?"))
    }
  } else {
    stop(paste0("ftype '", ftype, "' is not listed in the parser_env.",
               " Did you forget to set it first?"))
  }
}
