# Error checks for covar_sanitize
check_covar_sanitizer <- function(ftypes, ft_index, covars) {
  # Just get the names of these things so I don't have to call "names" multiple
  # times
  ncvars  <- names(covars)
  nftypes <- names(ftypes)

  # Check that 'covars' is a list
  if (class(covars) != "list") stop("'covars' needs to be a ftype list")

  # Check that every element of covars is named
  if ("" %in% ncvars) stop("Every element in 'covars' must be named for an ftype")

  # Check that all covar ftypes are in ftype list
  if (! all(ncvars %in% nftypes)) {
    not_in <- paste("'", ncvars[! ncvars %in% nftypes], "'",
                    sep = "", collapse = ", ")
    msg <- "ftypes " %+% not_in %+% " are in covars but not in ftypes"
    stop(msg)
  }

  # Check that every element of covars is a list or numeric/character vector
  # and if a list, check that every element of that list is a NULL, or numeric/character vector
  for (ft in ncvars) {
    cv <- covars[[ft]]
    class_cv <- class(cv)

    check0 <- class_cv %in% c("character", "list", "cbvec", "cvb")
    check1 <- ((class_cv == "numeric") & length(names(cv)) == length(cv))
    check  <- check0 | check1

    if (!check) {
      msg <- "The covar for ftype '" %+% ft %+% "' is not a list, " %+%
             "or named numeric vector or character vector"
      stop(msg)
    } else if (class_cv == "list") {
      i <- 0
      for (ele in cv) {
        i <- i + 1
        if (! class(ele) %in% c("character", "numeric", "cbvec", "cvb", "NULL")) {
          msg <- "Element " %+% i %+% " for covar ftype '" %+% ft %+%
                  "' is not NULL, a numeric or character vector, or a cvb or cbvec"
          stop(msg)
        }
      }
    }
  }

}

# Ensure cvar vecs have the correct form
cvar_vec_to_numeric <- function(cvar) {
  all_char <- is.character(cvar) & length(names(cvar)) == 0
  mix_char <- is.character(cvar) & length(names(cvar)) != 0
  is_empty <- length(cvar) == 0
  is_cvb   <- is(cvar, "cvb")
  # No need to do conversion on fully named numeric vectors, or if they are
  # cbvecs
  outvec <- cvar

  if (is_empty) {
    # Empty outvecs are made NULL types
    outvec <- NULL
  } else if (all_char) {
    outvec <- rep(0, length(outvec))
    names(outvec) <- cvar
  } else if (mix_char) {
    # Figure out which elements were unnamed
    ncvar <- names(cvar)
    nname <- which(ncvar == "")
    ncvar[nname] <- cvar[nname]
    # Replace elements that don't initialize with 0s
    outvec <- cvar
    outvec[nname] <- "0"
    # And covert to numeric
    outvec <- as.numeric(outvec)
    names(outvec) <- ncvar
  } else if (is_cvb) {
    outvec <- new("cbvec", values = list(outvec))
  }

  outvec
}

# Ensure cvar vecs, and cbvecs are expanded to full lists for a given param type
cvar_vec_to_list <- function(cvar, ft, ftypes) {
  pnames <- ftype_names(ft, ftypes)
  if (is(cvar, "cbvec")) {
    out <- cvar
  } else {
    out <- cvar_vec_to_numeric(cvar)
  }
  out    <- lapply(pnames, function(x) out)
  names(out) <- pnames
  out
}

# Ensure cvar lists are expanded to full lists for a given param type
cvar_list_to_list <- function(clist, ft, ftypes) {
  # The names of the parameters for this ftype
  pnames     <- ftype_names(ft, ftypes)
  out        <- vector(mode = "list", length = length(pnames))
  names(out) <- pnames

  # Which named parameters have been declared
  in_names <- names(clist)
  in_names <- in_names[in_names != ""]
  ipnames  <- in_names %in% pnames

  # Check we're not accepting bad names
  if (!all(ipnames)) {
    bad_names <- paste(in_names[!ipnames], collapse = ", ")
    stop("Named pars '" %+% bad_names %+%
         "', are not parameters for function '" %+% ftypes[[ft]])
  }

  # Check that too many parameters haven't been specified
  if (length(clist) > length(pnames)) {
    lcl <- length(clist)
    lpn <- length(pnames)
    stop(lcl %+% " parameters were specified for '" %+%
         ftypes[[ft]] %+% "', this function only accepts " %+% lpn)
  }

  # If we have named parameters assign them
  if (length(in_names) > 0) {
    enames      <- in_names[ipnames]
    out[enames] <- clist[enames]
  }

  # Figure out the remaining initial values to distribute
  if (is.null(in_names)) {
    r_pars <- clist
  } else {
    r_pars <- clist[which(names(clist) == "")]
  }

  i <- 0
  # Go through any remaining list elements and assign them in order of pnames
  for (p in seq_along(pnames)) {
    if (is.null(out[[p]])) {
      i <- i + 1
      if (i <= length(r_pars)) {
        if (!is.null(r_pars[[i]])) {
          out[[p]] <- r_pars[[i]]
        }
      }
    }
  }

  if (length(r_pars) > i) {
    msg <- "You've specified more parameters in the covars for ftype '" %+% ft %+%
           "' than there are parameters for that ftype."
    warning(msg)
  }

  # Sanitize the list of covars
  out <- lapply(out, cvar_vec_to_numeric)
  out
}

#' @title Covariate Sanitizer
#'
#' @description Make a simple covar initial list into a full covar initial list
#'
#' @param covars the simple covar list
#' @param ftypes the ftypes of the full estimated model
#' @return A covar list with every element initialized
#' @export covar_sanitize
covar_sanitize <- function(covars = list(), ftypes = list()) {
  # Sanitize the ftypes
  ftypes <- ftype_sanitize(ftypes = ftypes)
  # The index of the base pars
  ft_index <- ftype_index(ftypes = ftypes)

  # Check that covar ftypes are in ftype list
  check_covar_sanitizer(ftypes, ft_index, covars)

  nftypes <- names(ftypes)
  ncvars  <- names(covars)
  covars  <- lapply(nftypes, function(ft) {
    # Check if this ftype has associated covars, and parse them if so
    if (ft %in% ncvars) {
      cv <- covars[[ft]]
    } else {
      cv <- vector(mode = "numeric", length = 0)
    }
    # Make all stand-alone cvb's into cbvecs
    if (is(cv, "cvb")) cv <- new("cbvec", values = list(cv))
    # There are 3 ways one can specify covars, handle all of them
    if (is.list(cv)) {
      out <- cvar_list_to_list(cv, ft, ftypes)
    } else if (is(cv, "cbvec") | is.vector(cv)) {
      out <- cvar_vec_to_list(cv, ft, ftypes)
    }
    out
  })
  names(covars) <- nftypes

  covars
}

#' @title Covar Index
#'
#' @description ft_index-like list indexing the covars
#'
#' @param covars the simple covar list
#' @param ftypes the ftypes of the full estimated model
#' @return A covar list with every element initialized
#' @export covar_index
covar_index <- function(covars = list(), ftypes = list()) {
  # Quickly return if we can
  if (length(covars) == 0) return(list())

  # Sanitize the ftypes
  ftypes <- ftype_sanitize(ftypes = ftypes)
  # The index of the base pars
  ft_index <- ftype_index(ftypes = ftypes)
  # Sanitize the covars
  covars <- covar_sanitize(covars, ftypes)
  out    <- covars

  start_cvars <- max(unlist(ft_index))
  cvi         <- seq_along(unlist(covars)) + start_cvars

  count <- 1
  # Loop through each covar ftype
  for (ft in names(covars)) {
    cvar <- covars[[ft]]
    for (i in seq_along(cvar)) {
      # Get this parameter, so we can know how many covars were attached to it.
      cvar_i <- cvar[[i]]
      lcvi <- length(cvar_i)
      if (lcvi > 0) {
        # Get the cv index for the number of covars for this parameter
        out[[ft]][[i]] <- cvi[count:(count + lcvi - 1)]
        count <- count + lcvi
      }
    }
  }

  out
}

#' @title Covar Names
#'
#' @description A list giving the names of the covariates for a full covar list
#'
#' @param covars the simple covar list
#' @param ftypes the ftypes of the full estimated model
#' @return A covar list with every element initialized
#' @export covar_names
covar_names <- function(covars = list(), ftypes = list()) {
  if (length(covars) == 0) return(list())

  # Sanitize the ftypes
  ftypes <- ftype_sanitize(ftypes = ftypes)
  # The index of the base pars
  ft_index <- ftype_index(ftypes = ftypes)
  # Sanitize the covars
  covars <- covar_sanitize(covars, ftypes)
  # Make a copy of the covars to be filled with just names
  cnames <- covars

  for (cn in names(covars)) {
    cvar <- covars[[cn]]
    # If this is a multi-parameter covar, it needs special handling
    if (is.list(cvar)) {
      for (i in seq_along(cvar)) {
        if (is.null(cvar[[i]])) {
          in_val <- vector(mode = "character", length = 0)
        } else {
          in_val <- names(cvar[[i]])
        }
        cnames[[cn]][[i]] <- in_val
      }
    } else {
      cnames[[cn]] <- names(cvar)
    }
  }
  cnames[names(covars)]
}

#' @title Adjust covariates for transforms
#'
#' @param ftypes the list of function types
#' @param init the initial parameters of each ftype
#' @param covars the covariate list for each ftypes
#' @param transforms the ftype list of transforms
#' @param ... named variables passed directly to the likelihood function
#' @export mkcovars
mkcovars <- function(ftypes, init = list(), covars = list(), transforms = list()) {
  # Sanatize the initial values
  init <- init_sanitize(ftypes = ftypes, init = init)
  # Sanatize the covariates
  covars <- covar_sanitize(covars = covars, ftypes = ftypes)
  # Sanatize the transforms
  transforms <- trans_make(ftypes = ftypes, transforms = transforms)
  covars_out <- lapply(names(covars), function(ft) {
    # Get the covariates for this ftype
    ct <- covars[[ft]]
    if (length(ct) == 0) return()
    # Get the base parameters for this ftype
    ii <- init[[ft]]

    cout <- lapply(seq_len(length(ii)), function(fi) {
      cf <- ct[[fi]]
      tr <- transforms[[ft]][[fi]]
      val <- sapply(seq_len(length(cf)), function(ci) {
        tr$gi(ii[fi] + cf[ci]) - tr$gi(ii[fi])
      })
      names(val) <- names(cf)
      val
    })
    names(cout) <- names(ct)
    cout
  })
  names(covars_out) <- names(covars)
  covars_out
}
