grad_checker <- function(o, allow_multi_value) {
  if (! all(is.numeric(o))) {
    stop("The function passed to 'grad' does not return a numeric value at " %+%
         "the inital parameters")
  }

  if (! allow_multi_value & length(o) > 1) {
    stop("The function passed to 'grad' does not return a scalar value." %+%
         " Maybe you need 'jacobian'?")
  }
}

#' @title Find the gradient of a function
#'
#' @description Get the gradient of a function using a 2-sided delta method.
#'
#' @param fn the function being derived
#' @param x the parameters at which the gradient is being calulated
#' @param step the size of the step used for the delta. Can be a vector where
#' each element matches to a corresponding x
#' @param glapply The lapply function to use when calculating gradients, defaults to
#' base lapply. You can change this to something else for debugging, or for
#' parallel computation.
#' @param ... named variables passed directly to the function
#' @export grad
grad <- function(fn,
                 x,
                 step = .Machine$double.eps ^ (1 / 3),
                 glapply = base::lapply,
                 ...) {

  # Step can be a vector of different sized steps for the different x's
  yu <- x + step
  yd <- x - step
  # Ensure step is a vector
  step <- yu - x

  gchecker <- T
  # Allow multi-valued objective functions only sometimes. When using grad
  # directly, it isn't meant to allow non-scalar outputs, but with hessian or
  # jacobian it is.
  if (exists("allow_multi_value", envir = parent.frame(), inherits = FALSE)) {
    allow_multi_value <- get("allow_multi_value",
                             envir = parent.frame(),
                             inherits = FALSE)
  } else {
    allow_multi_value <- FALSE
  }

  # Pre allocate the sets of parameters to calculate over
  sets <- base::lapply(seq_along(x), function(i) {
    upper    <- x
    upper[i] <- yu[i]
    lower    <- x
    lower[i] <- yd[i]
    list(u = upper, l = lower, s = step[i])
  })

  # There is scope to parallelize this function here if need be
  out <- glapply(sets, gfun, fn = fn,
                allow_multi_value = allow_multi_value, ...)
  out <- do.call(cbind, out)
  # Collapse the dimensions
  if (nrow(out) == 1) out <- c(out)
  out
}

gfun <- function(pvec, fn, allow_multi_value, ...) {
  a <- fn(pvec$u, ...)
  # Run the checker, but only once
  if (! exists(x = "gchecker")) {
    assign("gchecker", F, envir = parent.frame())
    grad_checker(a, allow_multi_value)
  }
  b <- fn(pvec$l, ...)
  (a - b) / (2 * pvec$s)
}

#' @title Find the jacobian of a function
#'
#' @description Get the jacobian of a function using a 2-sided delta method.
#' The jacobian is the gradient at every observation, so this function mainly
#' provides a convienience wrapper around grad to allow non-scalar functions.
#'
#' @param fn the function being derived
#' @param x the parameters at which the gradient is being calulated
#' @param step the size of the step used for the delta. Can be a vector where
#' each element matches to a corresponding x
#' @param glapply The lapply function to use when calculating gradients,
#' defaults to base lapply
#' @param ... named variables passed directly to the function
#' @export jacobian
jacobian <- function(fn,
                     x,
                     step = .Machine$double.eps ^ (1 / 4),
                     glapply = base::lapply,
                     ...) {
  allow_multi_value <- TRUE
  grad(fn, x, step = step, glapply = glapply, ...)
}

#' @title Find the hessian of a function
#'
#' @description Get the hessian of a function using a 2-sided delta method. The
#' hessian is the gradient of the gradient, so this function mainly provides a
#' convienience wrapper around calls to grad.
#'
#' @param fn the function being derived
#' @param x the parameters at which the gradient is being calulated
#' @param step the size of the step used for the delta. Can be a vector where
#' each element matches to a corresponding x
#' @hlapply The lapply function to use when calculating second derivitives,
#' defaults to base lapply
#' @param glapply The lapply function to use when calculating first
#' derivitives, defaults to base lapply
#' @param ... named variables passed directly to the function
#' @export hessian
hessian <- function(fn,
                    x,
                    step = .Machine$double.eps ^ (1 / 4),
                    hlapply = base::lapply,
                    glapply = base::lapply,
                    ...) {
  allow_multi_value <- TRUE
  grad(fn = gwrap, x = x, step = step, glapply = hlapply,
       iglapply = glapply, ifn = fn, istep = step, ...)
}

gwrap <- function(x, iglapply, ifn, istep, ...) {
  allow_multi_value <- FALSE
  v <- grad(fn = ifn, x = x, step = istep, glapply = iglapply, ...)
  v
}
