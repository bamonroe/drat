#' @title Sanitize the transforms list
#'
#' @description Conduct checks on the transforms list and get it set up.
#' @param ftypes the ftypes
#' @param transforms the ftype list of transforms
#' @export trans_sanitize
trans_sanitize <- function(ftypes = list(), transforms = list()) {
  ftypes <- ftype_sanitize(ftypes)

  # First grab the default transforms
  out_trans <- lapply(names(ftypes), function(ft) {
    pe <- get_parser(ft, ftypes[[ft]])
    tf <- pe$transforms
    names(tf) <- pe$par_names
    tf
  })
  names(out_trans) <- names(ftypes)

  trans_avail <- ls(envir = top_env$trans_env)

  for (ft in names(ftypes)) {
    if (ft %in% names(transforms)) {
      tn <- transforms[[ft]]
      if (! all(is.character(tn))) {
        stop(paste0("You passed a transform for the '", ft,
                    "' ftype that isn't a character string"))
      }
      if ((length(tn) > 0) & (length(out_trans[[ft]]) == length(tn))) {
        if (all(tn %in% trans_avail)) {
          out_trans[[ft]] <- tn
        } else {
          stop(paste0("You passed a transform for the '", ft, "' ftype that isn't set."))
        }
      } else if (length(out_trans[[ft]]) != length(tn)) {
        stop(paste0("You passed ", length(tn), " transform(s) for the '", ft,
                    "' ftype. You need to pass ", length(out_trans[[ft]])))
      }
    }
  }

  # First grab the default transforms
  out_trans <- lapply(names(out_trans), function(ft) {
    pe <- get_parser(ft, ftypes[[ft]])
    tf <- out_trans[[ft]]
    names(tf) <- pe$par_names
    tf
  })
  names(out_trans) <- names(ftypes)

  return(out_trans)
}

#' @title Make the list of transform names a list of transform objects
#'
#' @description Conduct checks on the transforms list and get it set up.
#' @param ftypes the ftypes
#' @param transforms the ftype list of transforms
#' @export trans_make
trans_make <- function(ftypes = list(), transforms = list()) {
  transforms <- trans_sanitize(ftypes, transforms)
  tform_out <- lapply(transforms, function(tf) {
    lapply(tf, get_transform)
  })
  names(tform_out) <- names(transforms)
  tform_out
}

#' @title Init the ftypes
#'
#' @description Generate an init ftype list. A list with sanitized initial
#' values.
#'
#' @param ftypes list of function types
#' @export init_sanitize
init_sanitize <- function(ftypes = list(), init = NULL) {
  ftypes <- ftype_sanitize(ftypes)

  if (is.null(init)) {
    init <- list()
  } else if (is.list(init)) {
    for (ft in names(init)) {
      if (is.null(init[[ft]])) init[[ft]] <- NULL
    }
  }

  out_init <- list()
  for (ft in names(ftypes)) {
    fn        <- ftypes[[ft]]
    fte       <- top_env$parser_env[[ft]]
    def_pars  <- fte$foptions[[fn]]$def_pars
    par_names <- fte$foptions[[fn]]$par_names
    if (ft %in% names(init)) {
      ii <- init[[ft]]
      if (length(ii) != length(def_pars)) {
        stop(paste0("There are ", length(ii),
                    " parameters in the initial values list for the '", ft,
                    "' ftype, there should be ", length(def_pars)))
      }
      if (! all(is.numeric(ii))) {
        stop(paste0("At least one parameter for the '", ft, "' ftype is not numeric"))
      }
      out_init[[ft]] <- ii
    } else {
      out_init[[ft]] <- def_pars
    }
    names(out_init[[ft]]) <- par_names
  }
  return(out_init)
}
