#' @title Get a list of internal environments
#'
#' @export get_rcenv
get_rcenv <- function() {
  envs <- lapply(ls(envir = top_env), function(v) {
    if (endsWith(v, "_env")) {
      strsplit(v, "_env")[[1]][1]
    }
  })
  envs[sapply(envs, is.null)] <- NULL
  out <- lapply(envs, function(env) {
    get(paste0(env, "_env"), envir = top_env)
  })
  names(out) <- envs
  out
}

#' @title Set the set of internal environments
#'
#' @export set_rcenv
set_rcenv <- function(rcenv = list()) {

  env_types <- c("optimizer", "parser", "trans", "profile", "covar")

  if (! is.list(rcenv)) stop("'rcenv' must be a list.")
  if (! all(names(rcenv) %in% env_types)) {
      vals <- paste("'", names(rcenv)[! names(rcenv) %in% env_types], "'",
                    sep = "", collapse = ", ")
    stop(paste0("Elements: ", vals, " do not belong in the rcenv"))
  }
  for (et in names(rcenv)) {
    if (! is.environment(rcenv[[et]])) stop(paste0("'", et, "' is not an environment."))
  }

  for (et in env_types) {
    if (! et %in% names(rcenv)) {
      assign(paste0(et, "_env"), new.env(), envir = top_env)
    } else {
      assign(paste0(et, "_env"), rcenv[[et]], envir = top_env)
    }
  }
}
