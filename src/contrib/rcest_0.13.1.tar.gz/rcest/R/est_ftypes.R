#' @title Return estimates of parameters as ftype and covars list
#'
#' @param res the result of the rcest optimization
#' @export est_ftypes
est_ftypes <- function(res) {
  # Check the res obj
  res_check(res)

  # Sanatize the ftypes
  ftypes <- ftype_sanitize(ftypes = res$ftypes)
  # Sanatize the covariates
  covars <- covar_sanitize(covars = res$covars, ftypes = ftypes)
  # Sanatize the transforms
  transforms <- trans_make(ftypes = ftypes, transforms = res$transforms)
  # The index of the base pars
  ft_index <- ftype_index(ftypes = ftypes)
  # The index of the covars
  cv_index <- covar_index(covars = covars, ftypes = ftypes)

  # Loop through each ftype for this estimation
  init <- lapply(names(ftypes), function(ft) {
    # Get the index of the base parameters in the fullpar vector
    fi <- ft_index[[ft]]
    # If the index says there are no parameters, finish
    if (fi[1] == 0) return()
    # Get the raw estimates for this ftype in the fullpar vector
    ests <- res$estimates[fi]
    # Loop through each of the raw estimates
    for (ei in seq_along(ests)) {
      # Get the tranform for this parameter
      tr <- transforms[[ft]][[ei]]
      # Get the transformed value of the raw estimate
      ests[ei] <- tr$g(ests[ei])
    }
    # Get the parameter name for this ftype
    names(ests) <- ftype_names(ft, ftypes)
    ests
  })
  names(init) <- names(ftypes)

  # Now the covariate
  cv_init <- lapply(names(covars), function(ft) {
    # This a a full clist for this ftype
    ci <- covars[[ft]]
    # The index of the base_par for this ftype
    fi <- ft_index[[ft]]
    # The base_par estimates for this ftype
    bp_ests <- res$estimates[fi]
    # The index of cvars for the parameters of this ftype
    cvi <- cv_index[[ft]]
    # Loop over every parameter in this ftype
    cv_out <- lapply(seq_along(bp_ests), function(bi) {
      # Transforms for this parameter
      tr <- transforms[[ft]][[bi]]
      # Get the index for the set of covars for this parameter in the fullpar
      # vector
      cv_index_for_par <- cvi[[bi]]
      # The names of the covars for this parameter
      cnames <- names(ci[[bi]])
      # Loop through each covariate for this parameter, transforming it from
      # raw estimate to regular
      ovec <- sapply(cv_index_for_par, function(ci) {
        # Get the coefficient for this covar estimate
        cv <- res$estimates[ci]
        # Get the coefficient for basepar associated with this covar
        ee <- res$estimates[fi[bi]]
        # Get the tranformed value of the covariate's coefficient
        out <- tr$g(cv + ee) - tr$g(ee)
        out
      })
      names(ovec) <- cnames
      ovec
    })
    # Get the parameter name for this ftype
    names(cv_out) <- ftype_names(ft, ftypes)
    cv_out
  })
  names(cv_init) <- names(covars)

  list(init = init, covars = cv_init)
}
