#' @title Set optimizer method
#'
#' @param method the name of the method
#' @param type the type of optimizer this is, "ml" or "bayes"
#' @param fn the function that will be called to do the optimizer. See details.
#'
#' @details The "fn" needs to have the following signature:
#' fn <- function(pars, lfun, wrap_opts, method, optopt, ...)
#'
#' where the dots (...) are optional. The function can be anonymous.
#'
#' The parameters are the initial parameters for the function (can go unused),
#' lfun is the user-supplied objective function, ftypes is a sanitized ftype
#' list, ft_index is the ftype list that shows the index of the parameters in
#' the par vector, options are options for the optimizer, and ...  gives
#' additional parameters passed through to the likelihood function. The
#' "options" list should have items for "iterations" governing a stopping
#' condition for iterations, and "report" to determine if or how much verbosity
#' the optimizers should display while solving.
#'
#' @export set_optimizer
set_optimizer <- function(method, type = "ml", fn = NULL) {

  if (! all(is.character(method))) {
    stop("The name(s) listed in the 'method' argument must all be strings")
  }
  opt_types <- c("ml", "bayes")
  if (! type %in% opt_types) {
    stop("The 'type' argument must be either 'ml' for Maximum Likelihood," %+%
         " or 'bayes' for Baysian")
  }
  if (! is.function(fn)) stop("'fn' must be a function")

  # Check that the optim function has all the necessary parameters defined
  req_args <- c("pars", "lfun", "wrap_opts", "method", "optopt")
  fn_check(fn, req_args, "fn")

  fn <- compiler::cmpfun(fn)

  for (m in method) {
    assign(x = m, value = list(type = type, fn = fn), envir = top_env$optimizer_env)
  }
}

get_optimizer <- function(method) {
  if (! method %in% ls(envir = top_env$optimizer_env)) {
    stop("The method '", method,
         "' is not avaialable. Did you forget to set it?")
  }
  get(method, envir = top_env$optimizer_env)
}
