#' @title Set a transform function for parameters
#'
#' @param name the name of the function that transforms a parameter
#' @param g the function that transforms a parameter
#' @param gi the inverse of the function that transforms a parameter
#' @param gp the option first derivative of the function that transforms a parameter
#' @export set_transform
set_transform <- function(name, g, gi, gp = NULL) {
  if (! is.character(name))
    stop("The 'name' argument of the transform must be a string")
  if (! is.function(g))
    stop("The 'g' argument of the transform must be a function")
  if (! is.function(gi))
    stop("The 'gi' argument of the transform must be a function")
  if ((! is.function(gp)) & (! is.null(gp)))
    stop("The 'gp' argument of the transform must be a function or NULL")

  if (is.null(gp)) {
    gp <- function(x) {
      grad(fn = g, x = x)
    }
  }

  glist <-  list(name = name, g = g, gi = gi, gp = gp)
  assign(x = name, value = glist, envir = top_env$trans_env)
}

#' @title Get a transform function for parameters
#'
#' @param name the name of the function that transforms a parameter
#' @export get_transform
get_transform <- function(name) {
  if (length(name) == 0)
    stop("The name passed to 'get_transform' is of length 0. Something is wrong here.")
  if (! is.character(name))
    stop("The 'name' of the transform must be a string")

  if (name %in% ls(envir = top_env$trans_env)) {
    get(x = name, envir = top_env$trans_env)
  } else {
    stop(paste0("Transform '", name,
                "' not in trans_env. Did you forget to set it with set_transform()?"))
  }
}

#' @title Get a list of available transforms
#'
#' @export avail_transform
avail_transform <- function() {
  ls(envir = top_env$trans_env)
}
