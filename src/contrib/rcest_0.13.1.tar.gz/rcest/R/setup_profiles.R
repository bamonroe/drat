## These functions are to setup some profiles that are common in my
## work

profile_setup_fn <- function(inst, fname, layout, ...) {
  cnames <- colnames(inst)

  option_reg <- "opt[0-9]+_.*"
  uopts <- "opt([0-9]+)_.*"
  if (fname == "outcomes") {
    val <- "_out"
  } else if (fname == "probabilities") {
    val <- "_prob"
  } else if (fname == "times") {
    val <- "_time"
  }

  pat_fun <- function(opt, val) {
    paste0("^opt", opt, val)
  }

  onames <- cnames[grep(pattern = option_reg, x = cnames)]
  opts <- unique(gsub(pattern = uopts, replacement = "\\1", x = onames))
  out <- lapply(opts, function(opt) {
    grep(pattern = pat_fun(opt, val), x = cnames)
  })
  names(out) <- opts
  out
}

AB_profile_setup_fn <- function(inst, fname, layout, ...) {
  cnames <- colnames(inst)

  if (fname == "outcomes") {
    reg  <- "^[AB][0-9]+$"
    root <- "^([AB])[0-9]+$"
  } else if (fname == "probabilities") {
    reg  <- "^p[AB][0-9]+$"
    root <- "^(p[AB])[0-9]+$"
  } else if (fname == "times") {
    reg  <- "^t[AB][0-9]+$"
    root <- "^(t[AB])[0-9]+$"
  }

  full_names <- cnames[grep(pattern = reg, x = cnames)]
  root_names <- unique(gsub(pattern = root, replacement = "\\1", x = full_names))

  out <- lapply(root_names, function(opt) {
    grep(pattern = paste0("^", opt, "[0-9]+$"), x = cnames)
  })
  names(out) <- root_names
  out
}

profile_setup_covar_fn <- function(inst, fname, layout, ...) {
  dots <- list(...)
  # Check for covars and ftypes
  if (! "covars" %in% names(dots)) return()
  if (! "ftypes" %in% names(dots)) dots$ftypes <- list()
  covars  <- rcest::covar_sanitize(covars = dots$covars, ftypes = dots$ftypes)
  gnames <- function(i) {
    if (is.list(i)) lapply(i, gnames)
    else names(i)
  }
  ucnames <- unique(unlist(gnames(covars)))
  if (! all(ucnames %in% colnames(inst))) {
    bad_names <- ! ucnames %in% colnames(inst)
    bad_names <- ucnames[bad_names]
    bad_names <- paste(bad_names, collapse = ", ")
    msg <- paste0("Covars '", bad_names, "' are not in the instument")
    stop(msg)
  }
  covars  <- as.matrix(inst[, ucnames])
  colnames(covars) <- ucnames
  covars
}
