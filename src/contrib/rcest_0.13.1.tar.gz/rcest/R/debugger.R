whoami <- function() {
  val <- deparse(sys.calls()[[sys.nframe()-1]])
  val <- paste0("@@ ", val)
  print(val)
}
