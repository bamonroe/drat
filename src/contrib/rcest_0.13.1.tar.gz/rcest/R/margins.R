marg_wrap <- function(pvec, res, lfun, ...) {
  res$estimates <- pvec
  wo   <- get_wrap_opts(inst       = res$inst,
                        ftypes     = res$ftypes,
                        covars     = res$covars_in,
                        transforms = res$transforms)
  pmat <- pvec_adjust(pvec, wo)
  lfun(pmat, wo$inst, wo$ftypes, wo$ft_index, ...)
}

marg_worker <- function(pvec, res, m, ...) {
  if (is.null(m$par))  m$par <- 1
  if (is.null(m$lfun)) m$lfun <- function(pmat, inst, ftypes, ft_index) pmat

  if (m$type == "full") {
    out <- mean(marg_wrap(pvec, res, m$lfun, ...)[, m$par])
  } else if (m$type == "dydx" & ! is.null(m$b0)) {
    res$inst[[m$dem]] <- m$b0
    b0                <- marg_wrap(pvec, res, m$lfun, ...)[, m$par]
    res$inst[[m$dem]] <- m$b1
    b1                <- marg_wrap(pvec, res, m$lfun, ...)[, m$par]
    out               <- mean(b1 - b0)
    names(out) <- m$dem
  } else if (m$type == "dydx") {
    b0                <- marg_wrap(pvec, res, m$lfun, ...)[, m$par]
    e                 <- (mean(abs(res$inst[[m$dem]])) + 0.0001) * 0.0001
    res$inst[[m$dem]] <- res$inst[[m$dem]] + e
    b1                <- marg_wrap(pvec, res, m$lfun, ...)[, m$par]
    out               <- mean(b1 - b0) / e
    names(out) <- m$dem
  }
  out
}

#' @title Margins calculations
#'
#' @description
#' This is basically a wrapper around delta_parsed to get average marginal
#' effects from estimation. One must supply an 'mset' which is a list of lists
#' which contain the elements: "res", the result of an rcestimation with covmat
#' included, "lfun" the function to be called to calculate whatever effect is
#' desired, "type" the type of margin, either "full" to return the average of
#' the result of lfun or "dydx" to return the average marginal effect. If
#' "dydx" a "dem" is needed, the covariate which will be marginally changed,
#' and optionally, b0 and b1, to explicitly set what different values the covar
#' will be changed from and to.
#'
#' Thus, for discrete variables, b0 and b1 are necessary, and for continuous
#' variables, they are optional.
#'
#' An optional "par" element can also be supplied which will select the "par"
#' column from the result of "lfun".
#'
#' @param mset the list of lists described above
#' @param lafun the lapply function used when going through the mset. One can
#' supply a parallell version since these calculations are all independent.
#' @param ... arguments passed directly to the lfun in the mset.
#' @export margins
margins <- function(mset, lafun = lapply, ...) {
  v <- lafun(mset, function(m) {
    out <- delta_parsed(g     = marg_worker,
                 mu    = m$res$estimates,
                 sigma = m$res$covmat,
                 res   = m$res,
                 m     = m,
                 ...)
    out$margin <- m$type
    out$par    <- m$par
    out$dem    <- ifelse("dem" %in% names(m), m$dem, "")
    out$b0     <- ifelse("b0"  %in% names(m), m$b0,  "")
    out$b1     <- ifelse("b1"  %in% names(m), m$b1,  "")
    cnames <- colnames(out)
    norder <- c("margin", "par", "dem", "b0", "b1")
    norder <- c(norder, cnames[!cnames %in% norder])
    out[, norder]
  })
  v <- do.call(rbind, v)
  v
}
