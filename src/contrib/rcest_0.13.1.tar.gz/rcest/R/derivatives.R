deriv_selector <- function(deriv_type) {
  deriv_prov <- getOption("rcest_deriv", default = "rcest")

  if (deriv_type == "grad") {
    if      (deriv_prov == "rcest")    deriv_fun <- rcest::grad
    else if (deriv_prov == "numDeriv") deriv_fun <- numDeriv::grad
    else if (deriv_prov == "pracma")   deriv_fun <- pracma::grad
  } else if (deriv_type == "hessian") {
    if      (deriv_prov == "rcest")    deriv_fun <- rcest::hessian
    else if (deriv_prov == "numDeriv") deriv_fun <- numDeriv::hessian
    else if (deriv_prov == "pracma")   deriv_fun <- pracma::hessian
  } else if (deriv_type == "jacobian") {
    if      (deriv_prov == "rcest")    deriv_fun <- rcest::jacobian
    else if (deriv_prov == "numDeriv") deriv_fun <- numDeriv::jacobian
    else if (deriv_prov == "pracma")   deriv_fun <- pracma::jacobian
  } else {
    stop(paste0("'",
                deriv_type,
                "' was passed as a deriv type and this doesn't make sense."))
  }
  deriv_fun
}

deriv_wrap <- function(deriv_type, par, lfun, wrap_opts, ...) {
  deriv_fun <- deriv_selector(deriv_type)
  sum_res   <- if (deriv_type == "jacobian") FALSE else TRUE
  deriv_fun(lfun_wrap, par,
            lfun      = lfun,
            wrap_opts = wrap_opts,
            sum_res   = sum_res,
            ...)
}

#' @title Calculate Numeric Derivitives of Likelihood Function
#'
#' @param res the result of the rcest optimization
#' @param inst the inst passed to rcest
#' @param lfun the lfun passed to rcest
#' @param deriv the type of derivitive, "grad", "jacobian", or "hessian"
#' @param ... the ... passed to rcest
#'
#' @export calc_deriv
calc_deriv <- function(res = NULL,
                       inst = NULL,
                       lfun = NULL,
                       deriv = "grad",
                       ...) {

  # Check the res obj
  res_check(res)
  # Check the inst obj
  inst_check(inst)

  if (is.null(lfun))
    stop("You need to pass in the lfun used in the rcest function")

  if (! deriv %in% c("grad", "jacobian", "hessian")) {
    stop("'derive' must be one of 'grad', 'jacobian', or 'hessian'")
  }

  wrap_opts <- get_wrap_opts(inst = inst,
                             ftypes = res$ftypes,
                             covars = res$covars,
                             transforms = res$transforms,
                             init = list(), ...)

  out_deriv <- deriv_wrap(deriv_type = deriv,
                          par = res$estimates,
                          lfun = lfun,
                          wrap_opts = wrap_opts)

  out_deriv

}

#' @title Calculate the Covariance Matrix
#'
#' @description Calculate the covariance matrix of a set of estimates,
#' optionally clustering on multiple variables.
#'
#' @param res the result of the rcest optimization
#' @param inst the inst passed to rcest
#' @param lfun the lfun passed to rcest
#' @param cluster the variables to cluster on
#' @param do_par calculate the hessian in parallel?
#' @param cl the cluster object for parallelization
#' @param ... the ... passed to rcest
#'
#' @export calc_covmat
calc_covmat <- function(res = NULL, inst = NULL, lfun = NULL, cluster = NULL,
                        do_par = FALSE, cl = NULL,
                        ...) {

  # Check the res obj
  res_check(res)
  # Check the inst obj
  inst_check(inst)

  if (is.null(lfun))
    stop("You need to pass in the lfun used in the rcest function")

  if (! is.null(cluster)) {
    if (! all(cluster %in% colnames(inst))) {
      stop(paste0("cluster variable '",
                  cluster[! cluster %in% colnames(inst)],
                  "' is not in the inst"))
    }
  }

  # If we're doing it in parallel
  if (do_par) {
    hlapply <- function(...) {
      list(...) # Force promises to resolve
      parallel::parLapplyLB(cl = cl, ...)
    }
  } else {
    hlapply <- base::lapply
  }

  wrap_opts <- get_wrap_opts(inst = inst,
                             ftypes = res$ftypes,
                             covars = res$covars_in,
                             transforms = res$transforms,
                             init = list(), ...)

  # Implement a Sandwich, Huber & White clustered estimator for the covariance
  # matrix
  # Bread %*% Meat %*% Bread
  # The Bread is the inverse of the hessian over the whole likelihood function
  # The Meat is the summed crossproduct of the gradient at each cluster

  # First the bread
  hessian <- deriv_wrap(deriv_type = "hessian", par = res$estimates,
                        lfun = lfun, wrap_opts = wrap_opts,
                        hlapply = hlapply)

  # Inverse of the hessian (Also the non-corrected standard errors)
  covmat <- tryCatch(solve(-hessian), error = function(e) NA)
  if (is.na(covmat[1])) {
    return(NA)
  }

  if (! is.null(cluster)) {
    for (c_var in cluster) {
      # The variable to cluser on
      cluster_var <- inst[[c_var]]
      uids        <- unique(cluster_var)
      clusters    <- length(uids)
      if (clusters == 1) next
      # Implement a sandwich estimator
      # Calculate the Jacobian for the full dataset
      jacobian <- deriv_wrap(deriv_type = "jacobian", par = res$estimates,
                             lfun = lfun, wrap_opts = wrap_opts,
                             glapply = hlapply)

      # Now for each cluster, reduce the jabobian to the gradient, just a colsum
      meat <- lapply(uids, function(uid) {
          # Which rows of the jacobian belong to the cluster
          rkeep <- which(cluster_var == uid)
          # The gradient is just the element sum of the jacobian for every
          # observation If there is only one observation for a cluster, than
          # the jacobian of that observation is the gradient. But I think it's
          # probably a mistake if this occurs, so warn.
          if (length(rkeep) == 1) {
            warning(paste0("Cluster var has only one observation for uid: ",
                           uid))
            ngrad <- jacobian[rkeep, ]
          } else {
            ngrad <- colSums(jacobian[rkeep, ])
          }
          # Cross product
          tcrossprod(-ngrad, -ngrad)
        })
      meat <- Reduce(f = "+", x = meat) # Sum all the cross products by element

      # Implement the sandwich and save it so it can be used with the next
      # cluster variable, if there is one, or returned.
      covmat <- covmat %*% meat %*% covmat

      # Adjust the covmat for finite sample size corrections. See Fuller et al.
      # (1986) and Mackinnon and White (1985).
      covmat  <- covmat * (clusters / (clusters - 1))
    }
  }

  return(covmat)
}
