#' @title Adjust initial values for transforms
#'
#' @param ftypes the list of function types
#' @param init the initial parameters of each ftype
#' @param transforms the ftype list of transforms
#' @param ... named variables passed directly to the likelihood function
#' @export mkinit
mkinit <- function(ftypes, init = list(), transforms = list()) {
  # Sanatize the initial values
  init <- init_sanitize(ftypes = ftypes, init = init)
  # Sanatize the transforms
  transforms <- trans_make(ftypes = ftypes, transforms = transforms)
  init_out <- lapply(names(init), function(ft) {
    ii <- init[[ft]]
    if (length(ii) == 0) return()
    sapply(seq_along(ii), function(fi) {
      tr <- transforms[[ft]][[fi]]
      tr$gi(ii[fi])
    })
  })
  names(init_out) <- names(init)
  init_out
}
