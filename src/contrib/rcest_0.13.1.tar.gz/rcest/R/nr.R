default_optopt <- function(optopt, name, dvalue) {
  if (! name %in% names(optopt)) {
    optopt[[name]] <- dvalue
  }
  optopt
}
nr_option_defaults <- function(optopt) {

  optopt <- default_optopt(optopt, "grad_break", 1e-6)
  optopt <- default_optopt(optopt, "lambda_break", 0.00001)
  optopt <- default_optopt(optopt, "lambda_upscale", 1)
  optopt <- default_optopt(optopt, "lambda_downscale", 2)
  optopt <- default_optopt(optopt, "negdef_scalar", 10)
  optopt <- default_optopt(optopt, "iterations", Inf)
  optopt <- default_optopt(optopt, "report", FALSE)
  optopt <- default_optopt(optopt, "trace", 0)

  # For Parallel computing
  optopt <- default_optopt(optopt, "hlapply", base::lapply)
  optopt <- default_optopt(optopt, "glapply", base::lapply)
  optopt <- default_optopt(optopt, "parallel", FALSE)
  optopt
}

# Try and force the hessian to negitive definite by adjusting until we have all
# negitive eigen values
hessian_negdef <- function(h, optopt) {
  # An identity matrix
  nrh   <- nrow(h)
  iden  <- diag(ifelse(is.null(nrh), 1, nrh))
  count <- 0
  # Loop until all eigenvalues are negitive
  e <- eigen(h)$values
  while ((max_e <- max(e)) > 0) {
    count <- count + 1
    # We're giving up after 100 iterations, it shouldn't take more than 1
    if (count > 100) break
    # Adding max_e + epsilon is enough to make it negitive definite, but we
    # want it to be a bit more than than because the implied step size will be
    # too big for sure. So make epsilon something that has something to do with
    # the hessian matrix
    ah <- abs(h)
    mt <- max_e + max(ah) - min(ah)
    h  <- h - iden * mt
    # Calculate eigenvalues to check again
    e <- eigen(h)$values
  }
  h
}

nr_convreport <- function(res, optopt) {
  if (optopt$report) {
    if (res$retcode == 0) {
      cat("Converged, gradient close to 0\n")
    } else if (res$retcode == 1) {
      cat("No improvment could be found, not perfect convergance\n")
    } else if (res$retcode == 2) {
      cat("Iteration limit reached\n")
    }
    cat("fn:", res$value, "\n")
    if (optopt$trace > 0) {
      cat("x:", res$par, "\n")
    }
    if (optopt$trace > 1) {
      cat("grad:", res$grad, "\n")
    }
  }
}

#' @title Newton-Rhapson Optimizer
#'
#' @description Finds the maximum of a function
#'
#' @param x the initial parameters of the function
#' @param fn the objective function being maximized
#' @param optopt a list of options for the optimizer
#' @param ... named variables passed directly to the objective function
#' @export nr
nr <- function(x, fn, optopt = list(), ...) {

  # Set default options
  optopt <- nr_option_defaults(optopt)

  # iteration break
  ibreak <- F
  # lambda break
  lbreak <- F
  # gradient break
  gbreak <- F

  # I have (tentative) support for multiple providers of gradient functions.
  gfun <- deriv_selector("grad")
  hfun <- deriv_selector("hessian")

  # Initial values
  x0 <- x
  x1 <- x0
  l0 <- fn(x0, ...)

  # Lambda is a scaling parameter. Since basically every problem we'll actually
  # want to solve is not a quadratic, we want to overstep or understep the
  # quadratic prediction.
  lambda <- 1
  count  <- 0
  while (TRUE) {
    # Test if we're breaking iterations
    if (count >= optopt$iterations) {
      ibreak <- T
      break
    }

    # If we're adjusting lambda, we don't need to re-calculate g and h
    docalc <- identical(x0, x1)

    # Calculate the gradient
    if (docalc) g <- gfun(fn, x0, glapply = optopt$glapply, ...)

    # Check if the gradient is within the tolerance of 0
    if (all(abs(g) < optopt$grad_break)) {
      gbreak <- T
      break
    }

    # Increment the count if we haven't broken out
    count <- count + 1
    if (optopt$report && docalc)
      cat(paste0("Iteration: ", count, ", fn: ", l0), "\n")

    # If we're not rescaling, calculate the hessian, ensure it's negitive
    # definite, calculate the proposed delta from the previous parameters
    # vector
    if (docalc) {
      h0 <- hfun(fn, x0, hlapply = optopt$hlapply, ...)
      h1 <- hessian_negdef(h0, optopt)
      if (!identical(h0, h1) && optopt$trace > 0) {
        cat("Hessian not negitive definite. Adjusting.\n")
      }
      p <- qr.solve(-h1, g)
    }

    # Calculate next step
    if (!docalc && optopt$trace > 0) cat("Rescaling next step\n")
    x1 <- x0 + lambda * p
    l1 <- fn(x1, ...)
    l1 <- if (!is.finite(l1)) -Inf else l1

    if (optopt$trace > 0) {
      cat("x0:", x0, "\n")
      cat("x1:", x1, "\n")
    }
    if (optopt$trace > 1) {
      cat("g:",  g,  "\n")
      cat("l0:", l0, "\n")
      cat("l1:", l1, "\n")
    }

    if (l1 > l0) {
      x0 <- x1
      l0 <- l1
      lambda <- lambda * optopt$lambda_upscale
      lambda <- if (lambda < 1) 1 else lambda
    } else {
      count  <- count - 1
      lambda <- lambda / optopt$lambda_downscale
    }
    if (lambda < optopt$lambda_break) {
      lbreak <- T
      break
    }
  }

  retcode <- 0
  if (gbreak) {
    retcode <- 0
  } else if (lbreak) {
    retcode <- 1
  } else if (ibreak) {
    retcode <- 2
  }

  res <- list(par        = c(x0),
              value      = l0,
              grad       = g,
              iterations = count,
              retcode    = retcode)
  nr_convreport(res, optopt)
  res
}


#' @title Newton's Root Finding Method
#'
#' @description Finds the root (0 value) of a function
#'
#' @param x the initial parameters of the function
#' @param fn the objective function being maximized
#' @param optopt a list of options for the optimizer
#' @param ... named variables passed directly to the objective function
#' @export nrf
nrf <- function(x, fn, optopt = list(), ...) {

  # Set default options
  optopt <- nr_option_defaults(optopt)

  # iteration break
  ibreak <- F
  # lambda break
  lbreak <- F
  # gradient break
  gbreak <- F

  # I have (tentative) support for multiple providers of gradient functions.
  gfun <- deriv_selector("grad")

  # Initial values
  x0 <- x
  x1 <- x0
  l0 <- fn(x0, ...)

  # Lambda is a scaling parameter. Since basically every problem we'll actually
  # want to solve is not a quadratic, we want to overstep or understep the
  # quadratic prediction.
  lambda <- .1
  count  <- 0
  upscale <- F
  while (TRUE) {
    # Test if we're breaking iterations
    if (count >= optopt$iterations) {
      ibreak <- T
      break
    }

    # If we're adjusting lambda, we don't need to re-calculate g and h
    docalc <- identical(x0, x1)

    # Calculate the gradient
    if (docalc) {
      if (optopt$trace > 0) cat("Calculating gradient\n")
      g <- gfun(fn, x0, glapply = optopt$glapply, ...)
    }

    # Check if the gradient is within the tolerance of 0
    if (all(abs(g) < optopt$grad_break)) {
      gbreak <- T
      break
    }

    # Increment the count if we haven't broken out
    count <- count + 1
    if (optopt$report && docalc)
      cat(paste0("Iteration: ", count, ", fn: ", l0), "\n")

    # Calculate next step
    if (!docalc & optopt$trace > 0) {
      if (!upscale) {
        cat("Downscaling next step\n")
      }
    } else if (upscale & optopt$trace > 0) {
        cat("Upscaling next step\n")
    }
    x1 <- x0 + lambda * g
    l1 <- fn(x1, ...)
    l1 <- if (!is.finite(l1)) -Inf else l1

    if (optopt$trace > 1) {
      cat("x0:", x0, "\n")
      cat("x1:", x1, "\n")
    }
    if (optopt$trace > 2) {
      cat("g:",  g,  "\n")
      cat("l0:", l0, "\n")
      cat("l1:", l1, "\n")
    }

    if (l1 > l0) {
      x0 <- x1
      l0 <- l1
      lambda <- lambda * optopt$lambda_upscale
      upscale <- T
    } else {
      count  <- count - 1
      lambda <- lambda / optopt$lambda_downscale
      upscale <- F
    }
    if (lambda < optopt$lambda_break) {
      lbreak <- T
      break
    }
  }

  retcode <- 0
  if (gbreak) {
    retcode <- 0
  } else if (lbreak) {
    retcode <- 1
  } else if (ibreak) {
    retcode <- 2
  }

  res <- list(par        = c(x0),
              value      = l0,
              grad       = g,
              iterations = count,
              retcode    = retcode)
  nr_convreport(res, optopt)
  res
}

# Function for set_optimizer
nr_opt <- function(pars, lfun, wrap_opts, method, optopt) {
  # Set default options
  optopt <- nr_option_defaults(optopt)

  if (optopt$parallel) {
    cl <- optopt$cl
    # Export wrap_opts
    name <- "rcest_wrap_opts"
    assign(name, wrap_opts, envir = .GlobalEnv)
    size <- (format(object.size(wrap_opts), units = "MB"))
    cat("Exporting wrap opts. Size:", size, "...")
    s <- Sys.time()
    parallel::clusterExport(cl = cl,
                            varlist = name,
                            envir = .GlobalEnv)
    e <- Sys.time()
    cat("Done in", e - s, "\n")

    optopt$hlapply <- function(...) {
      list(...) # Force promises to resolve
      parallel::parLapplyLB(cl = cl, ...)
    }

    optopt$glapply <- function(...) {
      list(...) # Force promises to resolve
      parallel::parLapplyLB(cl = cl, ...)
    }
    # Don't carry this around now
    wrap_opts <- name
  }

  if (method == "NR") {
    out <- nr(x = pars,
              fn = rcest::lfun_wrap,
              optopt = optopt,
              sum_res = TRUE,
              wrap_opts = wrap_opts,
              lfun = lfun)
  } else {
    out <- nrf(x = pars,
              fn = rcest::lfun_wrap,
              optopt = optopt,
              sum_res = TRUE,
              wrap_opts = wrap_opts,
              lfun = lfun)
  }

  # Delete the temporary allocation if possible
  if (optopt$parallel) {
    rm(list = name, envir = .GlobalEnv)
  }

  list(estimates = out$par,
       likelihood = out$value,
       retcode = out$retcode,
       grad = out$grad,
       iterations = out$iterations)
}
