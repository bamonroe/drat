# Tests for the pure helpers that do not require compiling a Stan model.

make_dat <- function() {
  data.frame(
    ID = c(1, 1, 2, 2), choice = c(0, 1, 1, 0),
    Max = 10, Min = 0,
    opt1_out1 = 1, opt1_out2 = 2, opt1_prob1 = .5, opt1_prob2 = .5,
    opt2_out1 = 3, opt2_out2 = 4, opt2_prob1 = .5, opt2_prob2 = .5,
    age = c(20, 20, 30, 30), female = c(0, 0, 1, 1)
  )
}

test_that("get_stan_code returns a packaged .stan file", {
  f <- get_stan_code(1)
  expect_true(grepl("\\.stan$", f))
  expect_true(file.exists(f))
})

test_that("save_rcfit round-trips, preserves the object name, and is atomic", {
  tmp <- tempfile(fileext = ".Rda")
  rcfit <- list(a = 1, fname = "m.stan")
  rcstan:::save_rcfit(rcfit, tmp)

  expect_true(file.exists(tmp))
  expect_false(file.exists(paste0(tmp, ".tmp")))  # temp renamed away

  e <- new.env()
  load(tmp, envir = e)
  expect_true("rcfit" %in% ls(e))                 # loads back under name 'rcfit'
  expect_equal(e$rcfit$a, 1)
  unlink(tmp)
})

test_that("validate_inputs accepts well-formed data", {
  dat <- make_dat()
  expect_true(rcstan:::validate_inputs(dat, "()", NULL))
  expect_true(rcstan:::validate_inputs(dat, "(age,female)(age)", "age"))
})

test_that("validate_inputs rejects malformed data up front", {
  dat <- make_dat()

  bad_max <- dat; bad_max$Max <- NULL
  expect_error(rcstan:::validate_inputs(bad_max, "()", NULL), "Max")

  expect_error(rcstan:::validate_inputs(dat, "(nope)", NULL), "covariate")
  expect_error(rcstan:::validate_inputs(dat, "()", "ghost"), "extra_vars")

  mismatch <- dat; mismatch$opt3_out1 <- 5  # option 3 has outs but no probs
  expect_error(rcstan:::validate_inputs(mismatch, "()", NULL), "matching")
})
