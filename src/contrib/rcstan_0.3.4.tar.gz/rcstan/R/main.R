supported_mods <- c(
  "eut_bhm",
  "eut_ep_bhm",
  "rdu_power_bhm",
  "rdu_rw_bhm",
  "rdu_inverses_bhm",
  "rdu_prelec_bhm",
  "rdu_ep_prelec_bhm"
)
mod_map <- function(i) supported_mods[i]

sanitize_for_stata <- function(df) {
  # Replace illegal characters with underscore
  names(df) <- gsub("[^A-Za-z0-9_]", "_", names(df))

  # Make sure names start with a letter or underscore
  names(df) <- ifelse(grepl("^[A-Za-z_]", names(df)),
                      names(df),
                      paste0("v_", names(df)))

  # Truncate to Stata's 32-character limit
  names(df) <- substr(names(df), 1, 32)

  # Make names unique
  names(df) <- make.unique(names(df), sep = "_")

  df
}

covar_split <- function(s) {
  m <- unlist(strsplit(s, ")"))
  v <- lapply(m, function(m) {
    m <- stringr::str_remove(m, "\\(")
    m <- unlist(stringr::str_split(m, ","))
    m <- stringr::str_squish(m)
    m
  })
}

covar_unique <- function(cvars) {
  uvars <- unique(unlist(cvars))
  uvars[uvars!= ""]
}

covar_data <- function(cvars, dat) {
  uvars <- covar_unique(cvars)
  uvars <- stringr::str_sort(uvars)
  dat <- lapply(split(dat, dat$ID), function(sdat) sdat[1, ])
  dat <- do.call(rbind, dat)
  dat[, uvars]
}

covar_ucovars <- function(cvars) {
  uvars <- covar_unique(cvars)
  uvars <- stringr::str_sort(uvars)
  j <- lapply(cvars, function(v) {
    ifelse(uvars %in% v, 1, 0)
  })
  do.call(cbind, j)
}

covar_nest <- function(cvars) {
  count <- 0
  for (i in cvars) {
    j <- i[i != ""]
    count <- count + length(j)
  }
  count
}

# Extra variables for use in Stan
get_extra_vars <- function(stan_data, dat, extra_vars) {

  cnames <- colnames(dat)

  if (is.null(extra_vars)) {
    return(stan_data)
  }

  if (! is.character(extra_vars)) {
    stop("The 'extra_vars' argument needs to be a string")
  }

  # Extra_vars is a comma separated string,
  # So split the string to get the variable names that are to be passed to stan
  extra_vars <- unlist(strsplit(extra_vars, split = ","))
  extra_vars <- trimws(extra_vars)

  namecheck <- extra_vars %in% cnames

  if (any(!namecheck)) {
    missing_names <- extra_vars[!namecheck]
    msg <- paste(missing_names, collapse = ", ")
    msg <- paste0("The following 'extra_vars' are not in the dataset: ", msg)
    stop(msg)
  }

  stan_data$nextra_vars <- as.integer(length(extra_vars))
  stan_data$extra_vars  <- matrix(
    unlist(dat[, extra_vars]),
    nrow = nrow(dat),
    ncol = stan_data$nextra_vars
  )

  return(stan_data)

}


#' @title Get the raw stan code
#' @param mod_num the index of the model in the list of supported models
#' @export
get_stan_code <- function(mod_num = 1) {
  fname <- paste0(mod_map(mod_num), ".stan")
  out <- system.file(package = "rcstan", fname)
  out
}

#' Get the packaged file locally
#' @export
get_files <- function() {
  # Get the file for the stan code
  for (i in seq_along(supported_mods)) {
    fname <- get_stan_code(i)
    file.copy(from = fname, to = getwd(), overwrite = TRUE)
  }
}

# The data needs some checks to make sure it'll run
check_dat <- function(dat) {

  # Is a data.frame
  if (! is.data.frame(dat)) {
    stop("The passed data needs to be a data.frame")
  }

  # Required columns
  cn <- colnames(dat)
  rcn <- c("ID", "choice")
  not_present <- ! rcn %in% cn
  if (any(not_present)) {
    not_present <- paste(rcn[not_present], collapse = ", ")
    not_present <- paste0("The following columns are required but not present: ", not_present)
    stop(not_present)
  }

}

# Fail-fast validation of the inputs, run BEFORE the (potentially weeks-long)
# sampling so that a configuration error surfaces immediately rather than deep
# inside the Stan model after the expensive fit.
validate_inputs <- function(dat, covars, extra_vars) {

  # ID and choice columns
  check_dat(dat)

  cn <- colnames(dat)

  # Contextual-utility columns. dat[["Max"]] silently returns NULL when absent,
  # so an omission would otherwise only fail deep inside the Stan model.
  ctx_missing <- setdiff(c("Max", "Min"), cn)
  if (length(ctx_missing)) {
    stop("The following columns are required but not present: ",
         paste(ctx_missing, collapse = ", "))
  }

  # Outcome / probability column families. There must be at least one option,
  # and every option must carry matching outs and probs columns.
  outs <- grep("opt[0-9]+_out[0-9]+",  cn, value = TRUE, perl = TRUE)
  prbs <- grep("opt[0-9]+_prob[0-9]+", cn, value = TRUE, perl = TRUE)
  if (! length(outs)) {
    stop("No 'opt<k>_out<n>' outcome columns were found in the dataset")
  }
  out_opts <- sort(unique(gsub("opt([0-9]+)_out[0-9]+",  "\\1", outs, perl = TRUE)))
  prb_opts <- sort(unique(gsub("opt([0-9]+)_prob[0-9]+", "\\1", prbs, perl = TRUE)))
  if (! identical(out_opts, prb_opts)) {
    stop("Each option needs matching outcome and probability columns; found ",
         "outcomes for options {", paste(out_opts, collapse = ", "), "} but ",
         "probabilities for options {", paste(prb_opts, collapse = ", "), "}")
  }

  # Covariate columns referenced in the Stata-style covars string
  cvars <- covar_unique(covar_split(covars))
  cv_missing <- setdiff(cvars, cn)
  if (length(cv_missing)) {
    stop("The following covariate columns are referenced in 'covars' but not ",
         "present in the dataset: ", paste(cv_missing, collapse = ", "))
  }

  # Extra variables (same comma-separated parsing as get_extra_vars)
  if (! is.null(extra_vars)) {
    if (! is.character(extra_vars)) {
      stop("The 'extra_vars' argument needs to be a string")
    }
    ev <- trimws(unlist(strsplit(extra_vars, split = ",")))
    ev_missing <- setdiff(ev, cn)
    if (length(ev_missing)) {
      stop("The following 'extra_vars' are not in the dataset: ",
           paste(ev_missing, collapse = ", "))
    }
  }

  invisible(TRUE)
}

# Atomically save the rcfit list: write to a temp file then rename into place,
# so a crash part-way through writing cannot corrupt an existing (possibly
# weeks-old) result. The argument is named 'rcfit' so the object loads back
# under that name, which the Stata 'stan_diagnostics' helper relies on.
save_rcfit <- function(rcfit, file) {
  tmp <- paste0(file, ".tmp")
  save(rcfit, file = tmp)
  file.rename(tmp, file)
  invisible(file)
}

# Atomically write a data.frame to a .dta file (temp file then rename), so a
# crash mid-write cannot leave a truncated posterior in place.
write_dta_atomic <- function(df, path) {
  tmp <- paste0(path, ".tmp")
  haven::write_dta(df, path = tmp)
  file.rename(tmp, path)
  invisible(path)
}

#' @title Esimate the Stan model
#' @param dat the name of the stan file
#' @param covars the stata-style string for covars
#' @param fname the file name of the stan model file
#' @param extra_vars a string of extra variables to pass to Stan
#' @param stan_opts the list of options to pass directly to stan
#' @param diag TRUE to run diagnostics
#' @export
run_stan <- function(dat, covars, fname,
                     extra_vars = NULL, stan_opts = list(), diag = FALSE) {

  # Make sure the dat passes the checks
  check_dat(dat)

  # The number of subjects in this dataset
  nsubs <- length(unique(dat$ID))

  # The number of observations per subject
  ntasks <- unlist(lapply(split(dat, dat$ID), nrow))

  cnames <- colnames(dat)
  # Figure out the number of unique options by parsing the column names
  opts <- cnames[grep("opt([0-9]+)_out[0-9]+", cnames, perl = FALSE)]
  nopts <- gsub("opt([0-9]+)_out[0-9]+", "\\1", opts, perl = FALSE)
  uopts <- sort(unique(nopts))
  nopts <- length(uopts)

  # Figure ou the number of prizes associated with each lottery (to be the same
  # for every lottery)
  outs <- cnames[grep(paste0("opt", uopts[1], "_out([0-9]+)"), cnames, perl = TRUE)]
  nouts <- paste0("opt", uopts[1], "_out([0-9]+)")
  nouts <- gsub(nouts, "\\1", outs, perl = TRUE)
  uouts <- unique(nouts)
  nouts <- length(uouts)

  # Build the stan data list
  stan_data <- list(
    N = nsubs,
    T = ntasks,
    ndat = nrow(dat),
    nopts = nopts,
    nouts = nouts,
    choice = dat$choice
  )

  # We're using the on the fly counts of the number of outcomes and options.
  # It's up to the user to get this right in their code.
  for (opt in uopts) {
    soname <- paste0("outs", opt)
    spname <- paste0("probs", opt)

    oname <- paste0("opt", opt, "_out[0-9]+")
    pname <- paste0("opt", opt, "_prob[0-9]+")

    stan_data[[soname]] <- dat[, grep(pattern = oname, x = cnames, perl = TRUE)]
    stan_data[[spname]] <- dat[, grep(pattern = pname, x = cnames, perl = TRUE)]
  }

  # We add the max and minimum outcomes for Contextual Utility
  stan_data[["Max"]] <- dat[["Max"]]
  stan_data[["Min"]] <- dat[["Min"]]

  # Get the covariates
  csplit     <- covar_split(covars)
  nhyper     <- length(csplit)
  ncvars     <- length(covar_unique(csplit))
  ncovar_est <- covar_nest(csplit)
  cvarmap    <- covar_ucovars(csplit)
  cdat       <- covar_data(csplit, dat)
  # In Stan, this is declared as a matrix, not a vector, so ensure it's a matrix
  if (ncvars == 1) {
    cdat <- matrix(cdat, ncol = 1)
  }

  # Handle the extra data
  stan_data <- get_extra_vars(stan_data, dat, extra_vars)

  # Uncomment to help with debugging
  #print(cvarmap)
  #print(nhyper)
  #print(ncvars)
  #print(ncovar_est)

  stan_data$ncovar_est <- ncovar_est
  stan_data$ncvars     <- ncvars
  stan_data$nhyper     <- nhyper
  stan_data$cvarmap    <- cvarmap
  stan_data$covars     <- cdat

  stan_opts$file <- fname
  stan_opts$data <- stan_data

  # The fitted model
  fit <- do.call(rstan::stan, stan_opts)

  # Save a list object with all the info we've used to generate the fitted object
  rcfit <- list(
    fit       = fit,
    dat       = dat,
    covars    = covars,
    fname     = fname,
    stan_opts = stan_opts
  )

  # Each of the diagnostics are wrapped in tryCatch statements, so we don't need
  # to check for failure conditions here. We'll just let them fail with their
  # appropriate error messages iif needed.
  if (diag) rcfit <- mcmc_diag(rcfit)

  rcfit
}

#' Flatten the fitted model
#' @param rcfit the list returned from \code{run_stan}
#' @export
flatten_fit <- function(rcfit) {
  # Convert the posterior draws to a single matrix. The chain/iteration counts
  # are derived from this matrix rather than from a separate
  # rstan::extract(fit, permuted = FALSE) call: that call only existed to read
  # dim(), but it materialises a second full copy of the entire posterior,
  # which can itself exhaust memory on very long runs.
  mat     <- as.matrix(rcfit$fit)
  nchains <- rcfit$fit@sim$chains
  niter   <- nrow(mat) / nchains

  fit <- as.data.frame(mat)
  rm(mat)

  # Change the naming convention for the array parameters
  cnames <- colnames(fit)
  cnames <- gsub("]$", "", cnames)
  cnames <- gsub("\\[([0-9]+)$", "_\\1", cnames)
  colnames(fit) <- cnames

  # as.matrix() lays the draws out chain-major (all of chain 1, then chain 2,
  # ...), so iter cycles within each chain and chain repeats in blocks.
  fit$iter  <- rep(seq_len(niter))
  fit$chain <- rep(seq_len(nchains), each = niter)

  # Free the duplicated posterior copies before we return.
  gc()

  fit
}

#' Run the diagnostics on a list returned from run_stan
#' @param rcfit the list returned from \code{run_stan}
#' @param save_path optional path to a .Rda file. When supplied, the augmented
#'   \code{rcfit} is atomically re-saved after each diagnostic completes, so a
#'   failure in a later diagnostic (e.g. bridge sampling running out of memory)
#'   cannot lose the diagnostics that already succeeded. Defaults to NULL, which
#'   reproduces the original behaviour of saving nothing.
#' @importFrom utils write.csv
#' @export
mcmc_diag <- function(rcfit, save_path = NULL) {
  # Stubname for saving various CSV files
  fstub <- strsplit(rcfit$fname, ".stan")[[1]]

  # Checkpoint helper: atomically persist the augmented fit after each
  # diagnostic when a save_path was provided. The diagnostics run cheapest
  # first and bridge sampling (the most memory-hungry, and the usual OOM
  # culprit) last, so each checkpoint locks in the results obtained so far.
  checkpoint <- function() if (! is.null(save_path)) save_rcfit(rcfit, save_path)

  # Most of this stuff needs an mcmc.list object
  mlist <- rstan::As.mcmc.list(rcfit$fit)

  # Gelman-Rubin Diagnostic
  rcfit$gelman_diag <- tryCatch({
    print("Running Gelman-Rubin diagnostics")
    gd <- coda::gelman.diag(mlist, multivariate = FALSE)
    write.csv(gd["psrf"],  paste0(fstub, "_psrf.csv"))
    gd
  }, error = function(e) {
    cat("There was an error running the Gelman diagnostics:\n")
    print(e)
    return(NULL)
  })
  checkpoint()

  # Autocorrelation statistics
  rcfit$auto_corr <- tryCatch({
    print("Calculating autocorrelation")
    val <- coda::autocorr.diag(mlist, lags = seq(from = 1, to = 100, by = 1))
    write.csv(val,  paste0(fstub, "_autocorr.csv"))
    val
  }, error = function(e) {
    cat("There was an error running the autocorrelation diagnostics:\n")
    print(e)
    return(NULL)
  })
  checkpoint()

  # Effective sample sizes
  rcfit$effective_size <- tryCatch({
    print("Calculating effective sample size")
    val <- coda::effectiveSize(mlist)
    write.csv(val,  paste0(fstub, "_effectivesize.csv"))
    val
  }, error = function(e) {
    cat("There was an error running the effective size diagnostics:\n")
    print(e)
    return(NULL)
  })
  checkpoint()

  # Estimated marginal likelihood with bridgesampling
  # Return the bridgesampling fit as part of the diagnostics option
  rcfit$bridge <- tryCatch({
    print("Calculating marginal likelihood with bridge sampling")
    bridgesampling::bridge_sampler(samples = rcfit$fit, silent = TRUE)
  }, error = function(e) {
    cat("There was an error running the bridgesampling diagnostics:\n")
    print(e)
    return(NULL)
  })
  checkpoint()

  return(rcfit)
}

#' Fit a model, flatten it, and write to dta
#'
#' The expensive, irreplaceable posterior is persisted to disk (both as the
#' \code{.Rda} fit and as the flattened \code{.dta}) BEFORE any diagnostics are
#' run. Diagnostics can be memory-hungry (bridge sampling especially) and an
#' out-of-memory kill aborts the whole R process, so persisting first ensures a
#' fit that may have taken weeks to sample is never lost to a diagnostic crash.
#'
#' @param infile the path to the input Stata .dta dataset
#' @param outfile the path for the flattened posterior .dta (empty string to skip)
#' @param stan_file the file name of the Stan model file
#' @param covars the Stata-style covariate string
#' @param diag TRUE to run MCMC diagnostics after the posterior is persisted
#' @param stan_opts list of options passed directly to \code{rstan::stan}
#' @param extra_vars a string of extra variables to pass to Stan
#' @param return_fit NULL to return nothing, TRUE for the fit, FALSE for the
#'   flattened posterior
#' @param overwrite TRUE (default) always re-fits. FALSE resumes from an
#'   existing \code{<model>.Rda} when present, reloading the saved fit instead of
#'   re-running what may have been weeks of sampling.
#' @export
fit_to_dta <- function(infile,
                       outfile = "post.dta",
                       stan_file = NA,
                       covars = "",
                       diag = FALSE,
                       stan_opts = list(),
                       extra_vars = NULL,
                       return_fit = NULL,
                       overwrite = TRUE
                       ) {

  # Read in the stata dataset
  dat <- as.data.frame(haven::read_dta(infile))

  # Write the supported models to the current dir
  get_files()

  # Get the file for the stan code
  if (is.na(stan_file)) {
    msg <- paste0("You need to specify a stan file")
    stop(msg)
  } else if (! file.exists(stan_file)) {
    msg <- paste0( "The file '", stan_file, "' does not exist")
    stop(msg)
  }

  # Handle the case where no covars are passed
  if (covars == "") {
    covars <- "()"
  }

  # Validate everything we can up front, so a misconfiguration fails fast
  # instead of only surfacing deep inside Stan after the expensive sampling.
  validate_inputs(dat, covars, extra_vars)

  # The .Rda checkpoint path for this model
  fstub <- strsplit(stan_file, ".stan")[[1]]
  rda   <- paste0(fstub, ".Rda")

  # Resume: when asked not to overwrite and a completed fit already exists,
  # reload it rather than re-running what may have been weeks of sampling.
  # load() restores the object under the name 'rcfit'.
  if (! overwrite && file.exists(rda)) {
    message("Loading existing fit from '", rda, "' (overwrite = FALSE)")
    rcfit <- NULL
    load(rda)
    if (is.null(rcfit)) {
      stop("'", rda, "' did not contain an 'rcfit' object")
    }
  } else {
    # Fit the Stan model. Diagnostics are deliberately NOT run here: we persist
    # the posterior first (below) and only then run diagnostics, so an OOM or
    # crash during diagnostics cannot destroy the fitted posterior.
    rcfit <- run_stan(dat,
      covars = covars,
      fname = stan_file,
      extra_vars = extra_vars,
      stan_opts = stan_opts,
      diag = FALSE
    )

    # Persist the raw posterior IMMEDIATELY, before anything that could fail.
    save_rcfit(rcfit, rda)
  }

  # Flatten to a single matrix and write the Stata deliverable to disk. This
  # also happens before diagnostics, so the posterior is safely available to
  # Stata even if diagnostics later crash the R process.
  ffit <- flatten_fit(rcfit)
  ffit <- sanitize_for_stata(ffit)

  # If given an outfile write it, otherwise return the flattened object
  if (outfile != "") {
    write_dta_atomic(ffit, outfile)
  }

  # Both irreplaceable outputs (.Rda and .dta) are now on disk, so it is safe to
  # run the diagnostics. mcmc_diag checkpoints the augmented fit after each one,
  # so a failure in a later diagnostic cannot lose the earlier results.
  if (diag) {
    rcfit <- mcmc_diag(rcfit, save_path = rda)
  }

  if (is.null(return_fit)) {
    return(NULL)
  }
  if (return_fit) {
    return(rcfit)
  } else {
    return(ffit)
  }
}

#' A helper function to get the bridgesampling objects
#'
#' @param rcfit the output of the
#' @param ... options passed directly to the bridge sampler function
#' @export billy_goat
billy_goat <- function(rcfit, ...) {

  # We need to make a 0-iteration fit object with the same model
  stan_opts <- rcfit$stan_opts
  stan_opts$warmup <- 0
  stan_opts$iter   <- 1

  # Fit the Stan model and optionally run diagnostics
  blank <- run_stan(
    dat       = rcfit$dat,
    covars    = rcfit$covars,
    fname     = rcfit$fname,
    stan_opts = stan_opts,
    diag      = FALSE)

  dots <- list(...)
  # By default don't print the iterations, this can be overriden in the "dots"
  if (! "silent" %in% names(dots)) dots$silent <- TRUE
  dots$samples       <- rcfit$fit
  dots$stanfit_model <- blank$fit

  bs <- do.call(bridgesampling::bridge_sampler, dots)
  bs
}
