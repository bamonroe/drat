# rcstan

<!-- badges: start -->
<!-- badges: end -->

`rcstan` estimates standard risk-preference models from choice data using
Bayesian Hamiltonian Monte Carlo via [Stan](https://mc-stan.org/). You hand it a
standardized dataset of lottery choices; it builds the Stan data structures,
fits one of several pre-coded Behavioural Heterogeneity Models (BHM), flattens
the posterior into a tidy table, and optionally runs MCMC diagnostics.

It is the estimation engine behind the Stata `stata_stan` package (`stanfit.do`),
which shells out to `rcstan::fit_to_dta()`, but it can also be used directly
from R.

## Installation

`rcstan` is published in the author's [drat](https://bamonroe.github.io/drat/)
repository. It depends on `rstan`, which is served from the Stan repository:

``` r
install.packages('rcstan', repos = c(
  'https://bamonroe.github.io/drat/',
  'https://mc-stan.org/r-packages/',
  'https://cloud.r-project.org/'))
```

A working C++ toolchain is required to compile the Stan models (GCC on
Linux/macOS, Rtools on Windows) — the same requirement as `rstan`.

## Supported models

The packaged Stan models (shipped in `inst/`) differ in their probability
weighting function (PWF) and utility specification:

| Model                | Family | Notes                          |
| -------------------- | ------ | ------------------------------ |
| `eut_bhm`            | EUT    | Expected utility               |
| `eut_ep_bhm`         | EUT    | Expo-power utility             |
| `rdu_power_bhm`      | RDU    | Power PWF                      |
| `rdu_rw_bhm`         | RDU    | Rank-weighted PWF              |
| `rdu_inverses_bhm`   | RDU    | Inverse-S PWF                  |
| `rdu_prelec_bhm`     | RDU    | Prelec PWF                     |
| `rdu_ep_prelec_bhm`  | RDU    | Expo-power utility, Prelec PWF |

Use `get_files()` to copy the packaged `.stan` files into the working directory,
or `get_stan_code(n)` to get the path to model `n`.

## Required data format

The input is a long data frame (one row per choice task) whose columns describe
each option's prizes and probabilities. Column names are parsed by regex, so the
number of options and outcomes is detected automatically.

| Column(s)             | Meaning                                                        |
| --------------------- | -------------------------------------------------------------- |
| `ID`                  | Subject identifier (required)                                  |
| `choice`              | The chosen option, per task (required)                         |
| `Max`, `Min`          | Max/min outcome in the task, for contextual utility            |
| `opt<k>_out<n>`       | Outcome *n* of option *k* (e.g. `opt1_out1`, `opt2_out3`)      |
| `opt<k>_prob<n>`      | Probability of outcome *n* of option *k*                       |

The number of options (`k`) and the number of outcomes per option (`n`) are
counted from the column names. **Every option is assumed to have the same number
of outcomes.** Each option must carry matching `out` and `prob` columns.

## Usage

``` r
library(rcstan)

fit_to_dta(
  infile    = "mydata.dta",          # standardized Stata dataset
  outfile   = "posterior.dta",       # flattened posterior written here
  stan_file = "rdu_prelec_bhm.stan", # one of the packaged models (see get_files())
  covars    = "",                    # optional, see below
  diag      = TRUE,                  # run MCMC diagnostics
  stan_opts = list(chains = 4, warmup = 5000, iter = 15000)
)
```

`stan_opts` is passed straight through to `rstan::stan()`, so any of its
arguments (`chains`, `warmup`, `iter`, `thin`, `control`, ...) can be set there.

### Covariates

Covariates on the hyper-parameters are specified with a Stata-style string: one
parenthesised, comma-separated group per hyper-parameter, in order. For example

```
covars = "(age,female)(age)"
```

puts `age` and `female` on the first hyper-parameter and `age` on the second.
Referenced columns must exist in the dataset (one value per subject is used).

### Extra variables

`extra_vars` is a comma-separated string of additional dataset columns to pass
through to the Stan model's data block (for models that consume them).

## Outputs

A successful run produces:

- **`<model>.Rda`** — the full `rcfit` list (the `rstan` fit, the data, the run
  options, and any diagnostics). Load it with `load("<model>.Rda")`; the object
  is named `rcfit`.
- **the flattened posterior `.dta`** (`outfile`) — one column per parameter plus
  `iter` and `chain`, with names sanitized for Stata.
- **diagnostic CSVs** (when `diag = TRUE`): `<model>_psrf.csv` (Gelman-Rubin),
  `<model>_autocorr.csv`, and `<model>_effectivesize.csv`.

### Robustness to long, expensive runs

Because a fit can take weeks, `fit_to_dta()` persists the irreplaceable
posterior — both the `.Rda` and the flattened `.dta` — *before* running any
diagnostics, and writes them atomically (temp file then rename). Diagnostics
then checkpoint after each step, so an out-of-memory failure in a later
diagnostic (bridge sampling is the usual culprit) cannot destroy the posterior
or the diagnostics that already succeeded.

To re-run only the post-processing on an interrupted job, call with
`overwrite = FALSE`: an existing `<model>.Rda` is reloaded instead of being
re-sampled. Diagnostics on a saved fit can also be re-run directly with
`mcmc_diag(rcfit)`.
