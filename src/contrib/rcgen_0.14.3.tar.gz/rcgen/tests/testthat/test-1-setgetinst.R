library(testthat)
library(rcgen)

inst_test <-  data.frame(var1 = 1:10,
                         var2 = 1:10,
                         var3 = 1:10)

test_that("set_inst sets the inst invisibly", {
  expect_invisible(set_inst("test", inst_test))
})

test_that("get_inst returns the inst correctly", {
  expect_equal(get_inst("test"), inst_test)
})

test_that("get_inst returns the inst correctly", {
  expect_true("test" %in% avail_inst())
})
