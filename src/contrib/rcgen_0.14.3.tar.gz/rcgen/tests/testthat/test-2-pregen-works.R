library(testthat)
library(rcgen)

# Testing that the risk instruments have correct probabilities
for (i in avail_inst()) {
  inst <- get_inst(i)
  if (! "task" %in% colnames(inst)) {
    next
  }
  if (inst$task[1] != "risk") {
    next
  }

  probs1 <- inst[, grep("opt1_prob[0-9+]", colnames(inst))]
  probs2 <- inst[, grep("opt2_prob[0-9+]", colnames(inst))]

  probs1 <- rowSums(probs1)
  probs2 <- rowSums(probs2)

  test_that(paste("isnt", i, "option 1 has probabilities that sum to 1"), {
    expect_equal(probs1, rep(1, nrow(inst)))
  })

  test_that(paste("isnt", i, "option 2 has probabilities that sum to 1"), {
    expect_equal(probs1, rep(1, nrow(inst)))
  })

}
