library(testthat)
library(rcgen)

# Testing that the risk instruments have correct probabilities
for (i in avail_inst()) {
  inst <- get_inst(i)
  if (! "task" %in% colnames(inst)) {
    next
  }
  if (inst$task[1] != "risk") {
    next
  }

  rinst <- rcest::rank_inst(inst, "standard", use_times = F)

  test_that(paste("isnt", i, "is ranked."), {
    expect_equal(inst, rinst)
  })

}
