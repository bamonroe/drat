gtl <- system2("git", c("rev-parse", "--show-toplevel"), stdout = T)
setwd(gtl)
# Testing documentation
devtools::install()
cat("\n\nINSTALLATION GOOD\n\n")
devtools::document()
cat("\n\nDOCUMENTATION GOOD\n\n")
