#' @title Generate an instument
#'
#' @param names the names of the instruments to generate
#' @param pmat a matrix or data.frame, each row assigned to an ID
#' @param n (optional) number of IDs to generate
#' @export gen_inst
gen_inst <- function(names, pmat = NULL, n = NULL) {

  if (! is.null(pmat)) {
    if (! is.data.frame(pmat)) {
      if (! is.matrix(pmat)) {
        stop("'pmat' needs to be NULL, a data.frame, or a matrix")
      } else {
        n <- nrow(pmat)
      }
    } else {
      n <- nrow(pmat)
    }
  } else if (is.null(n)) {
    n <- 1
  } else if (! is.numeric(n)) stop("'n' must be NULL or numeric")
  else if (length(n) != 1) stop("'n' must be of length 1")

  # Get the instrument
  inst <- get_inst(names)

  # Stack it and add an ID column
  inst_rows <- nrow(inst)
  inst      <- stack_df(inst, n)
  inst$ID   <- rep(1:n, each = inst_rows)
  # Get rid of the rownames
  rownames(inst) <- NULL

  # If the pmat isn't null (it's already passed the other tests) then
  # add it to the inst. Every row of the pmat corresponds with an ID
  # in the inst
  if (! is.null(pmat)) {
    prows <- seq_len(nrow(pmat))
    inst[, colnames(pmat)] <- pmat[match(inst$ID, prows), ]
  }

  return(inst)
}

#' @title Generate chocies
#'
#' @param inst the instrument to generate choices for
#' @param lfun the function that generates the likelihood matrix
#' @param ftypes list of function types
#' @param covars ftype list of covars
#' @param inst_adjust Adjust the base_pars for covars in the returned inst
#' @param ... additional arguments required for the lfun
#' @export gen_choice
gen_choice <- function(inst, lfun = NULL,
                       ftypes = list(), covars = list(),
                       inst_adjust = FALSE, ...) {

  if (! is.data.frame(inst)) stop("'inst' must be a data.frame")
  if ((! is.function(lfun)) & (! is.null(lfun))) stop("'lfun' must be a function or NULL")

  # If a function has been passed
  # check if the lfun has the minimal arguments needed
  if (is.function(lfun)) {
    req_args <- c("pmat", "inst", "ftypes", "ft_index")
    rcest::fn_check(lfun, req_args, "lfun")
  }

  # Normalize the ftypes
  ftypes <- rcest::ftype_sanitize(ftypes)
  covars <- rcest::covar_sanitize(covars, ftypes = ftypes)
  cnames <- unlist(covars)

  # Get the ftypes
  parsers <- lapply(names(ftypes), function(ftype) {
    rcest::get_parser(ftype, ftypes[[ftype]])
  })

  # Get the par_names
  par_names <- lapply(parsers, "[[", "par_names")
  unames <- as.character(unlist(par_names))

  # Do some checks
  if (! all(unames %in% colnames(inst))) {
    not_in <- unames[! unames %in% colnames(inst)]
    not_in <- paste("'", not_in, "'", sep = "", collapse = ", ")
    stop(paste0("Parameters: ", not_in, " are not in the inst"))
  }

  # Make all transforms "none"
  trans <- rcest::trans_sanitize(ftypes = ftypes, transforms = list())
  trans <- lapply(trans, function(tt) {
    out <- rep("none", length(tt))
    names(out) <- names(tt)
    out
  })

  # Get the wrap_opts
  wrap_opts <- rcest::get_wrap_opts(inst, ftypes = ftypes, covars = covars,
                            transforms = trans, init = list(), ...)

  # Get the parameter matrix
  pmat <- as.matrix(inst[, unames])
  pvec <- rep(0, ncol(pmat))
  if (length(cnames) > 0) {
    pvec <- c(pvec, cnames)
  }

  # Adjust it for covariates
  pmat <- rcest::pmat_adjust(pmat, pvec, wrap_opts)

  # Change the base_pars in the inputted data.frame to use the adjusted
  # pmat
  if (inst_adjust | is.null(lfun)) {
    ft_index <- wrap_opts$ft_index
    for (fn in names(ft_index)) {
      index_add <- ft_index[[fn]][which(ft_index[[fn]] != 0)]
      pnames_add <- unames[index_add]
      for (ia in seq_along(index_add)) {
        inst[[pnames_add[ia]]] <- pmat[, index_add[ia]]
      }
    }
  }

  # Run the user-supplied likelihood funciton
  dargs <- list()
  if (length(wrap_opts$dot_args) > 0) {
    dargs <- wrap_opts$dot_args
  }

  dargs$pmat     <- pmat
  dargs$inst     <- inst
  dargs$ftypes   <- wrap_opts$ftypes
  dargs$ft_index <- wrap_opts$ft_index

  # If a function has been passed then choices are made,
  # otherwise the pmat is just applied
  if (is.function(lfun)) {
    like <- do.call(lfun, dargs)
    inst$choice <- choose_n_opts(like)
  }

  return(inst)
}
