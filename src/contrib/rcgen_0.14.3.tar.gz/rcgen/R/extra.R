## Environment for premade instruments
premade_inst_env <- new.env()

.onLoad <- function(libname, pkgname) {
  ## Holt & Laury (2002)
  # 10 lotteries
  set_inst(name = "HL", inst = dat_HL)
  # Instrument from Nathaniel Wilcox
  # 100 Lotteries
  set_inst(name = "WX", inst = dat_WX)

  # Harrison & NG (2016)
  # 80 Lotteries
  set_inst(name = "HN", inst = dat_HN)

  # Hey & Orme (1994) - Table I
  # 100 Lotteries
  set_inst(name = "HO", inst = dat_HO)

  # Harrison & NG (2016)
  # 24 lotteries - Insurance instrument
  set_inst(name = "HN_ins", inst = dat_HN_ins)

  # Loomes, Moffat & Sugden (2002)
  # 90 lotteries
  set_inst(name = "LMS20", inst = dat_LMS20)
  set_inst(name = "LMS30", inst = dat_LMS30)

  #Schmidt & Hey (2004)
  # 140 Lotteries
  set_inst(name = "SH", inst = dat_SH)

  # Instrument from Andre Hofmeyr
  # 40 Lotteries
  set_inst(name = "AH", inst = dat_AH)

  # No-thought time instrument from Brian Monroe
  # 20 pairs
  set_inst(name = "BAM_t", inst = dat_BAM_t)
}
