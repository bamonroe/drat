# This is used a couple of times, I find it more convienient to wrap this function rather than
# keep typing out the dplyr command
stack_df <- function(d, n) {
  if ("data.table" %in% class(d)) return(d[rep(seq_len(nrow(d)), n)])
  return(d[rep(seq_len(nrow(d)), n), ])
}

# Choose an option from among a set of discrete options.
choose_n_opts <- function(like) {
  rand   <- runif(nrow(like))
  choice <- rep(0, nrow(like))
  num_opts <- ncol(like)
  for (i in seq_len(num_opts)) {
    if (i == 1) {
      bot <- -Inf
    } else {
      like[, i] <- like[, i] + like[, i - 1]
      bot <- like[, i - 1]
    }
    if (i == num_opts) top <- Inf
    else top <- like[, i]
    choice[which((rand > bot) & (rand <= top))] <- i - 1
  }
  choice
}
