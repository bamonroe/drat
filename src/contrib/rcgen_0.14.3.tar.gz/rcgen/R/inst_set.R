#' Set an instrument to be simulated
#'
#' @param name the name of the instrument.
#' @param inst the data.frame being stored
#' @export set_inst
set_inst <- function(name, inst) {
  if (! is.character(name))  stop("'name' must be a character vector")
  if (length(name) != 1)     stop("Only one 'name' can be given")
  if (! is.data.frame(inst)) stop("'inst' must be a data.frame")
  premade_inst_env[[name]] <- inst
}

#' Get an instrument to be simulated
#'
#' @param names the name(s) of the instruments to get.
#' @export get_inst
get_inst <- function(names) {
  if (! all(is.character(names))) stop("'names' must be character vectors")
  inst_available <- avail_inst()
  for (iname in names) {
    if (! iname %in% inst_available) {
     stop(paste0("name '", iname, "' is not an available instrument. Did you forget to set it?"))
    }
  }
  # Get the insts from the environment
  inst <- lapply(names, function(name) premade_inst_env[[name]])
  # All the column names across all instruments
  all_names <- unique(unlist(lapply(inst, colnames)))
  # Add columns equal to 0 if they're missing from each inst
  inst <- lapply(inst, function(sinst) {
    not_in <- all_names[! all_names %in% colnames(sinst)]
    sinst[, not_in] <- 0
    sinst
  })
  # Combine and return
  do.call(rbind, inst)
}

#' @title Get Available Instruments
#'
#' @export avail_inst
avail_inst <- function() {
  ls(envir = premade_inst_env)
}

#' @title Get the Private Inst Environment
#'
#' @export get_instenv
get_instenv <- function() {
  return(premade_inst_env)
}

#' @title Set the Private Inst Environment
#'
#' @param instenv the environment containing premade insts
#' @export set_instenv
set_instenv <- function(instenv) {
  # remove everything from the environment
  rm(list = ls(envir = premade_inst_env), envir = premade_inst_env)
  for (e in ls(envir = instenv)) {
    assign(e, instenv[[e]], envir = premade_inst_env)
  }
}
