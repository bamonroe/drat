# rcgen
[![Build Status](https://drone.bamonroe.com/api/badges/rdev/rcgen/status.svg?ref=refs/heads/master)](https://drone.bamonroe.com/rdev/rcgen)

A package to simulate choices for discrete choice models.
