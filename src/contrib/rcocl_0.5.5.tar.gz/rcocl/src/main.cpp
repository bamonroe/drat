// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <CL/opencl.hpp>
#include <algorithm>
#include <unistd.h>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

using namespace Rcpp;

// There are key vectors of values that need to be carried around, we
// store them in a struct
struct Odata {
  Ovec<rtype> post;
  // The array for the parameters
  Ovec<rtype> par;
  // The arrays for the RNG states
  Ovec<cl_uint> rng;
  // The arrays for the mean pars
  Ovec<rtype> aux_mean;
  // The arrays for the covariance pars
  Ovec<rtype> aux_invcov;
  // The arrays for the covariance pars
  Ovec<rtype> aux_chol;
  // The arrays for the covariance pars
  Ovec<rtype> aux_logdet;
  // The arrays for the acceptance statistics
  Ovec<rtype> accepts;
  // The arrays for the batch info
  Ovec<cl_uint> batches;
  // The arrays for the sampling type
  Ovec<cl_uint> stype;
  // The arrays for the sampling type
  Ovec<cl_uint> iter_info;
};

void fmcmc_display(
  Stats &stats,
  int iter,
  int citer,
  List config
) {

  int show_every = config["show_every"];
  int show_sd = config["show_sd"];
  int ikeep = config["keep_every"];

  // The posterior
  rtype post   = stats.get(1);
  rtype par    = stats.get(3 + 3 * show_sd);
  rtype sd     = stats.get(3 + 3 * show_sd + 1);
  rtype accept = stats.get(3 + 3 * show_sd + 2);

  bool showme = false;
  // We want to show every "show_every" iteration
  if (iter == 0 || iter % show_every == 0) {
    showme = true;
  }

  // Also we want to show the collected iters
  std::string prefix;
  if ((citer >= 0) & (citer % ikeep == 0)) {
    prefix = "**";
  } else {
    prefix = "@@";
  }

  if (showme) {
    Rcout  
      << prefix
      << " iter: "    << std::left << std::setw(6) << iter
      << " post: "   << std::left << std::setw(10) << post
      << " par["     << show_sd << "]: " << std::right << std::setw(10) << std::setprecision(6) << std::fixed << par
      << "  sd["     << show_sd << "]: " << std::left << std::setw(10) << std::setprecision(6) << std::fixed << sd  << std::left << std::setw(10)
      << " accept: " << std::left << std::setw(10) << accept
      << std::endl;

    if ((stats.collect_signal > 0) & (citer < 0)) {
      Rcout << "\n** Start Collecting" << std::endl;
    }
  }

}

void collect_samples(
  Odata &odat,
  List  &config,
  NumericMatrix &samples,
  OclHandler &ocl,
  int iter,
  int citer,
  int &draws_collected
)
{

  // Keep every ikeep iterations
  int ikeep = config["keep_every"];
  // The number of parameters
  int npar = config["npar"];
  // The number of chains to be collected
  int collect_chains = config["collect_chains"];

  // If we're not in an ikeep iteration, just skip ahead
  if (citer % ikeep != 0) {
    return;
  }

  // Incrememnt the number of draws collected;
  draws_collected++;

  rtype *post_p, *par_i;

  // The row of the datset
  int rnum = (citer / ikeep) * collect_chains;

  int irow = 0;
  int chain = 0;
  // Assign the chosen pars to the full sample
  for (uint d = 0; d < ocl.ndev ; d++) {
    post_p = odat.post.getv(d);
    par_i  = odat.par.getv(d);
    for (int wi = 0; wi < ocl.chains[d] ; wi++) {

      // If we've already collected enough chains, break out
      if (chain >= collect_chains) {
        break;
      }

      // First the iteration
      samples.at(rnum + irow, 0) = iter;
      // Second the chain
      samples.at(rnum + irow, 1) = chain;
      // Third the posterior
      samples.at(rnum + irow, 2) = *post_p;
      for (int p = 0; p < npar; p++) {
        // Save the parameters
        samples.at(rnum + irow, 3 + p) = *par_i;
        par_i++;
      }
      irow++;
      post_p++;
      chain++;
    }
  }

}

// Do we adapt this iteration?
uint adapt_iter(int iter, List &config) {
  // The adapt_schedule is a list of 2 element vectors telling the lower and
  // upper bounds of the iteration range where adaption occurs. So we just test
  // if we're in these bounds
  List adapt_schedule  = config["adapt_schedule"];
  NumericVector adapt_range;
  // Defaults to false
  uint adapt = 0;
  for (int i = 0; i < adapt_schedule.size(); i++) {
    adapt_range = adapt_schedule[i];
    if (adapt_range[1] == (iter - 1)) {
      Rcout << "** Adaptation ended" << std::endl;
      adapt = 1;
      break;
    } else if (adapt_range[0] == iter) {
      Rcout << "** Starting an adaptation" << std::endl;
      adapt = 2;
      break;
    } else if (adapt_range[0] < iter && adapt_range[1] >= iter) {
      adapt = 2;
      break;
    }
  }
  return adapt;
}

void fmcmc_calc(
  Odata &odat,
  NumericMatrix &samples,
  int iter,
  OclHandler &ocl,
  Stats &stats,
  std::vector<rtype> &m1,
  std::vector<rtype> &a1,
  List &config
){

  int chains      = config["chains"];
  int npars       = config["npar"];

  uint adapt = adapt_iter(iter, config);

  // Set m1 and accept to 0
  std::fill(m1.begin(), m1.end(), 0);
  std::fill(a1.begin(), a1.end(), 0);

  // Average posterior
  rtype post0 = 0;
  rtype post1 = 0;
  rtype post2 = 0;

  rtype *post_i;
  // Work item counter
  for (uint d = 0; d < ocl.ndev ; d++) {
    post_i = odat.post.getv(d);
    for (int wi = 0; wi < ocl.chains[d] ; wi++) {
      post0  = *post_i;
      post1 += post0 / chains;
      post2 += (post0 / chains) * post0;
      post_i++;
    }
  }

  // Each device contains that device's portion of the mean and acceptance ratio
  // We need to sum these portions to get the real mean and acceptance ratio
  rtype *mean_i, *accept_i;
  for (uint d = 0; d < ocl.ndev ; d++) {
    mean_i   = odat.aux_mean.getv(d);
    accept_i = odat.accepts.getv(d);
    for (int p = 0; p < npars; p++) {
      m1.at(p) += *mean_i;
      a1.at(p) += *accept_i;
      // Increment the iterators
      mean_i++;
      accept_i++;
    }
  }

  // The vector of batches
  NumericVector batches = config["batches"];
  // How many parameters are in this batch
  int bnum = 0;
  // Vector of per-batch covariance matricies
  std::vector<arma::fmat> batch_cov;
  // Initialize them so we don't have to make a new matrix in the below loop
  for (int bi = 0; bi < (int)batches.length(); bi++) {
    bnum = batches.at(bi);
    // Fill with zeros
    arma::fmat val(bnum, bnum);
    val.zeros();
    batch_cov.push_back(val);
  }

  // counter for the par number
  int p = 0, q = 0, qbase = 0;
  // Point to the right spots in the par vector
  rtype *invcov;
  // A pointer for the matrix that we're going to write to
  arma::fmat* cmat;
  for (uint device = 0; device < ocl.ndev ; device++) {
    invcov = odat.aux_invcov.getv(device);
    // Loop through all batches, covariance is only calcualted per-batch
    p = 0;
    for (int bi = 0; bi < (int)batches.length(); bi++) {
      bnum = batches.at(bi);
      cmat = &batch_cov.at(bi);
      //Rcout << "iter: " << iter << ", Cmat for batch: " << bi << " Device: " << device << std::endl;
      //Rcout << *cmat << std::endl;
      qbase = p;
      for (int row = 0; row < bnum; row++) {
        for (int col = 0; col <= row; col++) {

          q = qbase + col;
          //Rcout << "p,q: " << p << "," << q << "row,col: " << row << "," << col << " invcov: " << *invcov << " mp,mq: " << m1.at(p) << "," << m1.at(q) << std::endl;
          // It's a symmetric matrix, so we don't need to loop over the whole thing
          cmat->at(row, col)   += *invcov - (m1.at(p) * m1.at(q)) / ocl.ndev;
          if (row != col) {
            cmat->at(col, row) += *invcov - (m1.at(p) * m1.at(q)) / ocl.ndev;
          }
          // Increment the row varaible
          invcov++;
        }
        p++;
      }
    }
  }

  // Save the iteration
  stats.add(iter);
  // Save the average posterior
  stats.add(post1);
  // Save the standard dev of the posteriors
  post2 = sqrt(post2 - (post1 * post1));
  stats.add(post2);

  p = 0;
  for (int bi = 0; bi < (int)batches.length(); bi++) {
    bnum = batches.at(bi);
    cmat = &batch_cov.at(bi);
    for (int row = 0; row < bnum; row++) {
      // Save the mean of this parameter
      stats.add(m1.at(p));
      // Save the standard dev of this parameter
      stats.add(sqrt(cmat->at(row, row)));
      // Save the acceptance rate of this parameter
      stats.add(a1.at(p));

      if (!std::isfinite(cmat->at(row, row))) {
        Rcout << "Non-finite between variance:" << std::endl;
        Rcout << "  p:    " << p  << std::endl;
        Rcout << "  mean: " << m1.at(p) << std::endl;
        Rcout << "  std:  " << cmat->at(row, row) << std::endl;
        std::exit(1);
      }
      p++;
    }
  }

  // Very basic, we always have to updat the iteration and the use_mean signal
  uint use_mean = config["use_mean"];
  uint *iter_info;
  for (uint d = 0; d < ocl.ndev ; d++) {
    iter_info = odat.iter_info.getv(d);
    iter_info[0] = iter;
    iter_info[1] = use_mean == 1 && adapt > 1 ? 1 : 0;
  }
  ocl.write_buffer<Ovec<uint>&>(odat.iter_info);

  // We adjust the cmat based on where we are in the adapt_schedule
  NumericVector cmat_mult = config["cmat_mult"];
  float cmat_mult_use = 1.0;
  cmat_mult_use = adapt >  0 ? cmat_mult[0] : cmat_mult_use;
  cmat_mult_use = adapt == 1 ? cmat_mult[1] : cmat_mult_use;

  // We adjust the covariance if we're adapting, which is adapt > 1, and if
  // we're not collecting.
  if ((stats.collect_signal == 0) && adapt > 0) {

    // Here's the mean
    rtype *aux_mean;
    for (uint d = 0; d < ocl.ndev ; d++) {
      aux_mean = odat.aux_mean.getv(d);
      for (int p = 0; p < npars; p++) {
        *aux_mean = m1.at(p);
        aux_mean++;
      }
    }

    // Loop over batches to calculate the cholesky matrix, at write it to the
    // ovec to be written to the buffer.
    // The number of batches is not dependent on work-items, and will always be
    // less than or equal to the number of parameters so this the number of
    // operations here will be dominated by the above calculation of covariance
    rtype* aux_invcov, *aux_chol, *aux_logdet;
    arma::fmat invcov, cholmat;
    bool chol_success = false;

    for (uint d = 0; d < ocl.ndev ; d++) {

      aux_invcov = odat.aux_invcov.getv(d);
      aux_chol   = odat.aux_chol.getv(d);
      aux_logdet = odat.aux_logdet.getv(d);

      for (int bi = 0; bi < (int)batches.length(); bi++) {
        bnum = batches.at(bi);
        cmat = &batch_cov.at(bi);

        //Rcout << "iter: " << iter << ", Cmat for batch: " << bi << std::endl;
        //Rcout << *cmat << std::endl;

        // We're adjusting the covariance matrix to be a bit smaller
        if (cmat_mult.at(0) > 0) {
          for (arma::uword crow = 0; crow < cmat->n_rows; crow++) {
            for (arma::uword ccol = 0; ccol < cmat->n_cols; ccol++) {
              cmat->at(crow, ccol) = cmat->at(crow, ccol) / (cmat_mult_use * sqrt(cmat->n_cols));
            }
          }
        }

        // Calculate the cholesky decomposition, try up to 5 times to get it right
        chol_success = false;
        for (int chol_tries = 0; chol_tries < 5; chol_tries++) {
          chol_success = arma::chol(cholmat, *cmat, "lower");
          if (chol_success) {
            break;
          } else {
            // Add a small amount to the diagonals to hopefully make the eigen values positive
            *cmat += arma::eye<arma::fmat>(cmat->n_rows, cmat->n_rows) * 1e-4;
          }
        }

        if (! chol_success) {
          *cmat -= arma::eye<arma::fmat>(cmat->n_rows, cmat->n_rows) * 4e-4;
          Rcout << "Batch (0-indexed): " << bi << std::endl;
          Rcout << "Cholesky decomposition failed after 5 tries for matrix:" << std::endl;
          Rcout << *cmat << std::endl;
          Rcout << "Eigenvalues:" << std::endl;
          Rcout << arma::eig_sym(*cmat) << std::endl;
          exit(1);
        }

        invcov  = arma::inv_sympd(*cmat);
        *aux_logdet = arma::log_det_sympd(*cmat);
        //Rcout << *cmat << std::endl;
        for (int row = 0; row < bnum; row++) {
          for (int col = 0; col <= row; col++) {
            *aux_invcov = invcov.at(row, col);
            *aux_chol   = cholmat.at(row, col);
            aux_invcov++;
            aux_chol++;
          }
        }
      }
    }
    // Write the jump buffer
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_mean);
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_invcov);
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_chol);
    ocl.write_buffer<Ovec<rtype>&>(odat.aux_logdet);
    ocl.finish();

  }

}

Odata ocl_setup(
  OclHandler    &ocl,
  List          &config,
  List          &dat,
  NumericVector &init,
  NumericVector &init_mean,
  List          &covinfo
) {

  int npars  = config["npar"];
  int chains = config["chains"];

  NumericVector init_invcov = covinfo["invcov"];
  NumericVector init_chol   = covinfo["cholesky"];
  NumericVector init_logdet = covinfo["logdet"];

  // The batches of parameters to run with gibbs
  IntegerVector batches = config["batches"];
  // The type of sampler used for each batch
  IntegerVector sampling_type = config["sampler"];
  // Some information about the current iteration
  IntegerVector iter_info = config["iter_info"];

  // Buffer for the posterior 
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, 1, true, "post");
  // Buffer for parameters
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, npars, true, "par");
  // Buffer to hold the state for RNG
  ocl.make_buffer<cl_uint>(CL_MEM_READ_WRITE, 1, true, "rng");
  // Buffer for the mean of the proposal distributions
  ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, npars, false, "aux_mean");

  // Buffer for the inverse covariance of the proposal distributions
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, init_invcov.length(), false, "aux_invcov");
  // Buffer for the cholesky decomposition of the covariance
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, init_chol.length(), false, "aux_chol");
  // Buffer for the log determinant of the covariance matrix
  ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, init_logdet.length(), false, "aux_logdet");

  // Buffer to hold the average acceptance states
  ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, npars, true, "accepts");
  // Buffer to hold the batch information
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, batches.length(), false, "batches");
  // Buffer to hold the sampling type information
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, sampling_type.length(), false, "sampling_type");
  // Buffer to hold the iteration information
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, iter_info.length(), false, "iter_info");

  // Buffer to hold the info for the calculation of mean and covariance
  ocl.make_buffer<cl_uint>(CL_MEM_READ_ONLY, 2, false, "parinfo");
  std::vector<cl_uint> parinfo {(cl_uint)npars, (cl_uint)chains};
  ocl.write_buffer<cl_uint*>(parinfo.data(), ocl.bi());
  ocl.finish();

  // Write in the data
  List ddat, idat;

  NumericVector dvec;
  IntegerVector ivec;

  ddat = dat["double"];
  idat = dat["int"];

  for (int i = 0; i < ddat.length(); i++) {
    // Get the List item into vectors
    dvec = ddat[i];
    std::vector<rtype> double_vec (dvec.begin(), dvec.end());

    ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, double_vec.size(), false);
    ocl.write_buffer<rtype*>(double_vec.data(), ocl.bi());
    ocl.finish();
  }

  for (int i = 0; i < idat.length(); i++) {
    // Get the List item into vectors
    ivec = idat.at(i);
    ocl.make_buffer<cl_int>(CL_MEM_READ_ONLY, ivec.length(), false);
    ocl.write_buffer<cl_int*>(ivec.begin(), ocl.bi());
    ocl.finish();
  }

  // This struct will carry around these ovecs and be returned from this
  // setup function
  Odata odat = {
    // Set the array that will hold the posterior
    Ovec<rtype>(&ocl, 0),
    // The arrary for the parameters
    Ovec<rtype>(&ocl, 1),
    // The arrays for the RNG states
    Ovec<cl_uint>(&ocl, 2),
    // The arrays for the mean parameters
    Ovec<rtype>(&ocl, 3),

    // The arrays for the covaraince parameters
    Ovec<rtype>(&ocl, 4),
    // The arrays for the covaraince parameters
    Ovec<rtype>(&ocl, 5),
    // The arrays for the covaraince parameters
    Ovec<rtype>(&ocl, 6),

    // The arrays for the acceptance statistics
    Ovec<rtype>(&ocl, 7),
    // The arrays for the batch info
    Ovec<cl_uint>(&ocl, 8),
    // The arrays for the sampling type
    Ovec<cl_uint>(&ocl, 9),
    // The arrays for the iteration info
    Ovec<cl_uint>(&ocl, 10)
  };

  // Initialize the parameter vector
  rtype   *post_init, *par_init, *mean_init, *invcov_init, *chol_init, *logdet_init, *accept_init;
  cl_uint *rng_init, *batch_init, *stype_init, *iter_info_init;

  int counter = 0;
  // loop through all devices to initialize per-device
  for (uint d = 0; d < ocl.ndev; d++)
  {
    post_init  = odat.post.getv(d);
    par_init   = odat.par.getv(d);
    rng_init   = odat.rng.getv(d);
    mean_init  = odat.aux_mean.getv(d);

    invcov_init = odat.aux_invcov.getv(d);
    chol_init   = odat.aux_chol.getv(d);
    logdet_init = odat.aux_logdet.getv(d);

    accept_init   = odat.accepts.getv(d);
    batch_init    = odat.batches.getv(d);
    stype_init    = odat.stype.getv(d);
    iter_info_init = odat.iter_info.getv(d);

    // Initialize the batch information
    for (int i = 0; i < batches.length(); i++) {
      *batch_init = batches.at(i);
      batch_init++;
    }
    // Initialize the sampler type
    for (int i = 0; i < sampling_type.size(); i++) {
      *stype_init = sampling_type.at(i);
      stype_init++;
    }
    // Initialize the iteration info
    for (int i = 0; i < iter_info.size(); i++) {
      *iter_info_init = iter_info.at(i);
      iter_info_init++;
    }

    // initialize the inverse covariance vector and cholesky decomposition 
    for (int i = 0; i < init_invcov.length(); i++)
    {
      *invcov_init = init_invcov.at(i);
      *chol_init   = init_chol.at(i);
      invcov_init++;
      chol_init++;
    }
    // initialize the log-determinant of the covariance matrix
    for (int i = 0; i < init_logdet.length(); i++) {
      *logdet_init = init_logdet.at(i);
      logdet_init++;
    }

    // Loop through parameter-specific inits
    for (int i = 0; i < npars; i++)
    {
      *mean_init = init_mean[i];
      mean_init++;
    }

    // Loop through the work-items per device
    for (int chain = 0; chain < ocl.chains[d]; chain++){
      // Initialize the parameters
      for (int pari = 0; pari < npars; pari++)
      {
        *par_init  = init[pari + npars * counter];
        *accept_init  = 0.0;
        par_init++;
        accept_init++;
      }
      // Set prior and posterior to lowest possible values
      *post_init  = 100 - FLT_MAX;
      // Set the initial RNG state to be equal to the work item index
      *rng_init = (counter + 1) * 10 + (cl_uint)round(R::runif(0, 10)) ;
      // Increment pointers
      post_init++;
      rng_init++;
      counter++;
    }
  }

  // Write the buffers for the initialized vectors
  ocl.write_buffer<Ovec<rtype>&>(odat.post);
  ocl.write_buffer<Ovec<rtype>&>(odat.par);
  ocl.write_buffer<Ovec<uint>&>(odat.rng);
  ocl.write_buffer<Ovec<rtype>&>(odat.aux_mean);

  ocl.write_buffer<Ovec<rtype>&>(odat.aux_invcov);
  ocl.write_buffer<Ovec<rtype>&>(odat.aux_chol);
  ocl.write_buffer<Ovec<rtype>&>(odat.aux_logdet);

  ocl.write_buffer<Ovec<rtype>&>(odat.accepts);
  ocl.write_buffer<Ovec<uint>&>(odat.batches);
  ocl.write_buffer<Ovec<uint>&>(odat.stype);
  ocl.write_buffer<Ovec<uint>&>(odat.iter_info);

  // Make sure everything is synced at this point
  ocl.finish();

  return odat;
}

//' @title Gather samples from _every_ chain
//' @param codeinfo    The code for the kernel
//' @param config      A list of configuration items
//' @param init        The initial parameters
//' @param init_mean   The initial value for the parameter mean
//' @param covinfo     The initial covariance information
//' @param dat         rtype precision data
// [[Rcpp::export]]
List full_mcmc
(
  List codeinfo,
  List config,
  NumericVector init,
  NumericVector init_mean,
  List covinfo,
  List dat
)
{
  // Some variables for timekeeping
  double avg_time = 0, diff = 0, n;
  uint64_t iter_time0, iter_time1, setup_time0, setup_time1;

  // We're going to time how long it takes to get to the iterations
  setup_time0 = timeSinceEpochMillisec();

  // Number of iterations
  int draws = config["draws"];
  // Keep every ikeep iterations
  int ikeep = config["keep_every"];
  // Skip the first iskip iterations
  int iskip = config["skip"];
  // Total number of iterations to run
  int niter = iskip + ikeep * draws;
  // Which algorithm are we running
  std::string algo = config["algo"];

  // The batches of parameters to run with gibbs
  IntegerVector batches = config["batches"];
  // The size of the invcov vector across all batches
  int total_batches = 0;
  for (int i = 0; i < batches.size(); i++) {
    total_batches += batches.at(i) * (batches.at(i) + 1) / 2;
  }

  // The device number
  List device_list = config["device_list"];

  // Most functions don't like calling Rcpp List items directly
  int collect_chains = config["collect_chains"];
  int npars = config["npar"];

  // Now actually begin initializing the OpenCL stuff
  // Get all platforms (devices)
  OclHandler ocl(device_list, codeinfo);
  // Initialize the buffers on the devices
  Odata odat = ocl_setup(ocl, config, dat, init, init_mean, covinfo);

  // Set the numeric vector that will hold all the samples
  // Extra cols:
  //   posterior
  //   chain
  //   iteration
  int extra_cols = 3;
  NumericMatrix samples(draws * collect_chains, npars + extra_cols);

  // Sum statistics
  // Extra cols:
  //  iteration
  //  posterior
  //  posterior standard deviation
  // Cols:
  //  mean parameter
  //  mean standard deviation
  //  mean acceptance
  Stats stats(config, 3 * npars + 3);

  // Between chain variance
  std::vector<rtype> m1(npars);
  std::vector<rtype> a1(npars);

  // This is the number of iterations from when the collect signal was given
  int citer = -1;
  // The number of draws we've collected thus far
  int draws_collected = 0;
  int iter = 1;

  setup_time1 = timeSinceEpochMillisec();

  Rcout << "@@full_mcmc: Staring iterations" << std::endl;

  iter_time0 = timeSinceEpochMillisec();

  while (true) 
  {

    // Run the kernel on all devices
    ocl.run_kernel(algo);
    ocl.run_mean(config);
    ocl.run_cov(config);
    // Read result from GPU to here
    ocl.read_buffer<Ovec<rtype>&>(odat.post);
    ocl.read_buffer<Ovec<rtype>&>(odat.par);
    ocl.read_buffer<Ovec<rtype>&>(odat.aux_mean);
    ocl.read_buffer<Ovec<rtype>&>(odat.aux_invcov);
    ocl.read_buffer<Ovec<rtype>&>(odat.accepts);
    // Kernel needs to have finished
    ocl.finish();

    // Calculate the jump distribution
    fmcmc_calc(odat, samples, iter, ocl, stats, m1, a1, config);

    ocl.finish();

    // Collect iteration times
    iter_time1 = timeSinceEpochMillisec();
    diff = iter_time1 - iter_time0;
    n    = iter;
    avg_time =  avg_time * (n / (n + 1)) + (diff / (n + 1));
    iter_time0 = iter_time1;

    stats.check_collect();

    if (stats.collect_signal == 1) {
      citer++;
      collect_samples(odat, config, samples, ocl, iter, citer, draws_collected);
    }

    // Display some information
    fmcmc_display(stats, iter, citer, config);

    if (draws_collected == draws) {
      break;
    }
    iter++;

  }

  Rcout << "\nDone with iterations" << std::endl;
  Rcout << "Total setup time:           " << (setup_time1 - setup_time0) / 1000.0 << "s" <<std::endl;
  Rcout << "Total iteration time:       " << avg_time * niter / 1000 << "s" <<std::endl;
  Rcout << "Average time per iteration: " << avg_time << "ms" <<std::endl;

  return List::create(
    Named("samples") = samples,
    Named("stats")   = stats.to_mat()
  );
};
