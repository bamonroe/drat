#ifndef maindef
#include "main.hpp"
#endif

#include <unistd.h>
#include <string>
#include <fstream>

void builderrors(int code) {
  switch(code) {
    case CL_SUCCESS:
      {
        Rcout << "CL_SUCCESS" << std::endl;
      }
    break;
    case CL_DEVICE_NOT_FOUND:
      {
        Rcout << "CL_DEVICE_NOT_FOUND" << std::endl;
      }
    break;
    case CL_DEVICE_NOT_AVAILABLE:
      {
        Rcout << "CL_DEVICE_NOT_AVAILABLE" << std::endl;
      }
    break;
    case CL_COMPILER_NOT_AVAILABLE:
      {
        Rcout << "CL_COMPILER_NOT_AVAILABLE" << std::endl;
      }
    break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE:
      {
        Rcout << "CL_MEM_OBJECT_ALLOCATION_FAILURE" << std::endl;
      }
    break;
    case CL_OUT_OF_RESOURCES:
      {
        Rcout << "CL_OUT_OF_RESOURCES" << std::endl;
      }
    break;
    case CL_OUT_OF_HOST_MEMORY:
      {
        Rcout << "CL_OUT_OF_HOST_MEMORY" << std::endl;
      }
    break;
    case CL_PROFILING_INFO_NOT_AVAILABLE:
      {
        Rcout << "CL_PROFILING_INFO_NOT_AVAILABLE" << std::endl;
      }
    break;
    case CL_MEM_COPY_OVERLAP:
      {
        Rcout << "CL_MEM_COPY_OVERLAP" << std::endl;
      }
    break;
    case CL_IMAGE_FORMAT_MISMATCH:
      {
        Rcout << "CL_IMAGE_FORMAT_MISMATCH" << std::endl;
      }
    break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED:
      {
        Rcout << "CL_IMAGE_FORMAT_NOT_SUPPORTED" << std::endl;
      }
    break;
    case CL_BUILD_PROGRAM_FAILURE:
      {
        Rcout << "CL_BUILD_PROGRAM_FAILURE" << std::endl;
      }
    break;
    case CL_MAP_FAILURE:
      {
        Rcout << "CL_MAP_FAILURE" << std::endl;
      }
    break;
    case CL_MISALIGNED_SUB_BUFFER_OFFSET:
      {
        Rcout << "CL_MISALIGNED_SUB_BUFFER_OFFSET" << std::endl;
      }
    break;
    case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST:
      {
        Rcout << "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST" << std::endl;
      }
    break;
    case CL_COMPILE_PROGRAM_FAILURE:
      {
        Rcout << "CL_COMPILE_PROGRAM_FAILURE" << std::endl;
      }
    break;
    case CL_LINKER_NOT_AVAILABLE:
      {
        Rcout << "CL_LINKER_NOT_AVAILABLE" << std::endl;
      }
    break;
    case CL_LINK_PROGRAM_FAILURE:
      {
        Rcout << "CL_LINK_PROGRAM_FAILURE" << std::endl;
      }
    break;
    case CL_DEVICE_PARTITION_FAILED:
      {
        Rcout << "CL_DEVICE_PARTITION_FAILED" << std::endl;
      }
    break;
    case CL_KERNEL_ARG_INFO_NOT_AVAILABLE:
      {
        Rcout << "CL_KERNEL_ARG_INFO_NOT_AVAILABLE" << std::endl;
      }
    break;
    case CL_INVALID_VALUE:
      {
        Rcout << "CL_INVALID_VALUE" << std::endl;
      }
    break;
    case CL_INVALID_DEVICE_TYPE:
      {
        Rcout << "CL_INVALID_DEVICE_TYPE" << std::endl;
      }
    break;
    case CL_INVALID_PLATFORM:
      {
        Rcout << "CL_INVALID_PLATFORM" << std::endl;
      }
    break;
    case CL_INVALID_DEVICE:
      {
        Rcout << "CL_INVALID_DEVICE" << std::endl;
      }
    break;
    case CL_INVALID_CONTEXT:
      {
        Rcout << "CL_INVALID_CONTEXT" << std::endl;
      }
    break;
    case CL_INVALID_QUEUE_PROPERTIES:
      {
        Rcout << "CL_INVALID_QUEUE_PROPERTIES" << std::endl;
      }
    break;
    case CL_INVALID_COMMAND_QUEUE:
      {
        Rcout << "CL_INVALID_COMMAND_QUEUE" << std::endl;
      }
    break;
    case CL_INVALID_HOST_PTR:
      {
        Rcout << "CL_INVALID_HOST_PTR" << std::endl;
      }
    break;
    case CL_INVALID_MEM_OBJECT:
      {
        Rcout << "CL_INVALID_MEM_OBJECT" << std::endl;
      }
    break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR:
      {
        Rcout << "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR" << std::endl;
      }
    break;
    case CL_INVALID_IMAGE_SIZE:
      {
        Rcout << "CL_INVALID_IMAGE_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_SAMPLER:
      {
        Rcout << "CL_INVALID_SAMPLER" << std::endl;
      }
    break;
    case CL_INVALID_BINARY:
      {
        Rcout << "CL_INVALID_BINARY" << std::endl;
      }
    break;
    case CL_INVALID_BUILD_OPTIONS:
      {
        Rcout << "CL_INVALID_BUILD_OPTIONS" << std::endl;
      }
    break;
    case CL_INVALID_PROGRAM:
      {
        Rcout << "CL_INVALID_PROGRAM" << std::endl;
      }
    break;
    case CL_INVALID_PROGRAM_EXECUTABLE:
      {
        Rcout << "CL_INVALID_PROGRAM_EXECUTABLE" << std::endl;
      }
    break;
    case CL_INVALID_KERNEL_NAME:
      {
        Rcout << "CL_INVALID_KERNEL_NAME" << std::endl;
      }
    break;
    case CL_INVALID_KERNEL_DEFINITION:
      {
        Rcout << "CL_INVALID_KERNEL_DEFINITION" << std::endl;
      }
    break;
    case CL_INVALID_KERNEL:
      {
        Rcout << "CL_INVALID_KERNEL" << std::endl;
      }
    break;
    case CL_INVALID_ARG_INDEX:
      {
        Rcout << "CL_INVALID_ARG_INDEX" << std::endl;
      }
    break;
    case CL_INVALID_ARG_VALUE:
      {
        Rcout << "CL_INVALID_ARG_VALUE" << std::endl;
      }
    break;
    case CL_INVALID_ARG_SIZE:
      {
        Rcout << "CL_INVALID_ARG_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_KERNEL_ARGS:
      {
        Rcout << "CL_INVALID_KERNEL_ARGS" << std::endl;
      }
    break;
    case CL_INVALID_WORK_DIMENSION:
      {
        Rcout << "CL_INVALID_WORK_DIMENSION" << std::endl;
      }
    break;
    case CL_INVALID_WORK_GROUP_SIZE:
      {
        Rcout << "CL_INVALID_WORK_GROUP_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_WORK_ITEM_SIZE:
      {
        Rcout << "CL_INVALID_WORK_ITEM_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_GLOBAL_OFFSET:
      {
        Rcout << "CL_INVALID_GLOBAL_OFFSET" << std::endl;
      }
    break;
    case CL_INVALID_EVENT_WAIT_LIST:
      {
        Rcout << "CL_INVALID_EVENT_WAIT_LIST" << std::endl;
      }
    break;
    case CL_INVALID_EVENT:
      {
        Rcout << "CL_INVALID_EVENT" << std::endl;
      }
    break;
    case CL_INVALID_OPERATION:
      {
        Rcout << "CL_INVALID_OPERATION" << std::endl;
      }
    break;
    case CL_INVALID_GL_OBJECT:
      {
        Rcout << "CL_INVALID_GL_OBJECT" << std::endl;
      }
    break;
    case CL_INVALID_BUFFER_SIZE:
      {
        Rcout << "CL_INVALID_BUFFER_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_MIP_LEVEL:
      {
        Rcout << "CL_INVALID_MIP_LEVEL" << std::endl;
      }
    break;
    case CL_INVALID_GLOBAL_WORK_SIZE:
      {
        Rcout << "CL_INVALID_GLOBAL_WORK_SIZE" << std::endl;
      }
    break;
    case CL_INVALID_PROPERTY:
      {
        Rcout << "CL_INVALID_PROPERTY" << std::endl;
      }
    break;
    case CL_INVALID_IMAGE_DESCRIPTOR:
      {
        Rcout << "CL_INVALID_IMAGE_DESCRIPTOR" << std::endl;
      }
    break;
    case CL_INVALID_COMPILER_OPTIONS:
      {
        Rcout << "CL_INVALID_COMPILER_OPTIONS" << std::endl;
      }
    break;
    case CL_INVALID_LINKER_OPTIONS:
      {
        Rcout << "CL_INVALID_LINKER_OPTIONS" << std::endl;
      }
    break;
    case CL_INVALID_DEVICE_PARTITION_COUNT:
      {
      Rcout << "CL_INVALID_DEVICE_PARTITION_COUNT" << std::endl;
      }
    break;

  }
}

OclHandler::OclHandler(List &device_list, List &codeinfo)
{
  // This is the acutal code
  std::string kcode = codeinfo["code"];
  // This is the md5sum of the code
  std::string code_md5 = codeinfo["md5"];

  // Add the kernel code to the sources
  sources.push_back({kcode.c_str(), kcode.length()});

  // Get all available platforms (drivers)
  cl::Platform::get(&all_platforms);
  if (all_platforms.size() == 0)
  {
    Rcout <<" No platforms found. Check OpenCL installation!" << std::endl;
    exit(1);
  }

  // This vector will hold all the devices on a given platform
  std::vector<cl::Device> plat_dev;
  // Initialize the total work items to 0
  totalwi = 0;

  // The current platform
  List plat_list;

  for (uint index = 0; index < device_list.length(); index++) {

    // This is the list for the platform-device pair
    plat_list = device_list[index];

    uint plat_num   = plat_list["plat_num"];
    uint device_num = plat_list["dev_num"];
    uint nchains    = plat_list["work_items"];
    uint use_bin    = plat_list["use_bin"];
   
    // Add this to the device specific vector
    chains.push_back(nchains);
    // And add to the total work item count
    totalwi += nchains;

    // Get all the devices for this platform
    all_platforms[plat_num].getDevices(CL_DEVICE_TYPE_ALL, &plat_dev);

    // Every device passed as this list should exist, it's an error if it doesn't
    if ((plat_dev.size() + 1) < device_num)
    {
      Rcout << "Device "
        << device_num
        << " is not available on platform: "
        << plat_num
        << ". Check OpenCL installation!"
        << std::endl;
      exit(1);
    }
    // Keep track of the device that we care about
    devices.push_back(plat_dev[device_num]);

    // The context for this device
    contexts.push_back(
      cl::Context(devices[index])
    );

    // The file name of the compiled binary
    std::string filename = code_md5 + "_" + std::to_string(plat_num) + "_" + toString(device_num) + ".bin";

    if (use_bin == 1) {

      // Open the file for reading
      std::ifstream file(filename, std::ios::binary);
      // don't eat new lines
      file.unsetf(std::ios::skipws);

      // Get the size of the file
      std::streampos fileSize;

      file.seekg(0, std::ios::end);
      fileSize = file.tellg();
      file.seekg(0, std::ios::beg);

      // The data for the binary
      std::vector<unsigned char> bin_data;
      bin_data.reserve(fileSize);

      // Read in the data
      bin_data.insert(bin_data.begin(),
                      std::istream_iterator<unsigned char>(file),
                      std::istream_iterator<unsigned char>());

      programs.push_back(cl::Program(
        contexts[index], {devices[index]},
        {bin_data}
      ));
      int build_check = programs[index].build();
      if (build_check != CL_SUCCESS)
      {
        Rcout << "Error building for platform " << plat_num << " device " << device_num << std::endl;
        Rcout << "Error Code: " << build_check << std::endl;
        builderrors(build_check);

        std::string buildlog = programs[index].getBuildInfo<CL_PROGRAM_BUILD_LOG>(devices[index]);
        Rcout << buildlog << std::endl;
        exit(1);
      } else {
        Rcout << "BINARY Kernel built successfully." << std::endl;
        Rcout << "Build Log" << std::endl;
        std::string buildlog = programs[index].getBuildInfo<CL_PROGRAM_BUILD_LOG>(devices[index]);
        Rcout << buildlog << std::endl;
      }

    } else {

      // Make the progam object
      programs.push_back(
        cl::Program(
          contexts[index],
          sources)
      );

      // Actually build the program
      int build_code = programs[index].build();
      // Check that it worked, and print the build log
      if (build_code != CL_SUCCESS)
      {
        Rcout << "Error building for platform " << plat_num << " device " << device_num << std::endl;
        Rcout << "Error Code: " << build_code << std::endl;
        builderrors(build_code);

        std::string buildlog = programs[index].getBuildInfo<CL_PROGRAM_BUILD_LOG>(devices[index]);
        Rcout << buildlog << std::endl;
        exit(1);
      } else {
        Rcout << "SOURCE Kernel built successfully." << std::endl;
        Rcout << "Build Log" << std::endl;
        std::string buildlog = programs[index].getBuildInfo<CL_PROGRAM_BUILD_LOG>(devices[index]);
        Rcout << buildlog << std::endl;
      }

      // Save the compiled binary
      // First figure out how big the binary is for this device
      std::vector<unsigned long> binSizes = programs[index].getInfo<CL_PROGRAM_BINARY_SIZES>();
      // calculate the total number of bytes...
      uint total_bytes = std::accumulate(binSizes.begin(), binSizes.end(), 0);

      // And make a char vector of the size of the total bytes
      std::vector<char> binData (total_bytes);
      // Make a vector pointing to these bytes
      std::vector<char*> binaries;

      // get the pointer to the first element of the binData
      char* binChunk = &binData[0];

      for (uint i = 0; i < binSizes.size(); i++) {
        binaries.push_back(binChunk);
        binChunk += binSizes[i];
      }

      programs[index].getInfo(CL_PROGRAM_BINARIES, &binaries[0]);

      std::ofstream binaryfile(filename);

      if(!binaryfile.good()) std::runtime_error("Failed to open the binary filw for writing.");
      for (size_t i = 0; i < binaries.size(); ++i) {
        binaryfile.write(binaries[i], binSizes[i]);
      }
      // Done making binaries

    }

    // Make the queue for this device
    queues.push_back(
      cl::CommandQueue(contexts[index], devices[index])
    );
    
  }

  // Wrapping up
  // How many devices do we have?
  ndev = devices.size();
  // Make the vector of kernsl
  kernels = std::vector<cl::Kernel>(ndev);
}

void OclHandler::finish()
{
  for (uint device = 0; device < this->ndev; device++)
  {
    this->queues[device].finish();
  }
}

void OclHandler::run_kernel(std::string kernel_name)
{

  std::vector<std::string> named_args {
    "post",
    "par",
    "rng",
    "aux_mean",
    "aux_invcov",
    "aux_chol",
    "aux_logdet",
    "accepts",
    "batches",
    "sampling_type",
    "iter_info"
  };

  int arg_index = 0;
  int buf_index = 0;

  // Loop through all the devices
  for (uint device = 0; device < this->ndev; device++)
  {
    // Run the kernel
    this->kernels[device] = cl::Kernel(this->programs[device], kernel_name.c_str());

    arg_index = 0;
    // Add the named arguments
    for (std::string name : named_args) {
      buf_index = this->named_buffers[name];
      this->kernels[device].setArg(arg_index, buffers[device][buf_index]);
      arg_index++;
    }

    // Add the unnamed arguments - only for the main kernel
    for (int j = 0; j < (int)this->unnamed_buffers.size(); j++) {
      buf_index = unnamed_buffers[j];
      this->kernels[device].setArg(arg_index, buffers[device][buf_index]);
      arg_index++;
    }

    this->queues[device].enqueueNDRangeKernel(this->kernels[device],
                                         cl::NullRange,
                                         cl::NDRange(this->chains[device]),
                                         cl::NullRange);
  }
}

void OclHandler::run_mean(List &config)
{

  std::string kernel_name = "calc_mean";

  int npars  = config["npar"];

  std::vector<std::string> named_args {
    "par",
    "aux_mean",
    "accepts",
    "parinfo",
  };

  int arg_index = 0;
  int buf_index = 0;

  // Loop through all the devices
  for (uint device = 0; device < this->ndev; device++)
  {
    // Run the kernel
    this->kernels[device] = cl::Kernel(this->programs[device], kernel_name.c_str());

    arg_index = 0;
    // Add the named arguments
    for (std::string name : named_args) {
      buf_index = this->named_buffers[name];
      this->kernels[device].setArg(arg_index, buffers[device][buf_index]);
      arg_index++;
    }

    // Set the number of chains specific to this device so that the loop doesn't overrun
    this->kernels[device].setArg(arg_index, this->chains[device]);
    arg_index++;

    this->queues[device].enqueueNDRangeKernel(this->kernels[device],
                                         cl::NullRange,
                                         cl::NDRange(npars),
                                         cl::NullRange);
  }
}

void OclHandler::run_cov(List &config)
{

  std::string kernel_name = "calc_cov";

  std::vector<std::string> named_args {
    "par",
    "aux_invcov",
    "batches",
    "parinfo",
  };

  int cov_vec_size = config["cov_vec_size"];

  int arg_index = 0;
  int buf_index = 0;

  // Loop through all the devices
  for (uint device = 0; device < this->ndev; device++)
  {
    // Run the kernel
    this->kernels[device] = cl::Kernel(this->programs[device], kernel_name.c_str());

    arg_index = 0;
    // Add the named arguments
    for (std::string name : named_args) {
      buf_index = this->named_buffers[name];
      this->kernels[device].setArg(arg_index, buffers[device][buf_index]);
      arg_index++;
    }

    // Set the number of chains specific to this device so that the loop doesn't overrun
    this->kernels[device].setArg(arg_index, this->chains[device]);
    arg_index++;

    this->queues[device].enqueueNDRangeKernel(this->kernels[device],
                                         cl::NullRange,
                                         cl::NDRange(cov_vec_size),
                                         cl::NullRange);
  }
}

int OclHandler::bi()
{
  return(this->buffers[0].size() - 1);
}
