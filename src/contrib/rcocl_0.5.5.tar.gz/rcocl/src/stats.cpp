// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

typedef unsigned int uint;

Stats::Stats(List config, int ncols)
{
  // If this is 1, start collecting samples
  this->collect_signal = 0;

  // Minimum number of iterations
  int skip = config["skip"];

  // How many columns are being used?
  this->ncols  = ncols;
  this->buffer = std::vector<rtype>(ncols);

  // Keep track of lots of things for the regression approach
  this->index  = 0;

  // Sign of the beta coefficient
  this->bhat_sign[0] = 0;
  this->bhat_sign[1] = 0;

  // Minimum number of iterations
  this->iter_min = skip;

  // Actual data being stored and saved
  std::vector<std::vector<rtype>> j;
  this->data = j;
}

void Stats::check_collect()
{
  // After the minimum iterations are met, start collecting
  this->collect_signal = (this->data.size() - 1) < this->iter_min ? 0 : 1;
}

void Stats::add(rtype val)
{
  // Assign the value to the relevent position in the index
  this->buffer.at(this->index) = val;
  // Increment the buffer index
  this->index++;

  // If we've reached the last column, reset the index, and push the row
  if (this->index >= this->ncols) {
    // Index reset
    this->index = 0;
    // Push the buffer
    this->data.push_back(this->buffer);
  }
}

rtype Stats::get(int col)
{
  return this->data.back().at(col);
}

NumericMatrix Stats::to_mat()
{
  NumericMatrix out(this->data.size(), this->ncols);
  for (uint row = 0; row < this->data.size(); row++) {
    for (uint col = 0; col < this->ncols; col++) {
      out.at(row, col) = this->data.at(row).at(col);
    }
  }
  return out;
}
