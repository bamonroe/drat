// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <CL/opencl.hpp>
#include <unistd.h>

using namespace Rcpp;

typedef std::vector<cl::Device> DevVec;
typedef unsigned int uint;

struct DeviceInfo {
  std::string name;
  cl_device_type type;
  std::string type_s;
  std::string profile;
  cl_ulong global_mem;
};

struct PlatformInfo {
  std::string name;
  std::string version;
  std::string vendor;
  int ndevices;
};

//' @title Get info about OpenCL Platforms and devices
//' @export clinfo
// [[Rcpp::export]]
void clinfo() {
  // Collect the platforms
  std::vector<cl::Platform> platforms;
  std::vector<DevVec> all_devices;
  // Collect the platforms
  cl::Platform::get(&platforms);
  // How many?
  Rcout << "Number of Platforms: " << platforms.size() << std::endl << std::endl;

  std::vector<PlatformInfo> pinfo_vec;
  std::vector<std::vector<DeviceInfo>> dinfo_vec;

  for (uint platform = 0; platform < platforms.size(); platform++) {
    Rcout << "Platform: " << platform << std::endl;

    // Get the Devices
    DevVec dvec;
    platforms[platform].getDevices(CL_DEVICE_TYPE_ALL, &dvec);
    all_devices.push_back(dvec);

    PlatformInfo pinfo;
    platforms[platform].getInfo((cl_platform_info)CL_PLATFORM_NAME,    &pinfo.name);
    platforms[platform].getInfo((cl_platform_info)CL_PLATFORM_VERSION, &pinfo.version);
    platforms[platform].getInfo((cl_platform_info)CL_PLATFORM_VENDOR,  &pinfo.vendor);
    platforms[platform].getInfo((cl_platform_info)CL_PLATFORM_SEMAPHORE_TYPES_KHR, &pinfo.vendor);

    pinfo.ndevices = all_devices[platform].size();
    pinfo_vec.push_back(pinfo);


    Rcout << "  Platform Name:     " << pinfo.name     << std::endl;
    Rcout << "  Platform Version:  " << pinfo.version  << std::endl;
    Rcout << "  Platform Vendor:   " << pinfo.vendor   << std::endl;
    Rcout << "  Number of devices: " << pinfo.ndevices << std::endl;

    std::vector<DeviceInfo> alldev_info;
    DeviceInfo dinfo;
    for (uint device = 0; device < all_devices[platform].size(); device++) {
      Rcout << "    Device: " << device << std::endl;

      all_devices[platform][device].getInfo(CL_DEVICE_NAME, &dinfo.name);
      all_devices[platform][device].getInfo(CL_DEVICE_TYPE, &dinfo.type);
      all_devices[platform][device].getInfo(CL_DEVICE_PROFILE, &dinfo.profile);
      all_devices[platform][device].getInfo(CL_DEVICE_GLOBAL_MEM_SIZE, &dinfo.global_mem);

      // Change the type to something human readable
      switch (dinfo.type) {
        case CL_DEVICE_TYPE_CPU:
          dinfo.type_s = "CPU";
          break;
        case CL_DEVICE_TYPE_GPU:
          dinfo.type_s = "GPU";
          break;
        case CL_DEVICE_TYPE_ACCELERATOR:
          dinfo.type_s = "Accelerator";
          break;
        case CL_DEVICE_TYPE_DEFAULT:
          dinfo.type_s = "Default";
          break;
        case CL_DEVICE_TYPE_CUSTOM:
          dinfo.type_s = "Custom";
          break;
      }

      Rcout << "      Name:         " << dinfo.name      << std::endl
            << "      Type:         " << dinfo.type_s    << std::endl
            << "      Profile:      " << dinfo.profile   << std::endl
            << "      Global Mem:   " << dinfo.global_mem / (1024*1024) << "MB" << std::endl;

      alldev_info.push_back(dinfo);
    }
    dinfo_vec.push_back(alldev_info);
    
    Rcout << std::endl;
  }

}
