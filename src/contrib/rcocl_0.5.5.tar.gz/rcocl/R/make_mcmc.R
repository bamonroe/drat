get_mcmc_cnames <- function(n, type, name, spaces, prefix) {
  if (n == 0) {
    return(NULL)
  }
  # make a number of preceeding spaces (for aesthetic on debugging really)
  spaces <- paste(rep(" ", spaces), collapse = "")
  # Generic names for the parameters
  out <- paste0(name, seq_len(n))
  if (prefix != "") {
    out <- paste0(spaces, prefix, " ", type, "* ", out)
  } else {
    out <- paste0(spaces, out)
  }
  out <- paste(out, collapse = ",\n")
  out
}

dat_nitems <- function(dat) {
  v <- c("double", "int")
  o <- lapply(v, function(type) {
    length(dat[[type]])
  })
  names(o) <- v
  o
}

get_dinames <- function(dat, spaces = 2, add_scope = TRUE) {

  nitems <- dat_nitems(dat)

  gscope <- ifelse(add_scope, "global", "")

  gdnames <- get_mcmc_cnames(nitems[["double"]], "float", "gd",  spaces, gscope)
  ginames <- get_mcmc_cnames(nitems[["int"]],    "int",   "gi",  spaces, gscope)

  dinames <- paste(c(gdnames, ginames), collapse = ",\n")
  dinames
}

# Make the mcmc kernel to export as OpenCL
make_mcmc_kern <- function(dat, fn, algo) {

  # Get the mhmc or gibbs file
  fname <- system.file(package = "rcocl", paste0(algo, ".c"))
  code  <- readLines(fname)
  code <- paste(code, collapse = "\n")

  # Start replacing bits
  code <- gsub(pattern = "@@function_name@@", replacement = fn, x = code)

  # Get the definition user args
  dinames <- get_dinames(dat, spaces = 2, add_scope = TRUE)
  code <- gsub(pattern = "@@def_user_args@@", replacement = dinames, x = code)

  # Get the function user args
  dinames <- get_dinames(dat, spaces = 8, add_scope = FALSE)
  code <- gsub(pattern = "@@fn_user_args@@", replacement = dinames, x = code)

  code
}

# Make define statements programatically
define <- function(name, value) {
  paste0("#define ", toupper(name), " ", value)
}

make_defines <- function(cfg) {
  options(digits = 10)
  out <- c()
  for (i in names(cfg)) {
    out <- c(out, define(i, cfg[[i]]))
  }
  paste(out, collapse = "\n")
}

get_file <- function(fnames = c()) {
  flines <- c()

  for (fn in fnames) {
    fconn <- file(description = fn, open = "r")
    lines <- readLines(con = fconn)
    lines <- paste(lines, collapse = "\n")
    lines <- paste0("\n", lines, "\n")
    close(fconn)

    flines <- paste(flines, lines, collapse = "\n\n")
  }

  fconn <- file("full.c", open = "w")
  writeLines(text = flines, con = fconn, sep = "")
  close(fconn)

  flines
}
