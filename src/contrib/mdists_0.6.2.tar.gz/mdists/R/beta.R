#' @title dbeta with mean and standard deviation
#'
#' @param x vector of quantiles
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @param psi psi parameter of beta distribution
#' @export mdbeta
mdbeta <- function(x, mu, sigma = NA, psi = NULL) {
  if (is.null(psi)) {
    # Derive psi from mean and standard deviation
    sigma2 <- sigma^2
    psi <- (mu * (1 - mu) - sigma2) / sigma2
  }
  # Recover the alpha and beta parameters from mu and psi
  apar <- mu * psi
  bpar <- (1 - mu) * psi

  dbeta(x = x, shape1 = apar, shape2 = bpar)
}

#' @title pbeta with mean and standard deviation
#'
#' @param q vector of quantiles
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @param psi psi parameter of beta distribution
#' @export mpbeta
mpbeta <- function(q, mu, sigma = NA, psi = NULL) {

  if (is.null(psi)) {
    # Derive psi from mean and standard deviation
    sigma2 <- sigma^2
    psi <- (mu * (1 - mu) - sigma2) / sigma2
  }
  # Recover the alpha and beta parameters from mu and psi
  apar <- mu * psi
  bpar <- (1 - mu) * psi

  pbeta(q = q, shape1 = apar, shape2 = bpar)
}

#' @title qbeta with mean and standard deviation
#'
#' @param p vector of probabilities
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @param psi psi parameter of beta distribution
#' @export mqbeta
mqbeta <- function(p, mu, sigma = NA, psi = NULL) {
  if (is.null(psi)) {
    # Derive psi from mean and standard deviation
    sigma2 <- sigma^2
    psi <- (mu * (1 - mu) - sigma2) / sigma2
  }
  # Recover the alpha and beta parameters from mu and psi
  apar <- mu * psi
  bpar <- (1 - mu) * psi

  qbeta(p = p, shape1 = apar, shape2 = bpar)
}

#' @title rbeta with mean and standard deviation
#'
#' @param n number of oberservations
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @param psi psi parameter of beta distribution
#' @export mrbeta
mrbeta <- function(n, mu, sigma = NA, psi = NULL) {
  if (is.null(psi)) {
    # Derive psi from mean and standard deviation
    sigma2 <- sigma^2
    psi <- (mu * (1 - mu) - sigma2) / sigma2
  }
  # Recover the alpha and beta parameters from mu and psi
  apar <- mu * psi
  bpar <- (1 - mu) * psi

  rbeta(n = n, shape1 = apar, shape2 = bpar)
}
