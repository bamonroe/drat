ln_mean <- function(mu, s) {
  log(mu / sqrt(1 + (s^2 / mu^2)))
}

ln_sd <- function(mu, s) {
  sqrt(log(1 + s^2 / mu^2))
}

#' @title Return the log_space mean and sd from normal mean sd
#' @export lnorm
lnorm <- function(m, s) {
  c(mean = ln_mean(m, s), sd = ln_sd(m, s))
}

#' @title Density Log-normal distribution
#'
#' @param x vector of quantiles
#' @param mean the mean of the distribution
#' @param sigma the standard deviation of the distribution
#' @export mdlnorm
mdlnorm <- function(x, mean = 1, sigma = 1) {
  lm <- ln_mean(mean, sigma)
  ls <- ln_sd(mean, sigma)
  stats::dlnorm(x = x, meanlog = lm, sdlog = ls)
}

#' @title Log-normal distribution
#'
#' @param q vector of quantiles
#' @param mean the mean of the distribution
#' @param sigma the standard deviation of the distribution
#' @export mplnorm
mplnorm <- function(q, mean = 1, sigma = 1) {
  lm <- ln_mean(mean, sigma)
  ls <- ln_sd(mean, sigma)
  stats::plnorm(q = q, meanlog = lm, sdlog = ls)
}

#' @title Quantile Log-normal distribution
#'
#' @param p vector of probabilityes
#' @param mean the mean of the distribution
#' @param sigma the standard deviation of the distribution
#' @export mqlnorm
mqlnorm <- function(p, mean = 1, sigma = 1) {
  lm <- ln_mean(mean, sigma)
  ls <- ln_sd(mean, sigma)
  stats::qlnorm(p = p, meanlog = lm, sdlog = ls)
}


#' @title Random Log-normal distribution
#'
#' @param n the number of random numbers
#' @param mean the mean of the distribution
#' @param sigma the standard deviation of the distribution
#' @export mrlnorm
mrlnorm <- function(n = 1, mean = 1, sigma = 1) {
  lm <- ln_mean(mean, sigma)
  ls <- ln_sd(mean, sigma)
  stats::rlnorm(n = n, meanlog = lm, sdlog = ls)
}
