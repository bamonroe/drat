#' @title Beta-Binomial Function
#'
#' @param n n for the choose function
#' @param k k for the choose function
#' @param a a for the beta function
#' @param b b for the beta function
#' @export bbinom
bbinom <- function(n, k, a, b) {
  choose(n, k) * exp(lbeta(k + a, n - k + b) - lbeta(a, b))
}

#' @title Beta-Binomial Function - New Formulation
#'
#' @param n n for the choose function
#' @param k k for the choose function
#' @param a a for the beta function
#' @param b b for the beta function
#' @export bbinom2
bbinom2 <- function(k, n, a, b) {
  if (k == 0) {
    num <- seq_len(n) + b - 1
    den <- seq_len(n) + a + b - 1
    out <- exp(sum(log(num) - log(den)))
  } else if (n == k) {
    num <- seq_len(n) + a - 1
    den <- seq_len(n) + a + b - 1
    out <- exp(sum(log(num) - log(den)))
  } else {
    first <- seq_len(n)
    first <- log(first) - log(first + a + b - 1)
    first <- sum(first)

    second <- seq_len(n - k)
    second <- log(second + b - 1) - log(second)
    second <- sum(second)

    third <- seq_len(k)
    third <- log(third + a - 1) - log(third)
    third <- sum(third)

    out <- exp(sum(first, second, third))
  }
  out
}
