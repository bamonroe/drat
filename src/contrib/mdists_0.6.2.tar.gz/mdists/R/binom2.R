#' @title Binomial Mixture
#'
#' @description
#' A linear mixture of two binomial distributions defined over the same n and k
#' @param k k parameter for dbinom
#' @param n n parameter for dbinom
#' @param p1 probability of success for first binomial distribution
#' @param p2 probability of success for second binomial distribution
#' @param p3 mixture value for the two distributions
#' @examples
#' dbinom2(k = 0:9, n = 9, p1 = .01, p2 = .5, p3 = .75)
#' @export dbinom2
dbinom2 <- function(k, n, p1, p2, p3) {
  dbinom(x = k, size = n, prob = p1) * p3 + dbinom(k, n, p2) * (1 - p3)
}

#' @title Binomial With Shaper
#'
#' @description
#' binomial distribution with a shape parameter
#' @param k k parameter for dbinom
#' @param n n parameter for dbinom
#' @param p1 probability of success for first binomial distribution
#' @param s scale parameter
#' @examples
#' sbinom(k = 0:9, n = 9, p1 = .01, s = 2)
#' @export sbinom
sbinom <- function(k, n, p1, s) {
  val <- dbinom(x = k, size = n, prob = p1)^s
  val / sum(val)
}
