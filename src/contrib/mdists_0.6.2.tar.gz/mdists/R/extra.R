#' @useDynLib mdists
#' @importFrom Rcpp sourceCpp
NULL

