#' @title dgamma with mean and variance
#'
#' @param x vector of quantiles
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @export mdgamma
mdgamma <- function(x, mu, sigma) {
  sigma <- sigma^2
  shape <- mu^2 / sigma
  rate  <- mu / sigma
  dgamma(x = x, shape = shape, rate = rate)
}

#' @title pgamma with mean and variance
#'
#' @param q vector of quantites
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @export mpgamma
mpgamma <- function(q, mu, sigma) {
  sigma <- sigma^2
  shape <- mu^2 / sigma
  rate  <- mu / sigma
  pgamma(q = q, shape = shape, rate = rate)
}

#' @title qgamma with mean and variance
#'
#' @param p vector of probabilities
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @export mqgamma
mqgamma <- function(p, mu, sigma) {
  sigma <- sigma^2
  shape <- mu^2 / sigma
  rate  <- mu / sigma
  qgamma(p = p, shape = shape, rate = rate)
}

#' @title rgamma with mean and variance
#'
#' @param n number of oberservations
#' @param mu mean of the distribution
#' @param sigma standard deviation of the distribution
#' @export mrgamma
mrgamma <- function(n, mu, sigma) {
  sigma <- sigma^2
  shape <- mu^2 / sigma
  rate  <- mu / sigma
  rgamma(n = n, shape = shape, rate = rate)
}
