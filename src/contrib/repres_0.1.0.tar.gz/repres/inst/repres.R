#' @title Specify the location of the top_level directory
#' @description This function creates the necessary directories for the local repositories
#' @param top_level the location where the R_library folder will be made
#' @export top_level_dirs
top_level_dirs <- function(top_level = NULL) {

  # Set some default repos if they haven't been specified
  repos <- getOption("repos")
  # My personal repo
  if (! "bam" %in% names(repos)) {
    repos["bam"]  <- "https://bamonroe.com/drat"
  }
  # The repo for the CRAN project
  if (! "CRAN" %in% names(repos) || repos["CRAN"] == "@CRAN@") {
    repos["CRAN"] <- "https://cloud.r-project.org/"
  }
  options(repos = repos)

  if (is.null(top_level)) {
    # The top level directory of the project. Needed for directory management
    # Can be anywhere, but since I usually have a "code" directory,
    # I set this to be one level up from where the code is run
    # It should be a relative path for reproducibility
    top_level <- getOption("repres_top_level", default = getwd())
  } else {
    options(repres_top_level = top_level)
  }

  # Setup the directories for library/repo work
  R_library <- file.path(top_level, "R_library", "library")
  R_repo    <- file.path(top_level, "R_library", "repo")
  R_contrib <- file.path(top_level, "R_library", "repo", "src", "contrib")

  if (! dir.exists(R_library)) dir.create(path = R_library, recursive = TRUE)
  if (! dir.exists(R_repo))    dir.create(path = R_repo,    recursive = TRUE)
  if (! dir.exists(R_contrib)) dir.create(path = R_contrib, recursive = TRUE)

  dirs <- list(
    R_library = R_library,
    R_repo    = R_repo,
    R_contrib = R_contrib
  )
  options(repres_dirs = dirs)
  return(dirs)
}

### Functions for reproducible research

#' @title Function to download packages
#' @description This function downloads a package, and all it's dependencies into the R_contrib directory
#'   and then writes the repo files so we can use R_contrib as a local R repo
#' @param pkgs character vector of packages to download
#' @param repos optional vector of repos to download packages from
#' @export download_packages
download_packages <- function(pkgs, repos = NULL) {

  dirs <- top_level_dirs()

  # What packages are currently downloaded
  if (file.exists(file.path(dirs$R_contrib, "PACKAGES"))) {
    contriburl        <- utils::contrib.url(file.path("file://", dirs$R_repo), "source")
    ap_local          <- utils::available.packages(contriburl = contriburl)
    local_have        <- ap_local[, "Package"]
    names(local_have) <- NULL
  } else {
    ap_local   <- NULL
    local_have <- NULL
  }
  # Use a specific repo if it's passed in, but otherwise use the default repos
  if (is.null(repos)) repos <- getOption("repos")

  # What packages are available remotely
  ap_remote <- utils::available.packages(repos = repos)

  dpkgs  <- tools::package_dependencies(
    packages  = pkgs,
    db        = ap_remote,
    which     = c("Depends", "Imports", "LinkingTo"),
    recursive = TRUE
  )
  dpkgs <- unlist(dpkgs)
  pkgs  <- union(dpkgs, pkgs)

  # Don't get the packages I already have
  pkgs <- pkgs[! pkgs %in% local_have]
  # Download the source packages
  utils::download.packages(
    pkgs      = pkgs,
    destdir   = dirs$R_contrib,
    available = ap_remote,
    repos     = repos,
    type      = "source"
  )
  # Write the new repo
  tools::write_PACKAGES(dirs$R_contrib, type = "source")
  cat("**\n** Finished Downloading Packages Locally\n**\n\n")
}

#' @title Reproducably install packages
#' @description This function installs packages from the local repo after checking for them
#' @param pkgs character vector of packages to download
#' @param ...  additional arguments to pass to the install.packages function. Note that some are overwritten
#' @export install.packages
install.packages <- function(pkgs, ...) {

  dirs <- top_level_dirs()

  dargs <- list(...)

  dargs$pkgs         <- pkgs
  dargs$lib          <- dirs$R_library
  dargs$contriburl   <- contrib.url(file.path("file://", dirs$R_repo), "source")
  dargs$dependencies <- c("Depends", "Imports", "LinkingTo")
  dargs$type         <- "source"

  # Download the packages and their dependencies into the local repo
  download_packages(pkgs, dargs$repos)

  # Install the packages from the local repo using the real install.packages function
  do.call(utils::install.packages, dargs)
}

#' @title Load packages from local repository
#' @description Replace the regular library and update.packages functions with one that downloads missing packages,
#'   creates a local repo for those packages, and installs those packages.
#' @param pkg package to load. Can be lazy loaded like utils::library
#' @param ... additional arguments passed to library and install.packages. Some arguments are overwritten
#' @export library
library <- function(pkg, ...) {

  dirs <- top_level_dirs()

  # Setup the arg vector from the ...
  # I need a pkg character string to download packages, so we need to sort this out
  dargs <- list(...)
  if (! "character.only" %in% names(dargs) || !dargs[["character.only"]]) {
    pkg <- as.character(substitute(pkg))
  }

  dargs$package        <- pkg
  dargs$character.only <- TRUE
  dargs$lib.loc        <- dirs$R_library
  dargs$quietly        <- TRUE

  # remove all libs but the local one
  .libPaths(dirs$R_library, include.site = TRUE)
  # Location of the local library. I prefer every project to have its own
  # library environment
  if (!do.call(require, dargs)) {
    install.packages(pkg)
    # Try loading it again, use library because it will
    # throw an error instead of a warning here
    do.call(base::library, dargs)
  }
  return(invisible(TRUE))
}


#' @title Update packages in the local repository
#' @param ...  currently discarded
#' @export update.packages
update.packages <- function(...) {

  dirs <- top_level_dirs()

  # Figure out what packages need to be updated
  opkg <- old.packages(lib.loc = dirs$R_library)
  opkg <- opkg[, "Package"]

  # If nothing to update, just quit here
  if (is.null(opkg)) return(invisible(NULL))

  # Delete the old source files
  dpkg <- list.files(dirs$R_contrib)
  for (old in opkg){
    sw <- startsWith(dpkg, old)
    sw <- file.path(dirs$R_contrib, dpkg[sw])
    file.remove(sw)
  }

  # Write the new repo
  tools::write_PACKAGES(dirs$R_contrib, type = "source")

  # Install the packages
  install.packages(opkg)
}
