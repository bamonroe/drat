## repres

#### A package to aid in the development of (rep)roducible (res)earch in R


Doing reproducible research in R can be difficult if you want the analyses to
be able to be replicated years later. Packages change and can break functions
that the research initially relied on. My solution is to install all packages
needed for an analysis into a local R library and make a local R repo using
these downloaded packages. When a project is "done", both of these directories
should be committed and shipped with the project. To reproduce an analysis, a
future user will just need the correct version of R, or at least a version of R
with backwards-compatible base functions, which rarely change.

The below shows how this is meant to be used. First, after ensuring you are in
the directory your project code will be, run the `repres()` function to get
started. This copies over the `repres.R` file that contains all the necessary
functions. You need to source this file, and set the location of where you'd
like your repo located (if not the current dir), then just code like you
normally would.

```r
# Source the repres functions
source("repres.R")
# Set the location of the R_library directory (defaults to current dir)
# This will contain the local library and repo
top_level_dirs("../")

# Now just go about your day, loading libraries as usual
library(ggplot2)
```
