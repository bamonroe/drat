// [[Rcpp::interfaces(r, cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

//' Generic Utility calculation
//'
//' @param pmat the parameter vector
//' @param inst the data.frame insrument as a list of its components
//' @param ftypes the ftypes list
//' @param ft_index the ft_index list for the parameters
//' @param profile the reginst profile for the instrument as defined by rcest
//' @export calc_utility
// [[Rcpp::export]]
arma::mat calc_utility(arma::mat pmat, DataFrame inst, List ftypes, List ft_index, List profile) {

	int dbug = 0;

	// Get the function types
	std::string ufun = ftypes["ufun"];
	std::string pfun = ftypes["pfun"];
	std::string tfun = ftypes["tfun"];
	std::string sfun = ftypes["sfun"];
	std::string dfun = ftypes["dfun"];

	// Get the indicies of the parameters that need to be passed to each piece
	arma::uvec uind = ft_index["ufun"];
	arma::uvec pind = ft_index["pfun"];
	arma::uvec tind = ft_index["tfun"];
	arma::uvec sind = ft_index["sfun"];

	// R indexes from 1, Rcpp from 0, so adjust each index down one and take care for underflow.
	uind = min(uind, uind - 1);
	pind = min(pind, pind - 1);
	tind = min(tind, tind - 1);
	sind = min(sind, sind - 1);

	// Get the parameters that need to be passed to each piece
	arma::mat upar = pmat.cols(uind);
	arma::mat ppar = pmat.cols(pind);
	arma::mat tpar = pmat.cols(tind);
	arma::mat spar = pmat.cols(sind);

	// Just like with the above matricies, we need more info to reconstruct pointers
	arma::uword upar_num = upar.n_cols;
	arma::uword ppar_num = ppar.n_cols;
	arma::uword tpar_num = tpar.n_cols;
	arma::uword spar_num = spar.n_cols;

	double* upar_mem = upar.memptr();
	double* ppar_mem = ppar.memptr();
	double* tpar_mem = tpar.memptr();
	double* spar_mem = spar.memptr();

	// Put everything into cubes
	arma::cube outcomes = inst_cube(inst, profile, "outcomes");
	arma::cube probs    = inst_cube(inst, profile, "probabilities");
	arma::cube times(outcomes.n_rows, outcomes.n_cols, outcomes.n_slices, arma::fill::ones);
	if (tfun != "none") {
		times = inst_cube(inst, profile, "times");
	}

	// From here we have the needed info to reconstruct pointers and generate other matricies
	arma::uword nslice = outcomes.n_slices;
	arma::uword nrow   = outcomes.n_rows;
	arma::uword ncol   = outcomes.n_cols;

	// Max and Min outcomes get a matrix
	arma::uword maxi = profile["Max"];
	arma::uword mini = profile["Min"];

	arma::mat Max_Min(nrow, 2);
	Max_Min.col(0) = Rcpp::as<arma::colvec>(inst[maxi - 1]);
	Max_Min.col(1) = Rcpp::as<arma::colvec>(inst[mini - 1]);

	// The Utility of each option
	arma::mat Utility(nrow, nslice);

	// Grab the pointers
	double* outs_mem    = outcomes.memptr();
	double* probs_mem   = probs.memptr();
	double* times_mem   = times.memptr();
	double* Max_Min_mem = Max_Min.memptr();
	double* U_mem       = Utility.memptr();

	// Do the utility function transformations
	utility(ufun, upar_mem, upar_num, outs_mem, Max_Min_mem, nrow, ncol, nslice);

	// Do the probability weighting function transformations
	pweight(pfun, ppar_mem, ppar_num, probs_mem, nrow, ncol, nslice);

	// Generate the discount factors from the time horizons
	discount(tfun, tpar_mem, tpar_num, times_mem, nrow, ncol, nslice);

	// Multiply the utility of the outcomes by the probabilities and take the rowsum
	for (arma::uword s = 0; s < nslice ; s++) {
		outcomes.slice(s) %= times.slice(s);
		outcomes.slice(s) %= probs.slice(s);
		Utility.col(s) = sum(outcomes.slice(s), 1);
	}

	// Adjust Utilities stocastically
	stochastic(sfun, spar_mem, spar_num, U_mem, Max_Min_mem, nrow, nslice);

	return(Utility);
}

//' Generic Certainty Equivalent Calculation
//'
//' @param pmat the parameter vector
//' @param inst the data.frame insrument as a list of its components
//' @param ftypes the ftypes list
//' @param ft_index the ft_index list for the parameters
//' @param profile the reginst profile for the instrument as defined by rcest
//' @export calc_ce
// [[Rcpp::export]]
arma::mat calc_ce(arma::mat pmat, DataFrame inst, List ftypes, List ft_index, List profile) {

	ftypes["sfun"] = "none";

	// Get the function types
	std::string ufun     = ftypes["ufun"];
	arma::uvec uind      = ft_index["ufun"];
	uind                 = min(uind, uind - 1);
	arma::mat upar       = pmat.cols(uind);
	arma::uword upar_num = upar.n_cols;
	double* upar_mem     = upar.memptr();

	// The Utility of each option
	arma::mat Utility = calc_utility(pmat, inst, ftypes, ft_index, profile);
	// Pointer for utility
	double *U_mem = Utility.memptr();

	arma::uword nslice = Utility.n_cols;
	arma::uword nrow   = Utility.n_rows;

	iutility(ufun, upar_mem, upar_num, U_mem, nrow, nslice);

	return(Utility);
}


//' Generic Likelihood calculation
//'
//' @param pmat the parameter vector
//' @param inst the data.frame insrument as a list of its components
//' @param ftypes the ftypes list
//' @param ft_index the ft_index list for the parameters
//' @param profile the reginst profile for the instrument as defined by rcest
//' @export calc_likelihood
// [[Rcpp::export]]
arma::mat calc_likelihood(arma::mat pmat, DataFrame inst, List ftypes, List ft_index, List profile) {
	// Get the list for this profile value
	List val_prof = profile["outcomes"];
	// The number of options
	arma::uword nopt = val_prof.length();
	// The number of rows for each option is the number of rows in the inst
	arma::uword nrow = inst.nrows();
	// The Utility of each option
	arma::mat Utility = calc_utility(pmat, inst, ftypes, ft_index, profile);
	// Pointer for utility
	double *U_mem = Utility.memptr();
	// The likelihood of each option
	arma::mat likemat(nrow, nopt);
	// Get the function types
	std::string dfun = ftypes["dfun"];
	// Pointer for likelihood
	double *likemat_mem = likemat.memptr();
	// Generate the likelihoods
	likelihood(dfun, likemat_mem, U_mem, nrow, nopt);

	return(likemat);
}

//' Return a likelihood vector for choices
//'
//' @param pmat the parameter vector
//' @param inst the data.frame insrument as a list of its components
//' @param ftypes the ftypes list
//' @param ft_index the ft_index list for the parameters
//' @param profile the reginst profile for the instrument as defined by rcest
//' @export mlgeneral
// [[Rcpp::export]]
arma::vec mlgeneral(arma::mat pmat, DataFrame inst, List ftypes, List ft_index, List profile) {
	// Get the likelihoods for the options
	arma::mat likelihoods = calc_likelihood(pmat, inst, ftypes, ft_index, profile);
	// Grab the choice index from the profile
	arma::uword choice_i = profile["choice"];
	// Adjust from 1 base vectors to 0 base
	choice_i -= 1;
	// Grab the choice vector
	arma::uvec choice = inst[choice_i];
	// Generate the final likelihood vector
	arma::vec like(likelihoods.n_rows);
	// Select the likelihood corresponding to the choice
	for (arma::uword r = 0; r < likelihoods.n_rows ; r++) {
		like(r) = likelihoods(r, choice(r));
	}
	return(log(like));
}
