// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;

// Functions actually in the main file
arma::mat calc_utility(arma::mat pmat, DataFrame inst, List profile, List ftypes, List ft_index);
arma::mat calc_ce(arma::mat pmat, DataFrame inst, List ftypes, List ft_index, List profile);
arma::vec gslikelihood(std::string sfun, arma::vec Utilities);

// Helper functions
arma::mat  vpow(const arma::vec base, const arma::vec exp);
arma::cube inst_cube(DataFrame inst, List profile, std::string prof_val);

// Utility Functions
void utility     (std::string ufun, double* par_mem, arma::uword par_num, double* outs_mem, double* Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_ev      (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_nonpar  (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_crra    (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_pow     (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_cara    (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void ufx_expow   (double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);

// Inverse-Utility Functions
void iutility  (std::string ufun, double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice);
void iufx_ev   (double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice);
void iufx_crra (double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice);

// Get the utilities of arbitrary outcomes
arma::vec gsutility(arma::vec outcomes, arma::vec pars, std::string ufun);

// Probability Weighting Functions
void pweight   (std::string pfun, double* par_mem, arma::uword par_num, double* probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void pw_eut    (double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void pw_pow    (double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void pw_invs   (double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void pw_prelec (double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
// Get the decision weights of arbitrary probabilities
arma::vec gspweight(arma::vec pars, std::string pfun, arma::vec probabilities);

// Discount Factor Functions
void discount (std::string tfun, double* par_mem, arma::uword par_num, double* times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void df_none  (double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void df_exp   (double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void df_qhyp  (double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void df_hyp   (double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
void df_wb    (double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice);
// Get the discount factors of arbitrary time frames
arma::vec gsdiscount(arma::vec pars, std::string tfun, arma::vec times);

// Stochastic error functions
void stochastic    (std::string sfun, double* par_mem, arma::uword par_num, double* U_mem, double* Max_Min_mem, arma::uword nrow, arma::uword nslice);
void stoch_none    (double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice);
void stoch_context (double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice);
void stoch_strong  (double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice);
// Get the Utilities of options, adjusted for stochastic function stuff
arma::vec gsstochastic(arma::vec pars, std::string sfun, arma::vec Utilities, arma::vec max_min);

// Distribution functions for likelihoods
void likelihood (std::string dfun, double* likemat_mem, double* U_mem, arma::uword nrow, arma::uword ncol);
void like_logit (double* likemat_mem, double* U_mem, arma::uword nrow, arma::uword ncol);
