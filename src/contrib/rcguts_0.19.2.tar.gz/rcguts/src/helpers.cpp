// [[Rcpp::interfaces(r, cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;


//' Vector Power
//'
//' Power calculation with element by element vectors
//' @param base the base of the exponent
//' @param exp the exponent
//' @export vpow
// [[Rcpp::export]]
arma::mat vpow(const arma::vec base, const arma::vec exp) {
	arma::vec out(base.size());
	std::transform(base.begin(), base.end(),
				   exp.begin(), out.begin(), ::pow);
  return out;
}

arma::cube inst_cube(DataFrame inst, List profile, std::string prof_val) {
	// Get the list for this profile value
	List val_prof = profile[prof_val];
	// The number of options
	arma::uword nopt = val_prof.length();
	// First outcome to determine dimensions for cube
	arma::vec prof_element = val_prof[0];
	// The number of columns for each option is the number of elements in this profile
	arma::uword ncol = prof_element.n_elem;
	// The number of rows for each option is the number of rows in the inst
	arma::uword nrow = inst.nrows();

	// Cube for this prof_val
	arma::cube out_cube(nrow, ncol, nopt);
	// Matrix for each slice
	arma::mat  out_mat(nrow, ncol);

	for (arma::uword s = 0 ; s < nopt ; s++) {
		// R indexes from 1, C++ from 0, so subtract 1 from the profile index
		prof_element = Rcpp::as<arma::colvec>(val_prof[s]) - 1;
		// Loop through the prof_element and add the corresponding column from
		// inst to the matrix for this option's value
		for (arma::uword i = 0; i < ncol; i ++) {
			out_mat.col(i) = Rcpp::as<arma::colvec>(inst[prof_element[i]]);
		}
		// Add in the matrix to this slice
		out_cube.slice(s) = out_mat;
	}
	return(out_cube);
}
