// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

void stochastic(std::string sfun, double* par_mem, arma::uword par_num, double* U_mem, double* Max_Min_mem, arma::uword nrow, arma::uword nslice) {
	std::map<std::string,
		std::function<void(double*, arma::uword, double*, double*, arma::uword, arma::uword)>>
		stochastic_handler = {
			{"none",       stoch_none},
			{"strong",     stoch_strong},
			{"contextual", stoch_context}
		};
	stochastic_handler[sfun](par_mem, par_num, U_mem, Max_Min_mem, nrow, nslice);
}

void stoch_none(double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice) {
	// Don't actually do anything
}

void stoch_context(double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice) {
	//Rcout << "In S Contextual" << std::endl;
	// Transform the parameters
	arma::mat par(par_mem, nrow, par_num, false);

	arma::mat Utility(U_mem, nrow, nslice, false);
	arma::mat Max_Min(Max_Min_mem, nrow, 2, false);
	// Adjust utility of each option to be relative to the maximum
	// utility in the set of alternatives. This will help with numerical
	// overflow problems.
	arma::vec max_utils(nrow);
	for	(arma::uword r = 0; r < nrow ; r++ ) {
		max_utils[r] = max(Utility.row(r));
	}
	Utility.each_col() -= max_utils;

	arma::vec mu = par.col(0);

	for (arma::uword s = 0; s < nslice; s++){
		Utility.col(s) = Utility.col(s) / (Max_Min.col(0) - Max_Min.col(1)) / mu;
	}
}

void stoch_strong(double* par_mem, arma::uword par_num, double *U_mem, double *Max_Min_mem, arma::uword nrow, arma::uword nslice) {
	//Rcout << "In S Contextual" << std::endl;
	// Transform the parameters
	arma::mat par(par_mem, nrow, par_num, false);
	arma::mat Utility(U_mem, nrow, nslice, false);
	
	// Adjust utility of each option to be relative to the maximum
	// utility in the set of alternatives. This will help with numerical
	// overflow problems.
	arma::vec max_utils(nrow);
	for	(arma::uword r = 0; r < nrow ; r++ ) {
		max_utils[r] = max(Utility.row(r));
	}
	Utility.each_col() -= max_utils;

	arma::vec mu = par.col(0);

	for (arma::uword s = 0; s < nslice; s++){
		Utility.col(s) = Utility.col(s) / mu;
	}

}
