// [[Rcpp::interfaces(r, cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

// [[Rcpp::export]]
arma::vec gslikelihood(std::string dfun, arma::vec Utilities) {

	arma::uword nrow = 1;
	arma::uword ncol = Utilities.n_elem;

	arma::mat U_mat(nrow, ncol);
	U_mat.row(0) = Utilities.t();
	double* U_mem = U_mat.memptr();

	arma::mat likemat(nrow, ncol);
	likemat.row(0) = Utilities.t();
	double* likemat_mem = likemat.memptr();

	likelihood(dfun, likemat_mem, U_mem, nrow, ncol);

	Utilities = likemat.row(0).t();

	return(Utilities);
}

void likelihood(std::string dfun, double* likemat_mem, double* U_mem, arma::uword nrow, arma::uword ncol) {
	std::map<std::string,
		std::function<void(double*, double*, arma::uword, arma::uword)>>
		likelihood_handler = {
			{"logit",  like_logit}
		};
	likelihood_handler[dfun](likemat_mem, U_mem, nrow, ncol);
}

void like_logit(double* likemat_mem, double* U_mem, arma::uword nrow, arma::uword ncol) {
	arma::mat likemat(likemat_mem, nrow, ncol, false);
	arma::mat Utility(U_mem, nrow, ncol, false);
	// Exponentiate the utilities
	likemat = exp(Utility);
	// Get Demoninator of the logit
	arma::vec denominator(nrow);

	// For large denominators, it's going to matter that we have the best
	// precision possible. C++ doesn't implement unsigned doubles, which we
	// could have used given likelihoods will be positive, so we'll sort
	// the likelihood matrix for the denominator before summing. See, for
	// instance, Gould (2006) for explainations why this helps.

	if (likemat.n_cols > 2) {
		denominator = sum(arma::sort(likemat, "ascend", 1), 1);
	}
	else {
		denominator = sum(likemat, 1);
	}
	for (arma::uword s = 0 ; s < ncol ; s++) {
		likemat.col(s) = likemat.col(s) / denominator;
	}
}
