// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

void iutility(std::string ufun, double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice) {
	std::map<std::string,
		std::function<void(double*, arma::uword, double*, arma::uword, arma::uword)>>
		utility_handler = {
			{"ev",     iufx_ev},
			{"crra",   iufx_crra}
		};
	utility_handler[ufun](par_mem, par_num, U_mem, nrow, nslice);
}

void iufx_ev(double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice) {
	// Expected Value, doesn't transform any outcomes
}

void iufx_crra(double* par_mem, arma::uword par_num, double* U_mem, arma::uword nrow, arma::uword nslice) {
	//Rcout <<"In u crra" << std::endl;
	// x^(1-r) / (1-r)

	arma::mat par(par_mem, nrow, par_num, false);
	arma::mat Utility(U_mem, nrow, nslice, false);

	arma::uword rn = 0;
	arma::vec r =  1 - par.col(0);

	for (arma::uword s = 0 ; s < nslice ; s++) {
		Utility.col(s) = vpow(Utility.col(s) % r, 1 / r);
	}
}
