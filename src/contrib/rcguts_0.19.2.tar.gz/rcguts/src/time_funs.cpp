// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

void discount(std::string tfun, double* par_mem, arma::uword par_num, double* times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {

	std::map<std::string,
		std::function<void(double*, arma::uword, double*, arma::uword, arma::uword, arma::uword)>>
		discount_handler = {
			{"none", df_none},
			{"exp",  df_exp},
			{"qhyp", df_qhyp},
			{"hyp",  df_hyp},
			{"wb",   df_wb}
		};

	discount_handler[tfun](par_mem, par_num, times_mem, nrow, ncol, nslice);
}

void df_none(double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	// This function gives a discount factor of 1 for everything
	// Since the times matrix is initialized with a fill::ones, this function does nothing
}

void df_exp(double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In df exp" << std::endl;
	// 1 / (1 + delta)^time
	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube times(times_mem, nrow, ncol, nslice, false);
	// delta = 1 + delta
	arma::vec delta = par.col(0) + 1;
	for (arma::uword s = 0 ; s < nslice ; s++) {
		for (arma::uword c = 0 ; c < ncol ; c++) {
			// (1 + delta)^time
			std::transform(delta.begin(),                 // Argument 1 begin
					       delta.end(),                   // Argument 1 end
						   times.slice(s).col(c).begin(), // Argument 2 begin
						   times.slice(s).col(c).begin(), // output begin
						   ::pow);                        // function
			// 1 / (1 + deltta)^time
			times.slice(s).col(c) = 1 / times.slice(s).col(c);
		}
	}
}

void df_qhyp(double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In df qhyp" << std::endl;
	// numerator / (1 + delta)^time
	// where
	// numerator == 1    if time == 0
	// numerator == beta if time > 0
	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube times(times_mem, nrow, ncol, nslice, false);
	// delta = 1 + delta
	arma::vec delta = par.col(0) + 1;
	arma::vec beta  = par.col(1);
	// The numerator is 1 if t == 0, beta otherwise
	arma::vec numerator  = beta;

	for (arma::uword s = 0 ; s < nslice ; s++) {
		for (arma::uword c = 0 ; c < ncol ; c++) {

			// Reset the numerator to be beta
			numerator = beta;
			// Replace the beta values with 1 for times equal to 0
			numerator.elem(find(times.slice(s).col(c) == 0)).ones();
			// (1 + delta)^time
			std::transform(delta.begin(),                 // Argument 1 begin
					       delta.end(),                   // Argument 1 end
						   times.slice(s).col(c).begin(), // Argument 2 begin
						   times.slice(s).col(c).begin(), // output begin
						   ::pow);                        // function
			// numerator / (1 + delta)^time
			times.slice(s).col(c) = numerator / times.slice(s).col(c);
		}
	}
}

void df_hyp(double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In df hyp" << std::endl;
	// 1 / (1 + delta*time)
	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube times(times_mem, nrow, ncol, nslice, false);
	// delta = 1 + delta
	arma::vec delta = par.col(0);
	for (arma::uword s = 0 ; s < nslice ; s++) {
		for (arma::uword c = 0 ; c < ncol ; c++) {
			// 1 / (1 + delta*time)
			times.slice(s).col(c) = 1 / (1 + delta % times.slice(s).col(c));
		}
	}
}

void df_wb(double* par_mem, arma::uword par_num, double *times_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In df qhyp" << std::endl;
	// exp(-delta * t^(1/beta))
	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube times(times_mem, nrow, ncol, nslice, false);

	// beta = 1 / beta
	arma::vec beta  = 1 / par.col(0);
	// delta = -delta
	arma::vec delta = -1 * par.col(1);

	for (arma::uword s = 0 ; s < nslice ; s++) {
		for (arma::uword c = 0 ; c < ncol ; c++) {

			// time^(1/beta)
			std::transform(times.slice(s).col(c).begin(), // Argument 1 begin
					       times.slice(s).col(c).end(),   // Argument 1 end
						   beta.begin(),                  // Argument 2 begin
						   times.slice(s).col(c).begin(), // output begin
						   ::pow);                        // function
			// exp(-delta * t^(1/beta))
			times.slice(s).col(c) = exp(delta % times.slice(s).col(c));
		}
	}
}
