// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

void utility(std::string ufun, double* par_mem, arma::uword par_num, double* outs_mem, double* Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	std::map<std::string,
		std::function<void(double*, arma::uword, double*, double*, arma::uword, arma::uword, arma::uword)>>
		utility_handler = {
			{"ev",     ufx_ev},
			{"nonpar", ufx_nonpar},
			{"crra",   ufx_crra},
			{"pow",    ufx_pow},
			{"cara",   ufx_cara},
			{"expow",  ufx_expow}
		};
	utility_handler[ufun](par_mem, par_num, outs_mem, Max_Min_mem, nrow, ncol, nslice);
}

void ufx_ev(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	// Expected Value, doesn't transform any outcomes
}

void ufx_nonpar(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout << "In u nonpar" << std::endl;

	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube outcomes(outs_mem, nrow, ncol, nslice, false);
	arma::mat  Max_Min(Max_Min_mem, nrow, 2, false);

	// Support 256 unqiue outcome values. May change later if need arises.
	arma::colvec unique_outs = arma::zeros<arma::vec>(256);

	int num_unique = 0;
	arma::vec tmp_unique;

	// Get the unique values across all options
	for (arma::uword s = 0 ; s < nslice ; s++) {
		tmp_unique = arma::unique(outcomes.slice(s));
		unique_outs.subvec(num_unique, tmp_unique.n_elem + num_unique - 1) = tmp_unique;
		num_unique += tmp_unique.n_elem;
	}
	unique_outs = arma::unique(unique_outs.subvec(0, num_unique - 1));

	// Make a temporary matrix for outcomes
	arma::mat  mat_temp(nrow, ncol);
	arma::uvec par_ind(nrow);

	// Need to hold some indicies as vectors
	arma::uvec cvec(1);
	arma::uvec pvec(1);

	for (arma::uword s = 0 ; s < nslice ; s++) {
		mat_temp = outcomes.slice(s);
		// Go through each unique_out / par
		for (arma::uword p = 0 ; p < (par_num + 2); p++ ) {
			for (arma::uword c = 0 ; c < ncol ; c++) {
				par_ind = arma::find(outcomes.slice(s).col(c) == unique_outs[p]);
				cvec.fill(c);
				pvec.fill(p - 1);
				if (p == 0) {
					mat_temp.submat(par_ind, cvec).zeros();
				} else if (p == (par_num + 1)) {
					mat_temp.submat(par_ind, cvec).ones();
				} else {
					mat_temp.submat(par_ind, cvec) = par.submat(par_ind, pvec);
				}
			}
		} 
		outcomes.slice(s) = mat_temp;
	}

	// Now do the same for the Max_Min matrix
	mat_temp = Max_Min;
	// Go through each unique_out / par
	for (arma::uword p = 0 ; p < (par_num + 2); p++ ) {
		for (arma::uword c = 0 ; c < Max_Min.n_cols ; c++) {
			par_ind = arma::find(Max_Min.col(c) == unique_outs[p]);
			cvec.fill(c);
			pvec.fill(p - 1);
			if (p == 0) {
				mat_temp.submat(par_ind, cvec).zeros();
			} else if (p == (par_num + 1)) {
				mat_temp.submat(par_ind, cvec).ones();
			} else {
				mat_temp.submat(par_ind, cvec) = par.submat(par_ind, pvec);
			}
		}
	} 
	Max_Min = mat_temp;

}

void ufx_crra(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In u crra" << std::endl;
	// x^(1-r) / (1-r)

	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube outcomes(outs_mem, nrow, ncol, nslice, false);
	arma::mat  Max_Min(Max_Min_mem, nrow, 2, false);

	arma::uword rn = 0;
	arma::mat::col_iterator r = par.begin_col(0);

	while (r != par.end_col(0)) {
		for (arma::uword s = 0 ; s < nslice ; s++) {
			if (*r == 1) {
				outcomes.slice(s).row(rn) = log(outcomes.slice(s).row(rn));
			}
			else {
				outcomes.slice(s).row(rn) = pow(outcomes.slice(s).row(rn), (1-*r)) / (1-*r);
			}
		}
		if (*r == 1) {
			Max_Min.row(rn) = log(Max_Min.row(rn));
		}
		else {
			Max_Min.row(rn) = pow(Max_Min.row(rn), (1-*r)) / (1-*r);
		}
		r++;
		rn++;
	}
}

void ufx_pow(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In u crra" << std::endl;
	// x^r

	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube outcomes(outs_mem, nrow, ncol, nslice, false);
	arma::mat  Max_Min(Max_Min_mem, nrow, 2, false);

	arma::uword rn = 0;
	arma::mat::col_iterator r = par.begin_col(0);

	while (r != par.end_col(0)) {
		for (arma::uword s = 0 ; s < nslice ; s++) {
			if (*r == 0) {
				outcomes.slice(s).row(rn) = log(outcomes.slice(s).row(rn));
			}
			else if (*r < 0) {
				outcomes.slice(s).row(rn) = -pow(outcomes.slice(s).row(rn), *r);
			}
			else {
				outcomes.slice(s).row(rn) = pow(outcomes.slice(s).row(rn), *r);
			}
		}
		if (*r == 0) {
			Max_Min.row(rn) = log(Max_Min.row(rn));
		}
		else if (*r < 0) {
			Max_Min.row(rn) = -pow(Max_Min.row(rn), *r);
		}
		else {
			Max_Min.row(rn) = pow(Max_Min.row(rn), *r);
		}
		r++;
		rn++;
	}

}

void ufx_cara(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In u crra" << std::endl;
	// x^(1-r) / (1-r)

	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube outcomes(outs_mem, nrow, ncol, nslice, false);
	arma::mat  Max_Min(Max_Min_mem, nrow, 2, false);

	arma::uword rn = 0;
	arma::mat::col_iterator r = par.begin_col(0);

	while (r != par.end_col(0)) {
		for (arma::uword s = 0 ; s < nslice ; s++) {
			outcomes.slice(s).row(rn) = exp(outcomes.slice(s).row(rn) * -*r);
		}
		Max_Min.row(rn) = exp(Max_Min.row(rn) * -*r);
		r++;
		rn++;
	}
}

void ufx_expow(double* par_mem, arma::uword par_num, double *outs_mem, double *Max_Min_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout <<"In u crra" << std::endl;
	// x^(1-r) / (1-r)

	arma::mat  par(par_mem, nrow, par_num, false);
	arma::cube outcomes(outs_mem, nrow, ncol, nslice, false);
	arma::mat  Max_Min(Max_Min_mem, nrow, 2, false);

	arma::uword rn = 0;
	arma::mat::col_iterator r = par.begin_col(0);
	arma::mat::col_iterator a = par.begin_col(1);

	while (r != par.end_col(0)) {
		for (arma::uword s = 0 ; s < nslice ; s++) {
			outcomes.slice(s).row(rn) = (1 - exp(-*a * pow(outcomes.slice(s).row(rn), (1-*r)))) / *a;
		}
		Max_Min.row(rn) = (1 - exp(-*a * pow(Max_Min.row(rn), (1-*r)))) / *a;

		a++;
		r++;
		rn++;
	}
}
