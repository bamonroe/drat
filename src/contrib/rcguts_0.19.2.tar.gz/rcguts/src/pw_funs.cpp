// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

void pweight(std::string pfun, double* par_mem, arma::uword par_num, double* probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	std::map<std::string,
		std::function<void(double*, arma::uword, double*, arma::uword, arma::uword, arma::uword)>>
		pweight_handler = {
			{"eut", pw_eut},
			{"pow", pw_pow},
			{"inv", pw_invs},
			{"pre", pw_prelec}
		};
	pweight_handler[pfun](par_mem, par_num, probs_mem, nrow, ncol, nslice);
}

void pw_eut(double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	// This function doesn't actually do anything
	// Rcout << "In P eut" << std::endl;
}

void pw_pow(double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	//Rcout << "In P pow" << std::endl;

	arma::mat par(par_mem, nrow, par_num, false);
	// Reconstruct the probs cube
	arma::cube probs(probs_mem, nrow, ncol, nslice, false, true);
	// Matricies for decumulating
	arma::mat prob0(nrow, ncol);
	arma::mat prob1(nrow, ncol);

	// Iterator of the parameter
	arma::mat::col_iterator phi = par.begin_col(0);

	// Each slice is a different option
	for (arma::uword s = 0; s < nslice ; s++) {
		// Use the temporary matricies, they're easier to read...
		prob0 = probs.slice(s);
		// Get the cummulative probabilities
		prob0 = arma::cumsum(prob0, 1);
		// Make a matrix that doesn't have the the lowest probabiliy choice
		prob1 = prob0.cols(0, prob0.n_cols - 2);
		prob1.insert_cols(0, 1);

		// Apply the power function
		arma::uword rn = 0;
		while (phi != par.end_col(0)) {
			prob0.row(rn) = pow(prob0.row(rn), *phi);
			prob1.row(rn) = pow(prob1.row(rn), *phi);
			phi++; rn++;
		}
		phi = par.begin_col(0);
		// De-cumulate

		probs.slice(s) = prob0 - prob1;
	}
}

void pw_invs(double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	// Rcout << "In P pow" << std::endl;
	arma::mat par(par_mem, nrow, par_num, false);
	// Reconstruct the probs cube
	arma::cube probs(probs_mem, nrow, ncol, nslice, false);
	// Matricies for decumulating
	arma::mat prob0(nrow, ncol);
	arma::mat prob1(nrow, ncol);

	// Iterator of the parameter
	arma::mat::col_iterator phi = par.begin_col(0);

	// Each slice is a different option
	for (arma::uword s = 0; s < nslice ; s++) {
		// Use the temporary matricies, they're easier to read...
		prob0 = probs.slice(s);
		// Get the cummulative probabilities
		prob0 = arma::cumsum(prob0, 1);
		// Make a matrix that doesn't have the the lowest probabiliy choice
		prob1 = prob0.cols(0, prob0.n_cols - 2);
		prob1.insert_cols(0,1);
		// Apply the Inverse-S function
		// Row number counter
		arma::uword rn = 0;
		while (phi != par.end_col(0)) {
			prob0.row(rn)  = pow(prob0.row(rn), *phi) / (pow((pow(prob0.row(rn), *phi) + pow((1 - prob0.row(rn)), *phi)), 1 / *phi));
			prob1.row(rn)  = pow(prob1.row(rn), *phi) / (pow((pow(prob1.row(rn), *phi) + pow((1 - prob1.row(rn)), *phi)), 1 / *phi));
			phi++; rn++;
		}
		phi = par.begin_col(0);

		// Get rid of crazy values
		prob0.elem(find_nonfinite(prob0)).ones();
		prob1.elem(find_nonfinite(prob1)).ones();
		// De-cumulate
		probs.slice(s) = prob0 - prob1;
		// Get rid of crazy values again
		probs.slice(s).elem(find_nonfinite(probs.slice(s))).zeros();
	}
}

void pw_prelec(double* par_mem, arma::uword par_num, double *probs_mem, arma::uword nrow, arma::uword ncol, arma::uword nslice) {
	// Rcout << "In P pow" << std::endl;
	arma::mat par(par_mem, nrow, par_num, false);
	// Reconstruct the probs cube
	arma::cube probs(probs_mem, nrow, ncol, nslice, false);
	// Matricies for decumulating
	arma::mat prob0(nrow, ncol);
	arma::mat prob1(nrow, ncol);


	arma::mat::col_iterator phi = par.begin_col(0);
	arma::mat::col_iterator eta = par.begin_col(1);
	// Each slice is a different option
	for (arma::uword s = 0; s < nslice ; s++) {
		// Use the temporary matricies, they're easier to read...
		prob0 = probs.slice(s);
		// Get the cummulative probabilities
		prob0 = arma::cumsum(prob0, 1);
		// Make a matrix that doesn't have the the lowest probabiliy choice
		prob1 = prob0.cols(0, prob0.n_cols - 2);
		prob1.insert_cols(0,1);
		// Apply the Inverse-S function
		// Iterator of the parameter
		// Row number counter
		arma::uword rn = 0;
		while (phi != par.end_col(0)) {
			prob0.row(rn)  = exp(-*eta * (pow(-log(prob0.row(rn)),  *phi)));
			prob1.row(rn)  = exp(-*eta * (pow(-log(prob1.row(rn)),  *phi)));
			phi++; eta++; rn++;
		}

		phi = par.begin_col(0);
		eta  = par.begin_col(1);

		// Get rid of crazy values
		prob0.elem(find_nonfinite(prob0)).ones();
		prob1.elem(find_nonfinite(prob1)).ones();
		// De-cumulate
		probs.slice(s) = prob0 - prob1;
		// Get rid of crazy values again
		probs.slice(s).elem(find_nonfinite(probs.slice(s))).zeros();
	}
}
