// [[Rcpp::interfaces(r, cpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include "main.hpp"
using namespace Rcpp;

// [[Rcpp::export]]
arma::vec gsutility(arma::vec pars, std::string ufun, arma::vec outcomes) {

	int nrow = 1;
	int ncol = outcomes.n_elem;
	int nslice = 1;

	arma::cube outs(nrow, ncol, nslice);
	outs.slice(0).row(0) = outcomes.t();
	double* outs_mem = outs.memptr();

	int par_num = pars.n_elem;
	arma::mat pmat(nrow, par_num);
	pmat.row(0) = pars.t();
	double* par_mem = pmat.memptr();

	arma::mat::fixed<1, 2> Max_Min(arma::fill::eye);
	double* Max_Min_mem = Max_Min.memptr();

	utility(ufun, par_mem, par_num, outs_mem, Max_Min_mem, nrow, ncol, nslice);

	outcomes = outs.slice(0).row(0).t();

	return(outcomes);
}

// [[Rcpp::export]]
arma::vec gsdiscount(arma::vec pars, std::string tfun, arma::vec times) {

	int nrow = 1;
	int ncol = times.n_elem;
	int nslice = 1;

	arma::cube dfactor(nrow, ncol, nslice);
	dfactor.slice(0).row(0) = times.t();
	double* times_mem = dfactor.memptr();

	int par_num = pars.n_elem;
	arma::mat pmat(nrow, par_num);
	pmat.row(0) = pars.t();
	double* par_mem = pmat.memptr();

	discount(tfun, par_mem, par_num, times_mem, nrow, ncol, nslice);

	times = dfactor.slice(0).row(0).t();

	return(times);
}

// [[Rcpp::export]]
arma::vec gsstochastic(arma::vec pars, std::string sfun, arma::vec Utilities, arma::vec max_min) {

	int nrow = 1;
	int ncol = Utilities.n_elem;

	arma::mat utils(nrow, ncol);
	utils.row(0) = Utilities.t();
	double* U_mem = utils.memptr();

	int par_num = pars.n_elem;
	arma::mat pmat(nrow, par_num);
	pmat.row(0) = pars.t();
	double* par_mem = pmat.memptr();

	arma::mat::fixed<1, 2> Max_Min;
	Max_Min.row(0) = max_min.t();
	double* Max_Min_mem = Max_Min.memptr();

	stochastic(sfun, par_mem, par_num, U_mem, Max_Min_mem, nrow, ncol);

	Utilities = utils.row(0).t();

	return(Utilities);
}

// [[Rcpp::export]]
arma::vec gspweight(arma::vec pars, std::string pfun, arma::vec probabilities) {

	int nrow = 1;
	int ncol = probabilities.n_elem;
	int nslice = 1;

	arma::cube probs(nrow, ncol, nslice);
	probs.slice(0).row(0) = probabilities.t();
	double* probs_mem = probs.memptr();

	int par_num = pars.n_elem;
	arma::mat pmat(nrow, par_num);
	pmat.row(0) = pars.t();
	double* par_mem = pmat.memptr();

	pweight(pfun, par_mem, par_num, probs_mem, nrow, ncol, nslice);

	probabilities = probs.slice(0).row(0).t();

	return(probabilities);
}
