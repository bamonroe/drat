#' @title Utility Calculation
#'
#' @param outcomes the outcomes the utility function is applied to
#' @param pars the parameters to the utility function
#' @param ufun the utility function to use
#' @export sutility
sutility <- function(outcomes, pars, ufun = "crra") {
  rnum <- nrow(outcomes)
  cnum <- ncol(outcomes)
  if (! is.null(rnum)) {
    outcomes <- matrix(outcomes, nrow = 1)
  }
  utilities <- gsutility(pars, ufun, outcomes)
  if (! is.null(rnum)) {
    utilities <- matrix(utilities, nrow = rnum, ncol = cnum)
  } else {
    utilities <- c(utilities)
  }
  return(utilities)
}

#' @title Probability Weight Calculation
#'
#' @description Assumes that the probabilities are already ranked by outcome
#' from best to worst
#'
#' @param probabilities the probabilities the utility function is applied to
#' @param pars the parameters to the probability weighting function
#' @param pfun the probability weighting function to use
#' @export spweight
spweight <- function(probabilities, pars, pfun = "eut") {
  rnum <- nrow(probabilities)
  cnum <- ncol(probabilities)
  if (! is.null(rnum)) {
    probabilities <- matrix(probabilities, nrow = 1)
  }
  if (probabilities[1] == 1) return(probabilities)
  pweights <- gspweight(pars, pfun, probabilities)
  if (! is.null(rnum)) {
    pweights <- matrix(pweights, nrow = rnum, ncol = cnum)
  } else {
    pweights <- c(pweights)
  }
  return(pweights)
}

#' @title Stochastic Function Calculation
#'
#' @param utilities the utilities the stochastic function is applied to
#' @param max_min the utilities of the maximum and minimum outcomes, in that order
#' @param pars the parameters to the stochastic function
#' @param sfun the stochastic function to use
#' @export sstoch
sstoch <- function(utilities, max_min, pars, sfun = "contextual") {
  rnum <- nrow(utilities)
  cnum <- ncol(utilities)

  if (! is.null(rnum)) {
    utilities <- matrix(unlist(utilities))
  } else {
    utilities <- unlist(utilities)
  }

  sutils <- gsstochastic(pars, sfun, utilities, max_min)
  if (! is.null(rnum)) {
    sutils <- matrix(sutils, nrow = rnum, ncol = cnum)
  } else {
    sutils <- c(sutils)
  }
  return(sutils)
}

#' @title Likelihood Calculation
#'
#' @param utilities the utilities the stochastic function is applied to
#' @param dfun the stochastic function to use
#' @export slike
slike <- function(utilities, sfun = "logit") {
  rnum <- nrow(utilities)
  cnum <- ncol(utilities)
  if (! is.null(rnum)) {
    utilities <- matrix(unlist(utilities))
  }
  slike <- gslikelihood(sfun, utilities)
  if (! is.null(rnum)) {
    slike <- matrix(slike, nrow = rnum, ncol = cnum)
  } else {
    slike <- c(slike)
  }
  return(slike)
}
