#' @useDynLib rcguts
#' @importFrom Rcpp sourceCpp

.onLoad <- function(libname, pkgname) {
  if ("rcest" %in% loadedNamespaces()) {
    # Set the parsers if we're using rcest
    set_uparsers()
  }
}
