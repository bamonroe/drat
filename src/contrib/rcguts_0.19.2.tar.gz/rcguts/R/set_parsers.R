#' @title Set rcest Parsers for Utility Functions
#'
#' @export set_uparsers
set_uparsers <- function() {
  ## Set ufun parsers
  rcest::set_parser(ftype      = "ufun",
                    fname      = c("ev", "linear"),
                    transforms = vector(mode = "character",   length = 0),
                    def_pars   = vector(mode = "numeric",   length = 0),
                    par_names  = vector(mode = "character", length = 0),
                    description = "Expected value"
                    )

  rcest::set_parser(ftype       = "ufun",
                    fname       = c("crra", "CRRA"),
                    transforms  = "none",
                    def_pars    = 0,
                    par_names   = "r",
                    description = "Constant relative risk aversion x^(1-r)/(1-r)"
                    )

  rcest::set_parser(ftype      = "ufun",
                    fname      = c("pow", "power"),
                    transforms = "none",
                    def_pars   = 1,
                    par_names  = "r",
                    description = "Constant relative risk aversion x^r"
                    )

  rcest::set_parser(ftype      = "ufun",
                    fname      = c("cara", "CARA"),
                    transforms = "none",
                    def_pars   = 1,
                    par_names  = "r",
                    description = "Absolute relative risk aversion exp(-rx)"
                    )

  rcest::set_parser(ftype      = "ufun",
                    fname      = c("expow", "expo-power"),
                    transforms = c("none", "exp"),
                    def_pars   = c(.5, .5),
                    par_names  = c("r", "a"),
                    description = "Expo-Power"
                    )

  ## Set pfun parsers
  rcest::set_parser(ftype      = "pfun",
                    fname      = c("eut", "linear", "none"),
                    transforms = vector(mode = "character", length = 0),
                    def_pars   = vector(mode = "numeric", length = 0),
                    par_names  = vector(mode = "character", length = 0),
                    description = "No prbability weighting"
                    )

  rcest::set_parser(ftype      = "pfun",
                    fname      = c("pow", "power"),
                    transforms = c("exp"),
                    def_pars   = 1,
                    par_names  = "phi",
                    description = "Power PWF, x^phi"
                    )

  rcest::set_parser(ftype      = "pfun",
                    fname      = c("inv", "invs", "inverse-s"),
                    transforms = c("exp"),
                    def_pars   = 1,
                    par_names  = "phi",
                    description = "Inverse-S"
                    )

  rcest::set_parser(ftype       = "pfun",
                    fname       = c("pre", "prelec"),
                    transforms  = c("exp", "exp"),
                    def_pars    = c(1, 1),
                    par_names   = c("phi", "eta"),
                    description = "Prelec PWF"
                    )

  ## Stochastic function parser
  rcest::set_parser(ftype      = "sfun",
                    fname      = c("none", "None"),
                    transforms = vector(mode = "character", length = 0),
                    def_pars   = vector(mode = "numeric",   length = 0),
                    par_names  = vector(mode = "character", length = 0),
                    description = "Contextual Stochastic Model"
                    )

  rcest::set_parser(ftype      = "sfun",
                    fname      = c("contextual", "context", "ctx"),
                    transforms = c("exp"),
                    def_pars   = c(.3),
                    par_names  = c("mu"),
                    description = "Contextual Stochastic Model"
                    )

  rcest::set_parser(ftype      = "sfun",
                    fname      = c("strong", "su"),
                    transforms = c("exp"),
                    def_pars   = c(1),
                    par_names  = c("mu"),
                    description = "Strong Utility Model"
                    )

  ## Distribution functions
  rcest::set_parser(ftype      = "dfun",
                    fname      = c("logit", "logistic"),
                    transforms = vector(mode = "character", length = 0),
                    def_pars   = vector(mode = "numeric",   length = 0),
                    par_names  = vector(mode = "character", length = 0),
                    description = "Logistic CDF"
                   )

  rcest::set_parser(ftype      = "dfun",
                    fname      = c("normal"),
                    transforms = vector(mode = "character", length = 0),
                    def_pars   = vector(mode = "numeric",   length = 0),
                    par_names  = vector(mode = "character", length = 0),
                    description = "Normal CDF"
                   )

  ## Time functions
  rcest::set_parser(ftype      = "tfun",
            fname      = c("none", "None", "No"),
            transforms = vector(mode = "character", length = 0),
            def_pars   = vector(mode = "numeric",   length = 0),
            par_names  = vector(mode = "character", length = 0),
            description = "No discounting"
            )

  rcest::set_parser(ftype      = "tfun",
            fname      = c("exp", "exponential"),
            transforms = c("none"),
            def_pars   = 0,
            par_names  = "delta",
            description = "Expnential discounting"
            )

  rcest::set_parser(ftype      = "tfun",
            fname      = c("qhyp", "qh", "qhype", "quasi-hyp", "quasi-hyperbolic"),
            transforms = c("none", "exp"),
            def_pars   = c(0, 1),
            par_names  = c("delta", "beta"),
            description = "Quasi-Hyperbolic discounting"
            )

  rcest::set_parser(ftype      = "tfun",
            fname      = c("hyp", "h", "hype", "hyperbolic"),
            transforms = c("none"),
            def_pars   = c(0),
            par_names  = c("delta"),
            description = "Hyperbolic discounting"
            )

  rcest::set_parser(ftype      = "tfun",
            fname      = c("wb", "web", "wei", "weibul"),
            transforms = c("exp", "exp"),
            def_pars   = c(1, 1),
            par_names  = c("beta", "delta"),
            description = "Weibul discounting"
            )
}

#' @title Set nonpar Utility Function
#'
#' @description Set the non-parametric utillty function by finding the number
#' of unique outcomes in an instrument.
#'
#' @param inst the data.frame instrument used in estimation
#' @param layout the name of the profile layout, needed to get outcomes
#' @export set_nopar
set_nopar <- function(inst, layout) {

  profile <- rcest::profile_inst(inst, layout)

  out <- lapply(seq_along(profile$probabilities), function(i) {
    pprof <- profile$probabilities[[i]]
    oprof <- profile$outcomes[[i]]
    probs <- inst[, pprof]
    outs  <- inst[, oprof]

    val <- unique(unlist(outs[probs > 0]))
    val
  })
  out <- sort(unique(unlist(out)))
  if (length(out) < 3) {
    msg <- "You're trying to estimate a nonpar utility function with less than 3 outcomes."
    msg <- paste0(msg, " This isn't possible.")
    stop(msg)
  }
  npars <- length(out) - 2

  par_seq <- seq(from = 0, to = 1, length.out = npars + 2)[2:(npars + 1)]
  rcest::set_parser(ftype       = "ufun",
                    fname       = "nonpar",
                    transforms  = rep("logit", npars),
                    def_pars    = par_seq,
                    par_names   = paste0("u", seq_len(npars)),
                    description = "Non-parametric utility function")
  return(out)
}
