## R C(hoice) Guts

This package provides back-end functions risk and time preference estimation coded in C++.

The other 'back-end' functionality was stripped in favor of the all R package [rcest](https://git.bamonroe.com/rdev/rcest).

The `mlgeneral` function provides a drop-in likelihood function for the rcest command provided a profile is passed as an additional argument.
