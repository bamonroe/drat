void kernel mhmc (
  // first two args are mandatory
  global   rtype* prior_out,
  global   rtype* like_out,
  global   rtype* par,
  global   uint*  rng_state,
  constant rtype* jump,
  global   rtype* accept,
  // user args
	@@def_user_args@@
)
{
  // The id for this worker
  int gid  = get_global_id(0);
  // Initialize the rng state
  state s = {
    rng_state[gid]
  };

  // The parameter vector for this model
  rtype pars[NPAR], ppars[NPAR];
  for (int i = 0; i < NPAR; i++) {
    pars[i] = par[gid * NPAR + i];
  }

  // The jump vector for this model
  rtype jvec[NPAR];
  for (int i = 0; i < NPAR; i++) {
    jvec[i] = jump[gid * NPAR + i];
  }

  // Some algebra needs to happen to the proposed, so it happens here
  rtype final_proposed, final_current, resolve, ratio;

  // Keep track of the proposed and current prior and posterior
  rtype proposed[2];
  rtype current[2] = {
    prior_out[gid],
    like_out[gid],
  };

  // Ensure we're dealing with real numbers here
  current[0] = isnan(current[0]) ? -FLT_MAX : current[0];
  current[1] = isnan(current[1]) ? -FLT_MAX : current[1];

	rtype aavg = 0;

  for (int iter = 0; iter < MCMC_RUNS; iter++) {
    // Draw proposals from a random normal distribution
    for (int i = 0; i < NPAR; i++) {
      ppars[i] = rnorm(&s, pars[i], jvec[i]);
    }

		// Get the current value of the proportional log-posterior
		// first two args are mandatory:
		// - an array to store the values of the log-prior and log-likelihood
		// - the parameters for the model
		@@function_name@@ (
			proposed,
			ppars,
			@@fn_user_args@@
		);

		// Add the log-prior and log-likelihood
		final_proposed = proposed[0] + proposed[1];
    final_current  = current[0]  + current[1];

    // Take the difference
    ratio   = final_proposed - final_current;
    // Get the min BEFORE exponentiation to avoid overflow
    ratio   = min((rtype) 0.0, ratio);
    // Then exponentiate
    resolve = runif(&s);
    resolve = log(resolve);

      if (ratio > resolve) {
        current[0] = proposed[0];
        current[1] = proposed[1];
        for (int i = 0; i < NPAR; i++) {
          pars[i] = ppars[i];
        }
        aavg += 1.0 / MCMC_RUNS;
      }
	}

  // reset the state
  rng_state[gid] = s.x;

  // Record the latest parameters
  for (int i = 0; i < NPAR; i++) {
    par[gid * NPAR + i] = pars[i];
  }

  // Record the prior and likelihood separately
  prior_out[gid] = current[0];
  like_out[gid]  = current[1];
	// Record the average acceptance rate
  accept[gid]    = aavg;
}
