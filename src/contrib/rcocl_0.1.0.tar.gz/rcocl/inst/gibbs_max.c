#define EE 0.01
void kernel gibbs_max (
  // first two args are mandatory
  global   rtype* prior_out,
  global   rtype* like_out,
  global   rtype* par,
  global   uint*  rng_state,
  constant rtype* jump,
  global   rtype* accept,
  // user args
	@@def_user_args@@
)
{
  // The id for this worker
  int gid  = get_global_id(0);
  // Initialize the rng state
  state s = {
    rng_state[gid]
  };

  // The parameter vector for this model
  rtype pars[NPAR], ppars[NPAR];
  for (int i = 0; i < NPAR; i++) {
    pars[i]  = par[gid * NPAR + i];
    ppars[i] = pars[i];
  }

  // The jump vector for this model
  rtype jvec[NPAR];
  for (int i = 0; i < NPAR; i++) {
    jvec[i] = jump[gid * NPAR + i];
  }

  // Some algebra needs to happen to the proposed, so it happens here
  rtype final_proposed, final_current, resolve, ratio;

  // Keep track of the proposed and current prior and posterior
  rtype proposed[2];
  rtype proposed_e[2];
  rtype current[2] = {
    prior_out[gid],
    like_out[gid],
  };

  // Ensure we're dealing with real numbers here
  current[0] = isnan(current[0]) ? -FLT_MAX : current[0];
  current[1] = isnan(current[1]) ? -FLT_MAX : current[1];

	rtype aavg = 0;
	rtype out_prior, out_like;

	int accept_this = 0;
	int badone = 0;

  for (int iter = 0; iter < MCMC_RUNS; iter++) {
    // This is gibbs sampling with an embedded metropolis hastings algorithm
    // We do the embedded algorithm because we do not know if we can directly
    // sample from the conditional posterior, and so instead, we use the MH
    // algorithm to sample for us.

		out_prior = 0;
		out_like  = 0;

    // Iterate through every parameter, in order, and calculate successive
    // conditional distribtuions
    for (int pari = 0; pari < NPAR; pari++) {

			current[0]  = 0.0;
			current[1]  = 0.0;
			proposed[0] = 0.0;
			proposed[1] = 0.0;

			if (badone == 1 && pari > 0 && gid == 0) {
				printf("par[%d]: %f\n", pari - 1, pars[pari - 1]);
			}

			// Get the current value of the conditional posterior
			// first three args are mandatory:
			// - an array to store the values of the log-prior and log-likelihood
			// - the parameters for the model
			// - the index of the parameter that the conditional posterior is being sampled
			@@function_name@@ (
				current,
				pars,
				pari,
				@@fn_user_args@@
			);

			// Propose a new value for parameter 'pari'
      ppars[pari] = pars[pari] + EE;

			// Get the value of the propposed conditional posterior
			@@function_name@@ (
				proposed,
				ppars,
				pari,
				@@fn_user_args@@
			);

			// Add the log-prior and log-likelihood to get the proportional log-posterior likelihood
			final_proposed = proposed[0] + proposed[1];
			final_current  = current[0]  + current[1];

			rtype g = (final_proposed - final_current) / EE ;

			pars[pari] = pars[pari] + .1 * g;

			// The rest of this is fluff
			aavg      += 1.0 / (MCMC_RUNS * NPAR);
			out_prior += proposed[0];
			out_like  += proposed[1];

    }
	}

  // reset the state
  rng_state[gid] = s.x;

  // Record the latest parameters
  for (int i = 0; i < NPAR; i++) {
    par[gid * NPAR + i] = pars[i];
  }

  // Record the prior and likelihood separately
  prior_out[gid] = out_prior;
  like_out[gid]  = out_like;
	// Record the average acceptance rate
  accept[gid]    = aavg;
}
