#define PI 3.14159265358979
#define SQ2PI 2.506628274631
#define SQ2 1.4142135623731
#define ERF_A 0.147
#define PI_A 4.330746751
#define PI2 6.283185

#define BETA_STOP 1.0e-7
#define BETA_TINY 1.0e-30


typedef float rtype;

// I'm keeping this as a separate type for clarity
typedef struct state {
	uint x;
} state;

typedef struct pp {
	rtype prior;
	rtype post;
} pp;

// From Xorshift RNGs
// George Marsaglia
rtype runif(state* s) {
	// uint in OpenCL is 32 bit
	uint y = s->x;
	// Note these are all prime
	y ^= y << 13;
	y ^= y >> 17;
	y ^= y << 15;
	// The runif function self-updates the state
	s->x = y;
	// x is a uint, we want a float, so divide by the maximum uint
	rtype o = (y >> 8) * 0x1.0p-24;
	return(o);
};


rtype dnorm(rtype x, rtype m, rtype s)
{
	return exp(-.5 * pow((rtype)(x - m)/s, (rtype)2.0)) / (s * SQ2PI);
};

rtype ldnorm(rtype x, rtype m, rtype s)
{
	return -log(s) - .5 * log(PI2) - pow((rtype)(x - m), (rtype)2.0) / (2.0 * pow((rtype)s, (rtype)2.0));
};

rtype pnorm(rtype x, rtype m, rtype s)
{
	return .5 * (1 + erf((x - m) / (s * SQ2)));
};

// This is just an approximation of the inverse erf
// https://en.wikipedia.org/wiki/Error_function#Inverse_functions
rtype ierf(rtype z)
{
	rtype t1 = log(1 - pow((rtype)z, (rtype)2.0));
	rtype t2 = PI_A + (t1 / 2.0);
	return sign(z) * sqrt(
		sqrt(pow((rtype)t2, (rtype)2.0) - (t1 / ERF_A)) - t2
	);
};

rtype qnorm(rtype x, rtype m, rtype s)
{
	return m + s * SQ2 * ierf(2.0 * x - 1.0);
};

rtype rnorm(state* s, rtype mean, rtype sd)
{
	rtype ru = runif(s);
	return qnorm(ru, mean, sd);
};

// This is the regularized beta function, in log form
rtype lbeta(rtype a, rtype b)
{
	// lgamma is a built-in for opencl
	return lgamma(a) + lgamma(b) - lgamma(a + b);
};

// The log of the beta density function
rtype ldbeta(rtype x, rtype a, rtype b)
{
	rtype den = log(powr((rtype)x, (rtype) (a - 1.0))) + log(powr((rtype)(1.0 - x), (rtype)(b - 1.0))) - lbeta(a, b);
	return(den);
};

// The log of the beta density function
rtype ldbeta_alt(rtype x, rtype m, rtype p)
{
	return(ldbeta(x, m * p, (1 - m) * p));
};

float pbeta(float x, float a, float b) {
    if (x < 0.0 || x > 1.0) return 1.0/0.0;

    /*The continued fraction converges nicely for x < (a+1)/(a+b+2)*/
    if (x > (a + 1.0)/(a + b + 2.0)) {
        return (1.0 - pbeta(b, a, 1.0 - x)); /*Use the fact that beta is symmetrical.*/
    }

    /*Find the first part before the continued fraction.*/
    const float lbeta_ab = lgamma(a) + lgamma(b) - lgamma(a + b);
    const float front = exp(log(x) * a + log(1.0 - x) * b - lbeta_ab) / a;

    /*Use Lentz's algorithm to evaluate the continued fraction.*/
    float f = 1.0, c = 1.0, d = 0.0;

    int i, m;
    for (i = 0; i <= 200; ++i) {
        m = i / 2;

        float numerator;
        if (i == 0) {
            numerator = 1.0; /*First numerator is 1.0.*/
        } else if (i % 2 == 0) {
            numerator = (m * (b - m) * x) / ((a + 2.0 * m - 1.0) * (a + 2.0 * m));  /* Even term. */
        } else {
            numerator = -((a + m) * (a + b + m) * x) / ((a + 2.0 * m) * (a + 2.0 * m + 1));  /* Odd term. */
        }

        /*Do an iteration of Lentz's algorithm.*/
        d = 1.0 + numerator * d;
        if (fabs(d) < BETA_TINY) d = BETA_TINY;
        d = 1.0 / d;

        c = 1.0 + numerator / c;
        if (fabs(c) < BETA_TINY) c = BETA_TINY;

        const float cd = c*d;
        f *= cd;

        /*Check for stop.*/
        if (fabs(1.0 - cd) < BETA_STOP) {
            return front * (f - 1.0);
        }
    }

    return 1.0/0.0; /*Needed more loops, did not converge.*/
}

void norm_to_lnnorm(rtype m, rtype s, rtype* out)
{
	rtype m2 = pown(m, 2);
	rtype s2 = pown(s, 2);

	out[0] = log(m2 / sqrt(m2 + s2));
	out[1] = sqrt(log(1 + (s2 / m2)));
}

// This is defined in terms of the mean and standard deviation of the log-normal distribution
rtype dlnorm(rtype x, rtype m, rtype s)
{

	rtype p[2];
	norm_to_lnnorm(m, s, p);

	rtype o = (1 / (x * p[1] * SQ2PI));
	rtype n = log(x) - p[0];
	n = -n * n;
	n = exp(n / (2 * p[1] * p[1]));

	o = o * n;

	return o;
};

// Inverse-Gamma density function
rtype ldigamma(rtype x, rtype a, rtype b) {
	int sign;
	rtype v = lgamma_r(a, &sign);
	rtype out = a * log(b) - (sign * v) - (a + 1) * log(x) - (b / x);
	return(exp(out));
}
