set_default <- function(cfg, name, value) {
  cn <- names(cfg)
  if (! name %in% cn) {
    cfg[[name]] <- value
  }
  cfg
}

code_creator <- function(config, kernel_code, npar, dat, algo) {
  # Some names are going to be overwritten, just stop the user here. I could
  # warn them, but they shouldn't be doing this and probably don't mean to be.
  constants <- config$constants
  nc <- names(constants)
  reserved_constants <- c("NPAR", "MCMC_RUNS")
  if (any(nc %in% reserved_constants)) {
    msg <- paste0("The following names cannot be used as constants:\n")
    msg <- paste0(msg, paste(nc[nc %in% reserved_constants], collapse = ",\n"))
    stop(msg)
  }
  # Anyway, let's add a few more
  constants["NPAR"]      <- npar
  constants["MCMC_RUNS"] <- config$mcmc_runs

  # The kernel_code can be a file name
  if (file.exists(kernel_code)) {
    kernel_code <- get_file(kernel_code)
  }

  # Get the mhmc or gibbs file
  fname <- system.file(package = "rcocl", paste0("dists.c"))
  dists  <- readLines(fname)
  dists  <- paste(dists, collapse = "\n")

  # Generate the kernel code
  code <- c(
    # Make define statements
    make_defines(constants),
    # Add code for distributions
    dists,
    # Add in the user code,
    kernel_code,
    # Make the kernel code
    make_mcmc_kern(
      dat,
      config$fn,
      algo
    )
  )
  code <- paste(code, collapse = "\n\n")

  # Write out the file for debugging purposes
  fname <- "/tmp/full.c"
  fconn <- file(fname, open = "w")
  writeLines(text = code, con = fconn, sep = "")
  close(fconn)

  code
}


#' @title Run MCMC sampler on gpu
#' @param kernel_code The code, or file, for the kernel
#' @param config      A list of configuration items
#' @param init        The initial parameters
#' @param jump        The jump standard deviations
#' @param dat        Double precision data
#' @export gpu_mcmc
gpu_mcmc <- function(
  kernel_code,
  config,
  init,
  jump,
  dat
) {

  # The jump and init vectors need to be the same size
  if (length(init) != length(jump)) {
    stop("Initial parameters and Jump vector are not the same length")
  }

  # Some terms are required in the config
  required_cfg <- c("draws", "fn", "dlist", "algo")
  check <- ! required_cfg %in% names(config)

  if (any(check)) {
    msg <- paste0("Some required config items are missing:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[! names(config) %in% required_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some terms are forbidden in the config
  forbidden_cfg <- c("nrows", "npar")
  if (any(names(config) %in% forbidden_cfg)) {
    msg <- paste0("Some config items are forbidden:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[names(config) %in% forbidden_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some names for the function are impermissible
  forbidden_fname <- c(
    "mhmc", "gibbs",
    "state",
    "dnorm", "ldnorm", "pnorm", "ierf", "qnorm", "rnorm",
    "lbeta", "ldbeta", "ldbeta_alt", "pbeta", "norm_to_lnorm",
    "dlnorm", "ldigamma")
  if (config$fn %in% forbidden_fname)
    stop("You can't name your function mhmc or gibbs")

  # The initial paramters need to be a numeric vector
  if (! is.vector(init, mode = "numeric")) {
    stop("init needs to be a numeric vector")
  }
  if (any(!is.finite(init))) {
    stop("All values of init need to be finite")
  }

  # Add a few extra items here and there
  # We need to know the number of parameters often
  npar <- length(init)

  # Some things are optional
  config <- set_default(config, "show_sd",    0)
  config <- set_default(config, "sd_mult",    1)
  config <- set_default(config, "mcmc_runs",  1)
  config <- set_default(config, "keep_every", 1)
  config <- set_default(config, "skip",       100)
  config <- set_default(config, "burn_sd",    1)
  config <- set_default(config, "auto_burn",  FALSE)
  config <- set_default(config, "auto_lag",   100)
  config <- set_default(config, "auto_sig",   .05)
  config <- set_default(config, "constants",  list())
  config <- set_default(config, "batches",    rep(1, npar))
  config <- set_default(config, "sampler",    rep("mcmc", length(config$batches)))

  # Some optional things have requirements still
  sbatch <- sum(config[["batches"]])
  if (sbatch < npar) {
    warning("The specified batches vector sums to less than the total number of parameters, appending '1' for missing batches")
    config[["batches"]] <- c(config[["batches"]], rep(1, npar - sbatch))
  } else if (sbatch > npar) {
    stop("The specified batches vector sums to more than the number of parameters, you need to fix this.")
  }

  nbatches <- length(config[["batches"]])
  lsampler <- length(config[["sampler"]])
  if (lsampler < nbatches) {
    warning("The specified sampler vector is smaller than the batches vector, appending 'mcmc' for missing batches")
    config[["sampler"]] <- c(config[["sampler"]], rep("mcmc", nbatches - lsampler))
  } else if (lsampler > nbatches) {
    stop("The specified sampler vector is longer than the number of batches, you need to fix this.")
  }
  # we actually want a uint vector to pass around in C++
  config$sampler <- ifelse(config$sampler == "mcmc", 0, 1)

  # Some things need to be overwritten
  config$npar  <- npar
  config$constants[["NBATCHES"]] <- length(config[["batches"]])

  # We also want to pre-figure out the number of chains
  config$chains <- sum(unlist(lapply(config$dlist, "[[", "work_items")))

  # Get the code
  code <- code_creator(config, kernel_code, npar, dat, algo = config["algo"])

  # Collect the samples
  out <- full_mcmc(
    kernel_code = code,
    config = config,
    init = init,
    jump = jump,
    dat = dat
  )

  # Name the output columns
  pnames <- names(init)
  stat_names <- c()
  for (pn in pnames) {
    stat_names <- c(stat_names, paste0(pn, c("_m", "_s", "_a")))
  }

  out[["stats"]] <- as.data.frame(out[["stats"]])
  colnames(out[["stats"]]) <- c("iter", "posterior_m", "posterior_s", stat_names)

  out[["samples"]] <- as.data.frame(out[["samples"]])
  colnames(out[["samples"]]) <- c("iter", "chain", "posterior", pnames)

  out
}
