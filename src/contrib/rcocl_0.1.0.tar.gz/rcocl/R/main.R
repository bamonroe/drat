set_default <- function(cfg, name, value) {
  cn <- names(cfg)
  if (! name %in% cn) {
    cfg[name] <- value
  }
  cfg
}

code_creator <- function(config, kernel_code, npar, dat, algo) {
  # Some names are going to be overwritten, just stop the user here. I could
  # warn them, but they shouldn't be doing this and probably don't mean to be.
  constants <- config$constants
  nc <- names(constants)
  reserved_constants <- c("NPAR", "MCMC_RUNS")
  if (any(nc %in% reserved_constants)) {
    msg <- paste0("The following names cannot be used as constants:\n")
    msg <- paste0(msg, paste(nc[nc %in% reserved_constants], collapse = ",\n"))
    stop(msg)
  }
  # Anyway, let's add a few more
  constants["NPAR"]      <- npar
  constants["MCMC_RUNS"] <- config$mcmc_runs

  # The kernel_code can be a file name
  if (file.exists(kernel_code)) {
    kernel_code <- get_file(kernel_code)
  }


  # Get the mhmc or gibbs file
  fname <- system.file(package = "rcocl", paste0("dists.c"))
  dists  <- readLines(fname)
  dists  <- paste(dists, collapse = "\n")

  # Generate the kernel code
  code <- c(
    # Make define statements
    make_defines(constants),
    # Add code for distributions
    dists,
    # Add in the user code,
    kernel_code,
    # Make the kernel code
    make_mcmc_kern(
      dat,
      config$fn,
      algo
    )
  )
  code <- paste(code, collapse = "\n\n")

  # Write out the file for debugging purposes
  fname <- "/tmp/full.c"
  fconn <- file(fname, open = "w")
  writeLines(text = code, con = fconn, sep = "")
  close(fconn)

  code
}

#' @title Run MCMC sampler on gpu
#' @param kernel_code The code, or file, for the kernel
#' @param config      A list of configuration items
#' @param init        The initial parameters
#' @param jump        The jump standard deviations
#' @param dat        Double precision data
#' @export gpu_mcmc
gpu_mcmc <- function(
  kernel_code,
  config,
  init,
  jump,
  dat
) {

  # The jump and init vectors need to be the same size
  if (length(init) != length(jump)) {
    stop("Initial parameters and Jump vector are not the same length")
  }

  # Some terms are required in the config
  required_cfg <- c(
    "draws",   "fn",      "mcmc_runs",
    "dlist",   "burn_sd", "keep_every",
    "show_sd", "skip",    "algo")
  check <- ! required_cfg %in% names(config)

  if (any(check)) {
    msg <- paste0("Some required config items are missing:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[! names(config) %in% required_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some terms are forbidden in the config
  required_cfg <- c("nrows", "npar")
  if (any(names(config) %in% required_cfg)) {
    msg <- paste0("Some config items are forbidden:\n")
    msg <- paste0(
      msg,
      paste(
        names(config)[names(config) %in% required_cfg],
        collapse = ",\n"
      )
    )
    stop(msg)
  }

  # Some names for the function are impermissible
  forbidden <- c("mhmc", "gibbs")
  if (config$fn %in% forbidden)
    stop("You can't name your function mhmc or gibbs")

  # The initial paramters need to be a numeric vector
  if (! is.vector(init, mode = "numeric")) {
    stop("init needs to be a numeric vector")
  }
  if (any(!is.finite(init))) {
    stop("All values of init need to be finite")
  }

  # Add a few extra items here and there
  # We need to know the number of parameters often
  npar <- length(init)

  # Some things need to be overwritten
  config$npar  <- npar
  # Some things are optional
  config <- set_default(config, "show_sd", 0)

  # Get the code
  code <- code_creator(config, kernel_code, npar, dat, algo = config["algo"])

  # Collect the samples
  out <- full_mcmc(
    kernel_code = code,
    config = config,
    init = init,
    jump = jump,
    dat = dat
  )

  samples <- as.data.frame(out)
  cn <- c("posterior", "chain", "iter")
  cn <- c(cn, paste0("theta", seq_len(npar)))
  colnames(samples) <- cn

  samples
}
