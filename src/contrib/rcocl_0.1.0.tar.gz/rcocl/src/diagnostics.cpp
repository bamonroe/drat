// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

void per_marginal(
	int n,
	int m,
	NumericVector &var,
	double *out
) {

	// Make a matrix of the marginal distribution with columns for each
	// chain, and rows for each iteration
	arma::mat smat(var.begin(), n, m);

	// Means of the paramaters by chain
	arma::rowvec chain_mean = mean(smat, 0);
	arma::rowvec chain_var  = mean(pow(smat, 2.0), 0) - pow(chain_mean, 2.0);

	// Mean of the parameters across all chains
	double tot_mean = mean(chain_mean);

	// Between chain variance
	double B = ((double)n / (double)(m - 1.0)) * sum(pow(chain_mean - tot_mean, 2.0));
	double W = (1.0 / (double)m) * sum(chain_var);
	// Adjust for the (n - 1) in the estimation of the variance instead of just n
	W = W *  ((double) n / ((double) n - 1));

	// Estimate the variance of the estimator
	double vhplus = ((double)(n - 1) / (double)n) * W + (1.0 / (double)n) * B;

	// Gelman-Rubin statistic, commonly labelled as r hat.
	double Rhat = sqrt(vhplus / W);

	// Save Rhat
	out[0] = Rhat;

}

//' @title Calculate some diagnostics for the posterior
//' @param n       The number of iterations
//' @param m       The number of chains
//' @param samples The matrix of the posterior stacked by chain
//' @export post_diag
// [[Rcpp::export]]
NumericMatrix post_diag (
	int n,
	int m,
	NumericMatrix samples
) {

	int npar = samples.ncol();

	// Mark the current time
	uint64_t now0 = timeSinceEpochMillisec();
	uint64_t now1;
	double diff = 0;

	double dvals[1];
	NumericVector var;
	NumericMatrix out(npar, 1);

	for (int i = 0; i < npar; i++) {
		var = samples(_, i);
		per_marginal(n, m, var, dvals);

		// Save the Rhat value
		out(i, 0) = dvals[0];

	}

	// Calculate the total time for diagnostic calculation
	now1 = timeSinceEpochMillisec();
	diff = now1 - now0;

	Rcout << "Done with diagnostics" << std::endl;
	Rcout << "Average time per parameter: " << diff / n << "ms" <<std::endl;
	Rcout << "Total diagnostic time:      " << diff / 1000 << "s" <<std::endl;

	return(out);
}

