// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <CL/opencl.hpp>
#include <unistd.h>
#include <limits>
#include <chrono>

// Only define if needed
#ifndef maindef
#include "main.hpp"
#endif

#define __CL_ENABLE_EXCEPTIONS

using namespace Rcpp;

uint64_t timeSinceEpochMillisec() {
  using namespace std::chrono;
  return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

//std::vector<double> per_marginal(
void per_marginal(
	int n,
	int m,
	NumericVector &var,
	double *out
) {

	// Make a matrix of the marginal distribution with columns for each
	// chain, and rows for each iteration
	arma::mat smat(var.begin(), n, m);

	// Means of the paramaters by chain
	arma::rowvec chain_mean = mean(smat, 0);
	arma::rowvec chain_var  = mean(pow(smat, 2.0), 0) - pow(chain_mean, 2.0);

	// Mean of the parameters across all chains
	double tot_mean = mean(chain_mean);

	// Between chain variance
	double B = ((double)n / (double)(m - 1.0)) * sum(pow(chain_mean - tot_mean, 2.0));
	double W = (1.0 / (double)m) * sum(chain_var);
	// Adjust for the (n - 1) in the estimation of the variance instead of just n
	W = W *  ((double) n / ((double) n - 1));

	// Estimate the variance of the estimator
	double vhplus = ((double)(n - 1) / (double)n) * W + (1.0 / (double)n) * B;

	// Gelman-Rubin statistic, commonly labelled as r hat.
	double Rhat = sqrt(vhplus / W);

	// Save Rhat
	out[0] = Rhat;

}

//' @title Calculate some diagnostics for the posterior
//' @param n       The number of iterations
//' @param m       The number of chains
//' @param samples The matrix of the posterior stacked by chain
//' @export post_diag
// [[Rcpp::export]]
NumericMatrix post_diag (
	int n,
	int m,
	NumericMatrix samples
) {

	int npar = samples.ncol();

	// Mark the current time
	uint64_t now0 = timeSinceEpochMillisec();
	uint64_t now1;
	double diff = 0;

	double dvals[1];
	NumericVector var;
	NumericMatrix out(npar, 1);

	for (int i = 0; i < npar; i++) {
		var = samples(_, i);
		per_marginal(n, m, var, dvals);

		// Save the Rhat value
		out(i, 0) = dvals[0];

	}

	// Calculate the total time for diagnostic calculation
	now1 = timeSinceEpochMillisec();
	diff = now1 - now0;

	Rcout << "Done with diagnostics" << std::endl;
	Rcout << "Average time per parameter: " << diff / n << "ms" <<std::endl;
	Rcout << "Total diagnostic time:      " << diff / 1000 << "s" <<std::endl;

	return(out);
}


void showme(
	Ovec<rtype> &ll,
	Ovec<rtype> &prior,
	Ovec<rtype> &par,
	Ovec<rtype> &jump,
	OclHandler &ocl,
	bconf &cfg,
	int p
){

	rtype v;
	for (int d = 0; d < ocl.ndev ; d++) {
		for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
			v = par.at(d, wi, p);
			// Increment the work item counter
			if (!std::isfinite(v)) {
					Rcout << "d: " <<d << " wi: " << wi << " par: " << v  << std::endl;
			}
		}
	}

}

void fmcmc_display(
	Ovec<rtype> &ll,
	Ovec<rtype> &prior,
	Ovec<rtype> &par,
	Ovec<rtype> &jump,
	bconf &cfg,
	int iter,
	List config,
	rtype &avg_accept
) {

	std::vector<rtype> drow(cfg.NPARS + 1);
	// The posterior
	drow.at(0) = ll.at(0) + prior.at(0);

	rtype *par_i;
	par_i   = par.getv(0);
	for (int p = 0; p < cfg.NPARS; p++) {
		drow.at(p + 1) = *par_i;
		par_i++;
	}

	int show_sd = config["show_sd"];
	int iskip   = config["skip"];
	int ikeep   = config["keep_every"];

	if (iter >= iskip && ((iter - iskip) % ikeep) == 0) {
		Rcout  << "**iter: " << iter;
	} else {
		Rcout  << "@@iter: " << iter;
	}

	Rcout
	<< " \tpost: "   << drow.at(0)
	<< " \tpar["     << show_sd << "]: " << drow.at(show_sd + 1)
	<< " \tsd["      << show_sd << "]: " << jump.at(0, 0, show_sd)
	<< " \taccept: " << avg_accept
	<< std::endl;

}

void collect_samples(
	Ovec<rtype> &ll,
	Ovec<rtype> &prior,
	Ovec<rtype> &par,
	bconf &cfg,
	NumericMatrix &samples,
	OclHandler &ocl,
	int iter,
	int keep_row
)
{
	rtype *ll_p, *prior_p, *par_i;
	int rnum = keep_row * cfg.POINTS;
	int irow = 0;
	int chain = 0;
	// Assign the chosen pars to the full sample
	for (int d = 0; d < ocl.ndev ; d++) {
		ll_p    = ll.getv(d);
		prior_p = prior.getv(d);
		par_i   = par.getv(d);

		for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
			// First the posterior
			samples.at(rnum + irow, 0) = *ll_p + *prior_p;
			// Second the chain
			samples.at(rnum + irow, 1) = chain;
			// Third the iteration
			samples.at(rnum + irow, 2) = iter;

			for (int p = 0; p < cfg.NPARS; p++) {
				// Save the parameters
				samples.at(rnum + irow, 3 + p) = *par_i;
				par_i++;
			}
			irow++;
			ll_p++;
			prior_p++;
			chain++;
		}
	}

}

void fmcmc_calc(
	Ovec<rtype> &ll,
	Ovec<rtype> &prior,
	Ovec<rtype> &par,
	Ovec<rtype> &accepts,
	Ovec<rtype> &jump,
	bconf &cfg,
	NumericMatrix &samples,
	int iter,
	OclHandler &ocl,
	std::vector<std::vector<rtype>> &rm1,
	std::vector<std::vector<rtype>> &rm2,
	std::vector<rtype> &m1,
	std::vector<rtype> &m2,
	rtype &jump_mult,
	rtype &avg_accept,
	List config
){

	rtype *par_i, *rej_i;
	rtype *rm1_i, *rm2_i;

	int rnum = iter * cfg.POINTS;

	// Set m1 and m2 to 0
	std::fill(m1.begin(), m1.end(), 0);
	std::fill(m2.begin(), m2.end(), 0);

	// Reset to 0
	avg_accept = 0;

	// Work item counter
	int wic = -1;
	for (int d = 0; d < ocl.ndev ; d++) {
		par_i   = par.getv(d);
		rej_i   = accepts.getv(d);
		for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
			// Increment the work item counter
			wic++;

			rm1_i = rm1.at(wic).data();
			rm2_i = rm2.at(wic).data();

			avg_accept += *rej_i / cfg.POINTS;
			rej_i++;

			for (int p = 0; p < cfg.NPARS; p++) {

				// Winithin chain mean and variance
				*rm1_i = *rm1_i * ((iter - 1) / iter) + (*par_i / iter);
				*rm2_i = *rm2_i * ((iter - 1) / iter) + ((*par_i * *par_i) / iter);

				// Between chain mean and variance parameters
				// Live mean algorithm
				m1.at(p) += *par_i / cfg.POINTS;
				// Live variance
				m2.at(p) += (*par_i * *par_i) / cfg.POINTS;

				// Increment the iterators
				par_i++;
				rm1_i++;
				rm2_i++;
			}
		}
	}
	// Update jump after the burn_sd
	int sd_stop  = config["sd_stop"];
	int sd_every = config["sd_every"];
	rtype sd_mult = config["sd_mult"];

	if (iter >= cfg.BURNSD && iter < sd_stop && iter % sd_every == 0) {

		rtype bvar, wvar, *jump_i;

		// The fraction of the jump distribution given by between chain variance
		rtype bfactor = config["bfactor"];

		wic = 0;
		for (int d = 0; d < ocl.ndev ; d++) {
			jump_i = jump.getv(d);
			for (int wi = 0; wi < ocl.work_items[d] ; wi++) {
				rm1_i = rm1.at(wic).data();
				rm2_i = rm2.at(wic).data();
				for (int p = 0; p < cfg.NPARS; p++) {
					// Between_chain variance
					bvar = m2.at(p) - (m1.at(p) * m1.at(p));
					bvar = sqrt(bvar);

					// Within_chain variance
					wvar = *rm2_i - (*rm1_i * *rm1_i);
					wvar = sqrt(wvar);

					if (!std::isfinite(wvar)) {
						Rcout << "Non-finite within variance:" << std::endl;
						Rcout << "d: " <<d << " wi: " << wi << " p: " << p  << std::endl;
						Rcout << "wvar: " << *rm2_i - (*rm1_i * *rm1_i) << std::endl;
						Rcout << "bvar: " << m2.at(p) - (m1.at(p) * m1.at(p)) << std::endl;
						Rcout << "rm1: " << *rm1_i  << std::endl;
						Rcout << "rm2: " << *rm2_i  << std::endl;
						Rcout << "m1 " << m1.at(p) << std::endl;
						Rcout << "m2 " << m2.at(p) << std::endl;
						Rcout << "par(p) " << par.at(d, wi, p) << std::endl;
						showme(ll, prior, par, jump, ocl, cfg, p);
						std::exit(1);
					}

					if (!std::isfinite(bvar)) {
						Rcout << "Non-finite between variance:" << std::endl;
						Rcout << "d: " <<d << " wi: " << wi << " p: " << p  << std::endl;
						Rcout << "bvar: " << m2.at(p) - (m1.at(p) * m1.at(p)) << std::endl;
						Rcout << "rm1 " << *rm1_i << std::endl;
						Rcout << "rm2 " << *rm2_i << std::endl;
						Rcout << "m1 " << m1.at(p) << std::endl;
						Rcout << "m2 " << m2.at(p) << std::endl;
						Rcout << "wvar(p) " << wvar << std::endl;

						showme(ll, prior, par, jump, ocl, cfg, p);
						std::exit(1);
					}

					// Average the between and within variance
					*jump_i = (bvar * bfactor) + (wvar * (1 - bfactor));
					// Adjust this by a scaling factor to keep acceptance rates in a good range
					*jump_i = *jump_i * sd_mult;

					rm1_i++;
					rm2_i++;
					jump_i++;
					//Rcout << var << std::endl;
				}
				wic++;
			}
		}

		// Write the jump buffer
		ocl.write_buffer<Ovec<rtype>&>(jump, 4, cfg.NPARS, true);
		ocl.finish();
	}
}

//' @title Gather samples from _every_ chain
//' @param kernel_code The code for the kernel
//' @param config      A list of configuration items
//' @param init        The initial parameters
//' @param jump        The jump standard deviations
//' @param dat         rtype precision data
// [[Rcpp::export]]
NumericMatrix full_mcmc
(
	String kernel_code,
	List config,
	NumericVector init,
	NumericVector jump,
	List          dat
)
{
	// Number of iterations
	int draws = config["draws"];
	// Keep every ikeep iterations
	int ikeep = config["keep_every"];
	// Skip the first iskip iterations
	int iskip = config["skip"];
	// Which algorithm are we running
	std::string algo = config["algo"];

	// Fix a = 0.5 after this many iterations
	const int show_sd = config["show_sd"];
	// The device number
	List dlist = config["dlist"];
	// Now actually begin initializing the OpenCL stuff
	// Get all platforms (drivers)
	OclHandler ocl(dlist, kernel_code);

	// Some pieces need to be carried arround, so let's save them in a struct
	bconf cfg = {
		config["npar"],
		ocl.totalwi,
		config["burn_sd"],
	};

	// Add the prior column
	ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, 1, true);
	// Add the likelihood column
	ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, 1, true);
	// Add column for parameters
	ocl.make_buffer<rtype>(CL_MEM_READ_WRITE, cfg.NPARS, true);
	// Add column to hold the state for RNG
	ocl.make_buffer<cl_uint>(CL_MEM_READ_WRITE, 1, true);
	// Add column for the standard deviation of the proposal distributions
	ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, cfg.NPARS, true);

	// Add column to hold the average rejection states
	ocl.make_buffer<cl_uint>(CL_MEM_WRITE_ONLY, 1, true);
	std::vector<rtype> wzeros(cfg.POINTS);
	std::fill(wzeros.begin(), wzeros.end(), 0.0);
	ocl.write_buffer<rtype*>(wzeros.data(), ocl.bi(), 1, true);

	// Write in the data
	List ddat, idat;

	NumericVector dvec;
	IntegerVector ivec;

	ddat = dat["double"];
	idat = dat["int"];

	for (int i = 0; i < ddat.length(); i++) {
		// Get the List item into vectors
		dvec = ddat[i];
		std::vector<rtype> sdvec (dvec.begin(), dvec.end());

		ocl.make_buffer<rtype>(CL_MEM_READ_ONLY, sdvec.size(), false);
		ocl.write_buffer<rtype*>(sdvec.data(), ocl.bi(), dvec.length(), false);
		ocl.finish();
	}

	for (int i = 0; i < idat.length(); i++) {
		// Get the List item into vectors
		ivec = idat.at(i);
		ocl.make_buffer<cl_int>(CL_MEM_READ_ONLY, ivec.length(), false);
		ocl.write_buffer<cl_int*>(ivec.begin(), ocl.bi(), ivec.length(), false);
	}

	// Everything up to here needs to have finished
	ocl.finish();

	// Set the array that will hold the prior
	Ovec<rtype> prior(&ocl, 1);
	// Set the array that will hold the likelihoods
	Ovec<rtype> ll(&ocl, 1);
	// The arrary for the parameters
	Ovec<rtype> par(&ocl, cfg.NPARS); // Initial
	// The arrays for the RNG states
	Ovec<cl_uint> rng(&ocl, 1);
	// The arrays for the jumps
	Ovec<rtype> jvec(&ocl, cfg.NPARS);
	// The arrays for the rejection statistics
	Ovec<rtype> accepts(&ocl, 1);

	// Initialize the parameter vector
	rtype *par_init, *like_init, *prior_init, *rej_init, *jump_init;
	cl_uint *rng_init;

	int counter = 0;
	// loop through all devices to initialize per-device
	for (int d = 0; d < ocl.ndev; d++)
	{
		// Parameter
		par_init   = par.getv(d);
		// likelihood
		like_init  = ll.getv(d);
		// prior
		prior_init = prior.getv(d);
		// rng
		rng_init   = rng.getv(d);
		// rng
		jump_init  = jvec.getv(d);
		// rejects
		rej_init   = accepts.getv(d);

		// Loop through the work-items per device
		for (int i = 0; i < ocl.work_items[d]; i++){
			// Initialize the parameters
			for (int j = 0; j < cfg.NPARS; j++)
			{
				*par_init  = init[j];
				*jump_init = jump[j];
				par_init++;
				jump_init++;
			}
			// Set prior and posterior to lowest possible values
			*like_init  = -90000;
			*prior_init = -10000;
			// Set the initial RNG state to be equal to the work item index
			*rng_init = (counter + 1) * 10 + (cl_uint)round(R::runif(0, 10)) ;
			// Initializing rejections at 0
			*rej_init = 0.0;
			// Increment pointers
			like_init++;
			prior_init++;
			rng_init++;
			rej_init++;
			counter++;
		}
	}

	// Write the prior buffer
	ocl.write_buffer<Ovec<rtype>&>(prior,   0, 1, true);
	// Write the likelihood buffer
	ocl.write_buffer<Ovec<rtype>&>(ll,      1, 1, true);
	// Write the parameter buffer
	ocl.write_buffer<Ovec<rtype>&>(par,     2, cfg.NPARS, true);
	// Write the RNG states
	ocl.write_buffer<Ovec<cl_uint>&>(rng,   3, 1, true);
	// Write the jump buffer
	ocl.write_buffer<Ovec<rtype>&>(jvec,    4, cfg.NPARS, true);
	// Write the rejection buffer
	ocl.write_buffer<Ovec<rtype>&>(accepts, 5, 1, true);

	// Set the numeric vector that will hold all the samples
	// Extra cols:
	//   posterior
	//   chain
	//   iteration
	int extra_cols = 3;
	NumericMatrix samples(draws * cfg.POINTS, cfg.NPARS + extra_cols);

	// Within chain variance
	std::vector<std::vector<rtype>> rm1;
	std::vector<std::vector<rtype>> rm2;

	// Filly with vectors of zeros
	std::vector<rtype> zeros(cfg.NPARS);
	std::fill(zeros.begin(), zeros.end(), 0.0);
	for (int i = 0; i < cfg.POINTS; i++) {
			rm1.push_back(zeros);
			rm2.push_back(zeros);
	}

	// Between chain variance
	std::vector<rtype> m1(cfg.NPARS);
	std::vector<rtype> m2(cfg.NPARS);

	rtype jump_mult = 1.0;
	rtype avg_accept = 1.0;

	Rcout << "@@full_mcmc: Staring iterations" << std::endl;

	int keep_row = 0;
	// And loop through the iterations
	ocl.finish();

	double avg_time = 0;
	uint64_t now0 = timeSinceEpochMillisec();
	uint64_t now1;
	double diff = 0, n;

	// number of iterations
	int niter = iskip + ikeep * draws;

	for (int iter = 1; iter <= niter; iter++)
	{
		// Run the kernel on all devices
		ocl.run_kernel(algo);
		// Read result from GPU to here
		ocl.read_buffer<Ovec<rtype>&>(prior,   0, 1, true);
		ocl.read_buffer<Ovec<rtype>&>(ll,      1, 1, true);
		ocl.read_buffer<Ovec<rtype>&>(par,     2, cfg.NPARS, true);
		ocl.read_buffer<Ovec<cl_uint>&>(rng,   3, 1, true);
		ocl.read_buffer<Ovec<rtype>&>(accepts, 5, 1, true);
		// Kernel needs to have finished
		ocl.finish();

		// Calculate the jump distribution
		fmcmc_calc(ll, prior, par, accepts, jvec, cfg, samples, iter, ocl, rm1, rm2, m1, m2, jump_mult, avg_accept, config);

		// Collect the samples
		if (iter > iskip && ((iter - iskip) % ikeep) == 0) {
			collect_samples(ll, prior, par, cfg, samples, ocl, iter, keep_row);
			keep_row++;
		}

		// Display some information
		fmcmc_display(ll, prior, par, jvec, cfg, iter, config, avg_accept);
		ocl.finish();

		// Collect iteration times
		now1 = timeSinceEpochMillisec();
		diff = now1 - now0;
		n    = iter;
		avg_time =  avg_time * (n / (n + 1)) + (diff / (n + 1));
		now0 = now1;
	}

	Rcout << "Done with iterations" << std::endl;
	Rcout << "Average time per iteration: " << avg_time << "ms" <<std::endl;
	Rcout << "Total iteration time:       " << avg_time * niter / 1000 << "s" <<std::endl;

	return samples;
};
