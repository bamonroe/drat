// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <CL/opencl.hpp>
using namespace Rcpp;

#define maindef
//#define rtype cl_float
typedef cl_float rtype;

typedef NumericVector nvec;
typedef NumericMatrix nmat;

template <typename T> class Ovec;
class OclHandler;

uint64_t timeSinceEpochMillisec();

struct bconf
{
	int NPARS;
	int CHAINS;
	int BURNSD;
};

struct ravg
{
	rtype ratio;
	int n;
	int N;
};

struct ocl_pairs
{
	int pnum;
	std::vector<int> dnum;
	std::vector<int> work_items;
};

struct buffer_parameters {
  int  nelem;
  bool times_wi;
};

class OclHandler {
	private:
		std::vector<ocl_pairs>               pairs;
		std::vector<cl::Platform>            platforms;
		std::vector<std::vector<cl::Device>> all_devs;
		std::vector<cl::Device*>             devices;
		cl::Program::Sources                 sources;
		std::vector<buffer_parameters>       buf_params;
		int buf_num;

		// Functions to get pointers dynamically
		template <typename T> T* get_ptr(Ovec<T>& in, int d) {return (in.getv(d));}
		template <typename T> T* get_ptr(T* in, int d)       {return (in);}

		// Functions to get sizes for read/writing to buffers dynamically
		template <typename T> T get_size(Ovec<T>& in) {return (sizeof(T));}
		template <typename T> T get_size(T* in)       {return (sizeof(T));}

	public:
		std::vector<std::vector<cl::Buffer>> buffers;
		std::vector<cl::Context>             contexts;
		std::vector<cl::CommandQueue>        queues;
		std::vector<cl::Program>             programs;
		std::vector<cl::Kernel>              kernels;
		std::vector<int>                     work_items;
		int                                  ndev;
		int                                  totalwi;
		OclHandler(List &dev, String &code);
		void finish();
		void run_kernel(std::string kernel_name);
		int bnum();
		int bi();

		template <typename T>
		void make_buffer(int cl_mem, int nelem, bool times_wi)
		{
			// Some are ints, some are doubles
			int size = sizeof(T);

			// Instantiate the buffers vector if it doesn't already exist
			if (this->buffers.size() != this->ndev) {
				for (int d = 0; d < this->ndev; d++)
				{
					this->buffers.push_back(std::vector<cl::Buffer>());
				}
			}

			int twi;
			for (int d = 0; d < this->ndev; d++)
			{
				// Some buffers need dev-specific sizes
				twi = times_wi ? this->work_items[d] : 1;
				// Make the buffer
				this->buffers[d].push_back(
					cl::Buffer(this->contexts[d], cl_mem, nelem * size * twi)
				);
			}

      // Saving the buffer parameters for reading/writing
      buffer_parameters bp = {
        nelem,
        times_wi
      };
      this->buf_params.push_back(bp);
		}

		template <typename T>
		void read_buffer(T out, int bnum)
		{
			// Some are ints, some are doubles
			int size = get_size(out);

      int nelem     = this->buf_params[bnum].nelem;
      bool times_wi = this->buf_params[bnum].times_wi;

			int twi;
			for (int d = 0; d < this->ndev; d++)
			{
				// Some buffers need dev-specific sizes
				twi = times_wi ? this->work_items[d] : 1;
				this->queues[d].enqueueReadBuffer(this->buffers[d][bnum],
					CL_FALSE,
					0,
					nelem * size * twi,
					get_ptr(out, d));
			}
		}

		template <typename T>
		void write_buffer(T in, int bnum)
		{
			// Some are ints, some are doubles
			int size = get_size(in);

      int nelem     = this->buf_params[bnum].nelem;
      bool times_wi = this->buf_params[bnum].times_wi;

			int twi;
			for (int d = 0; d < this->ndev; d++)
			{
				// Some buffers need dev-specific sizes
				twi = times_wi ? this->work_items[d] : 1;
				// Actually do the writing
				this->queues[d].enqueueWriteBuffer(this->buffers[d][bnum],
					CL_FALSE,
					0,
					nelem * size * twi,
					get_ptr(in, d)
				);
			}
		}
};

template <typename T>
class Ovec {
	private:
		// The vector of vectors that will hold the actual values
		std::vector<std::vector<T>> val;
		// Keep track of the handler
		const OclHandler *ocl;
		// The multiplier. Basically 1 for the log-posterior, and NPARS for the
		// paramters
		int m;

	public:
		std::vector<int> wi;
		int ndev;

	Ovec(const OclHandler *ocl_in, int mult)
	{
		// keep track of the pointer and multiplier
		ocl = ocl_in;
		m = mult;
		ndev = ocl->ndev;
		// Initialize 'val'
		for (int i = 0; i < ocl->ndev; i++)
		{
			val.push_back(std::vector<T>(m * ocl->work_items[i]));
			wi.push_back(m * ocl->work_items[i]);
		}
	}

	// Get the pointer the position in the correct vector that corresponds
	// to work item 'wi'
	T* geti(int wi)
	{
		int w = 0, i;
		// Loop over the different devices
		for (i = 0; i < ocl->ndev; i++)
		{
			// Accumulate the number of work items for each device
			w += ocl->work_items[i];
			// If the work item 'wi' is less than the accumulated work
			// items, then it exists in device 'i'. Also, if we subtract
			// the latest device's work items from 'w', then we have the index of the first
			// work item for device 'i'. 'wi' minus this number times the multiplier is the
			// position in the i'th val vector of work item 'wi'.
			if (wi < w)
			{
				w -= ocl->work_items[i];
				break;
			}
		}
		// Return a pointer in the correct vector for the beginning of work item 'wi'
		return &val[i][(wi - w) * m];
	}

	// Get the pointer the position in the correct vector that corresponds
	// to work item 'wi'
	T at(int wi)
	{
		return(*geti(wi));
	}

	// Get the pointer the position in the correct vector that corresponds
	// to work item 'wi'
	T at(int di, int wi, int i)
	{
		return(val[di][wi * m + i]);
	}

	// Get the pointer to the beginning of the vector associated with device 'di'
	T* getv(int di)
	{
		return &val[di][0];
	}
};

class Stats {
  private:
    int bhat_sign[2];
    int iter_min;

    bool auto_burn;
    int  auto_lag;
    rtype auto_sig;

    int n;
    int index;
    arma::vec lm_x;
    arma::vec lm_y0;
    arma::vec lm_y1;

    std::vector<rtype> buffer;
    std::vector<std::vector<rtype>> data;
    void reg();
	public:
    int collect_signal;
    int ncols;

    rtype par_pred[3];

    Stats(List config, int ncol);
    void add(rtype val);
    rtype get(int col);
    NumericMatrix to_mat();
    void check_collect();
};
